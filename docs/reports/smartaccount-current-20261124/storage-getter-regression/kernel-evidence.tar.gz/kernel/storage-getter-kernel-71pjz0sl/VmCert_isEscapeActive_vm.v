From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition isEscapeActive_vm_program : list Ins :=
 [InitSlot 0 1; LdArg; Call 9; Push (GInt 4); PickItem; Push (GInt 0); Greater; Jump 8; Ret; InitSlot 2 1; LdStatic 8; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; NotEqualIns; JumpIf 25; Push (GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]); AbortMsg; LdLoc 1; CallToken 4; Jump 28; Ret].
Definition isEscapeActive_vm_code (pc : nat) : Ins := nth pc isEscapeActive_vm_program Unsupported.
Definition isEscapeActive_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 8 then Some (GBytes account_state_prefix) else None.
Definition isEscapeActive_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account] isEscapeActive_vm_statics sto [] tok.

Definition M0_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 isEscapeActive_vm_init tok sto account.

Definition M1_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M4_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M5_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M6_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M7_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M8_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M9_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M10_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M11_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M12_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M13_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M14_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M15_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M16_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M17_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M18_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M19_isEscapeActive_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Lemma t0_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 31 0 isEscapeActive_vm_code (M0_isEscapeActive_vm_miss tok sto account) =
 run 30 1 isEscapeActive_vm_code (M1_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_isEscapeActive_vm_miss.

Lemma t1_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 30 1 isEscapeActive_vm_code (M1_isEscapeActive_vm_miss tok sto account) =
 run 29 2 isEscapeActive_vm_code (M2_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_isEscapeActive_vm_miss.

Lemma t2_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 29 2 isEscapeActive_vm_code (M2_isEscapeActive_vm_miss tok sto account) =
 run 28 9 isEscapeActive_vm_code (M3_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_isEscapeActive_vm_miss.

Lemma t3_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 28 9 isEscapeActive_vm_code (M3_isEscapeActive_vm_miss tok sto account) =
 run 27 10 isEscapeActive_vm_code (M4_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_isEscapeActive_vm_miss.

Lemma t4_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 10 isEscapeActive_vm_code (M4_isEscapeActive_vm_miss tok sto account) =
 run 26 11 isEscapeActive_vm_code (M5_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_isEscapeActive_vm_miss.

Lemma t5_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 11 isEscapeActive_vm_code (M5_isEscapeActive_vm_miss tok sto account) =
 run 25 12 isEscapeActive_vm_code (M6_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_isEscapeActive_vm_miss.

Lemma t6_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 12 isEscapeActive_vm_code (M6_isEscapeActive_vm_miss tok sto account) =
 run 24 13 isEscapeActive_vm_code (M7_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_isEscapeActive_vm_miss.

Lemma t7_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 13 isEscapeActive_vm_code (M7_isEscapeActive_vm_miss tok sto account) =
 run 23 14 isEscapeActive_vm_code (M8_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_isEscapeActive_vm_miss.

Lemma t8_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 14 isEscapeActive_vm_code (M8_isEscapeActive_vm_miss tok sto account) =
 run 22 15 isEscapeActive_vm_code (M9_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M8_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_isEscapeActive_vm_miss.

Lemma t9_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 15 isEscapeActive_vm_code (M9_isEscapeActive_vm_miss tok sto account) =
 run 21 16 isEscapeActive_vm_code (M10_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_isEscapeActive_vm_miss.

Lemma t10_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 16 isEscapeActive_vm_code (M10_isEscapeActive_vm_miss tok sto account) =
 run 20 17 isEscapeActive_vm_code (M11_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_isEscapeActive_vm_miss.

Lemma t11_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (H : sto (account_state_prefix ++ account) = None),
 run 20 17 isEscapeActive_vm_code (M11_isEscapeActive_vm_miss tok sto account) =
 run 19 18 isEscapeActive_vm_code (M12_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account H.
 rewrite run_S.
 cbn [M11_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite H.
 reflexivity.
Qed.
Print Assumptions t11_isEscapeActive_vm_miss.

Lemma t12_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 18 isEscapeActive_vm_code (M12_isEscapeActive_vm_miss tok sto account) =
 run 18 19 isEscapeActive_vm_code (M13_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M12_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_isEscapeActive_vm_miss.

Lemma t13_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 18 19 isEscapeActive_vm_code (M13_isEscapeActive_vm_miss tok sto account) =
 run 17 20 isEscapeActive_vm_code (M14_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_isEscapeActive_vm_miss.

Lemma t14_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 20 isEscapeActive_vm_code (M14_isEscapeActive_vm_miss tok sto account) =
 run 16 21 isEscapeActive_vm_code (M15_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_isEscapeActive_vm_miss.

Lemma t15_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 21 isEscapeActive_vm_code (M15_isEscapeActive_vm_miss tok sto account) =
 run 15 22 isEscapeActive_vm_code (M16_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_isEscapeActive_vm_miss.

Lemma t16_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 22 isEscapeActive_vm_code (M16_isEscapeActive_vm_miss tok sto account) =
 run 14 23 isEscapeActive_vm_code (M17_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_isEscapeActive_vm_miss.

Lemma t17_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 23 isEscapeActive_vm_code (M17_isEscapeActive_vm_miss tok sto account) =
 run 13 24 isEscapeActive_vm_code (M18_isEscapeActive_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M17_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_isEscapeActive_vm_miss.

Lemma t18_isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 24 isEscapeActive_vm_code (M18_isEscapeActive_vm_miss tok sto account) = Thrown.
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M18_isEscapeActive_vm_miss isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_isEscapeActive_vm_miss.
Definition M0_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 isEscapeActive_vm_init tok sto account.

Definition M1_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M4_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M5_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M6_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M7_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M8_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M9_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M10_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M11_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M12_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M13_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M14_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M15_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M16_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBool true; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M17_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M18_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M19_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M20_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M21_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt 4%Z; GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt z; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt 0%Z; GInt z; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBool (Z.ltb 0 z); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M26_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBool (Z.ltb 0 z); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M27_isEscapeActive_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBool (Z.ltb 0 z); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := isEscapeActive_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 31 0 isEscapeActive_vm_code (M0_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 30 1 isEscapeActive_vm_code (M1_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M0_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_isEscapeActive_vm_hit.

Lemma t1_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 30 1 isEscapeActive_vm_code (M1_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 29 2 isEscapeActive_vm_code (M2_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M1_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_isEscapeActive_vm_hit.

Lemma t2_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 29 2 isEscapeActive_vm_code (M2_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 28 9 isEscapeActive_vm_code (M3_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M2_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_isEscapeActive_vm_hit.

Lemma t3_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 28 9 isEscapeActive_vm_code (M3_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 27 10 isEscapeActive_vm_code (M4_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M3_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_isEscapeActive_vm_hit.

Lemma t4_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 27 10 isEscapeActive_vm_code (M4_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 26 11 isEscapeActive_vm_code (M5_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M4_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_isEscapeActive_vm_hit.

Lemma t5_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 26 11 isEscapeActive_vm_code (M5_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 25 12 isEscapeActive_vm_code (M6_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M5_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_isEscapeActive_vm_hit.

Lemma t6_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 25 12 isEscapeActive_vm_code (M6_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 24 13 isEscapeActive_vm_code (M7_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M6_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_isEscapeActive_vm_hit.

Lemma t7_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 24 13 isEscapeActive_vm_code (M7_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 23 14 isEscapeActive_vm_code (M8_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M7_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_isEscapeActive_vm_hit.

Lemma t8_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 23 14 isEscapeActive_vm_code (M8_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 22 15 isEscapeActive_vm_code (M9_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M8_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_isEscapeActive_vm_hit.

Lemma t9_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 22 15 isEscapeActive_vm_code (M9_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 21 16 isEscapeActive_vm_code (M10_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M9_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_isEscapeActive_vm_hit.

Lemma t10_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 21 16 isEscapeActive_vm_code (M10_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 20 17 isEscapeActive_vm_code (M11_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M10_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_isEscapeActive_vm_hit.

Lemma t11_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (H : sto (account_state_prefix ++ account) = Some payload),
 run 20 17 isEscapeActive_vm_code (M11_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 19 18 isEscapeActive_vm_code (M12_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z H.
 rewrite run_S.
 cbn [M11_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite H.
 reflexivity.
Qed.
Print Assumptions t11_isEscapeActive_vm_hit.

Lemma t12_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 19 18 isEscapeActive_vm_code (M12_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 18 19 isEscapeActive_vm_code (M13_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M12_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_isEscapeActive_vm_hit.

Lemma t13_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 18 19 isEscapeActive_vm_code (M13_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 17 20 isEscapeActive_vm_code (M14_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M13_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_isEscapeActive_vm_hit.

Lemma t14_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 17 20 isEscapeActive_vm_code (M14_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 16 21 isEscapeActive_vm_code (M15_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M14_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_isEscapeActive_vm_hit.

Lemma t15_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 16 21 isEscapeActive_vm_code (M15_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 15 22 isEscapeActive_vm_code (M16_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M15_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_isEscapeActive_vm_hit.

Lemma t16_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 15 22 isEscapeActive_vm_code (M16_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 14 25 isEscapeActive_vm_code (M17_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M16_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_isEscapeActive_vm_hit.

Lemma t17_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 14 25 isEscapeActive_vm_code (M17_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 13 26 isEscapeActive_vm_code (M18_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M17_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_isEscapeActive_vm_hit.

Lemma t18_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 13 26 isEscapeActive_vm_code (M18_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 12 27 isEscapeActive_vm_code (M19_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Htok.
 rewrite run_S.
 cbn [M18_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t18_isEscapeActive_vm_hit.

Lemma t19_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 12 27 isEscapeActive_vm_code (M19_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 11 28 isEscapeActive_vm_code (M20_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M19_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_isEscapeActive_vm_hit.

Lemma t20_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 11 28 isEscapeActive_vm_code (M20_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 10 3 isEscapeActive_vm_code (M21_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M20_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_isEscapeActive_vm_hit.

Lemma t21_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 10 3 isEscapeActive_vm_code (M21_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 9 4 isEscapeActive_vm_code (M22_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M21_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_isEscapeActive_vm_hit.

Lemma t22_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hnth : nth_error xs (Z.to_nat 4%Z) = Some (GInt z)),
 run 9 4 isEscapeActive_vm_code (M22_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 8 5 isEscapeActive_vm_code (M23_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hnth.
 rewrite run_S.
 cbn [M22_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t22_isEscapeActive_vm_hit.

Lemma t23_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 8 5 isEscapeActive_vm_code (M23_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 7 6 isEscapeActive_vm_code (M24_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M23_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_isEscapeActive_vm_hit.

Lemma t24_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 7 6 isEscapeActive_vm_code (M24_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 6 7 isEscapeActive_vm_code (M25_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M24_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_isEscapeActive_vm_hit.

Lemma t25_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 6 7 isEscapeActive_vm_code (M25_isEscapeActive_vm_hit tok sto account payload xs z) =
 run 5 8 isEscapeActive_vm_code (M26_isEscapeActive_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M25_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t25_isEscapeActive_vm_hit.

Lemma t26_isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 5 8 isEscapeActive_vm_code (M26_isEscapeActive_vm_hit tok sto account payload xs z) = Done (GBool (Z.ltb 0 z)).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M26_isEscapeActive_vm_hit isEscapeActive_vm_init isEscapeActive_vm_code isEscapeActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t26_isEscapeActive_vm_hit.

Theorem isEscapeActive_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (account_state_prefix ++ account) = None ->
 run 31 0 isEscapeActive_vm_code (isEscapeActive_vm_init tok sto account) = Thrown /\
 escape_active_outcome tok sto account = Fault.
Proof.
 intros tok sto account H. split.
 - exact (eq_trans (t0_isEscapeActive_vm_miss tok sto account) (eq_trans (t1_isEscapeActive_vm_miss tok sto account) (eq_trans (t2_isEscapeActive_vm_miss tok sto account) (eq_trans (t3_isEscapeActive_vm_miss tok sto account) (eq_trans (t4_isEscapeActive_vm_miss tok sto account) (eq_trans (t5_isEscapeActive_vm_miss tok sto account) (eq_trans (t6_isEscapeActive_vm_miss tok sto account) (eq_trans (t7_isEscapeActive_vm_miss tok sto account) (eq_trans (t8_isEscapeActive_vm_miss tok sto account) (eq_trans (t9_isEscapeActive_vm_miss tok sto account) (eq_trans (t10_isEscapeActive_vm_miss tok sto account) (eq_trans (t11_isEscapeActive_vm_miss tok sto account H) (eq_trans (t12_isEscapeActive_vm_miss tok sto account) (eq_trans (t13_isEscapeActive_vm_miss tok sto account) (eq_trans (t14_isEscapeActive_vm_miss tok sto account) (eq_trans (t15_isEscapeActive_vm_miss tok sto account) (eq_trans (t16_isEscapeActive_vm_miss tok sto account) (eq_trans (t17_isEscapeActive_vm_miss tok sto account) (t18_isEscapeActive_vm_miss tok sto account))))))))))))))))))).
 - apply isEscapeActive_source_miss with (sto := sto) (account := account)
     (tok := tok). exact H.
Qed.
Print Assumptions isEscapeActive_vm_miss.
Theorem isEscapeActive_vm_hit : forall (tok : nat -> GVal -> GVal) sto account payload xs z,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 4%nat = Some (GInt z) ->
 run 31 0 isEscapeActive_vm_code (isEscapeActive_vm_init tok sto account) = Done (GBool (Z.ltb 0 z)) /\
 escape_active_outcome tok sto account = OK (GBool (Z.ltb 0 z)).
Proof.
 intros tok sto account payload xs z H Htok Hnth. split.
 - exact (eq_trans (t0_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t1_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t2_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t3_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t4_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t5_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t6_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t7_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t8_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t9_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t10_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t11_isEscapeActive_vm_hit tok sto account payload xs z H) (eq_trans (t12_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t13_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t14_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t15_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t16_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t17_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t18_isEscapeActive_vm_hit tok sto account payload xs z Htok) (eq_trans (t19_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t20_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t21_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t22_isEscapeActive_vm_hit tok sto account payload xs z Hnth) (eq_trans (t23_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t24_isEscapeActive_vm_hit tok sto account payload xs z) (eq_trans (t25_isEscapeActive_vm_hit tok sto account payload xs z) (t26_isEscapeActive_vm_hit tok sto account payload xs z))))))))))))))))))))))))))).
 - apply isEscapeActive_source_hit with (payload := payload) (xs := xs) (z := z); assumption.
Qed.
Print Assumptions isEscapeActive_vm_hit.
