From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageMutant3.
Example mutant_matches_original : mutant_binding fixture_storage [3%nat] =
 original_binding fixture_storage [3%nat].
Proof. reflexivity. Qed.
