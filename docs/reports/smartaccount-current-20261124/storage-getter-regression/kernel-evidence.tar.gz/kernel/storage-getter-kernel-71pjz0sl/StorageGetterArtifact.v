From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Definition account_state_prefix : bytes := [1%nat].
Definition account_state_outcome (tok : nat -> GVal -> GVal) (i : nat)
  (sto : storage) (account : bytes) : Outcome :=
  match sto (account_state_prefix ++ account) with
  | None => Fault
  | Some payload =>
      match tok 4%nat (GBytes payload) with
      | GArray xs => match nth_error xs i with
                     | Some v => OK v
                     | None => Fault
                     end
      | _ => Fault
      end
  end.
Definition getAdminTransferAvailableAt_prefix : bytes := [22%nat].
Definition getAdminTransferAvailableAt_decode (b : bytes) : Outcome :=
 match decode_integer b with
 | OK (GInt v) => if integer_fitsb (v + 604800000%Z) then OK (GInt (v + 604800000%Z)) else Fault
 | OK _ => Fault
 | Fault => Fault
 end.
Definition getAdminTransferAvailableAt_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getAdminTransferAvailableAt_prefix (GInt 0%Z) getAdminTransferAvailableAt_decode sto account.
Theorem getAdminTransferAvailableAt_missing_key_default : forall sto account,
 sto (getAdminTransferAvailableAt_prefix ++ account) = None ->
 getAdminTransferAvailableAt_binding sto account = OK (GInt 0%Z).
Proof. intros sto account H. unfold getAdminTransferAvailableAt_binding, getter_outcome.
 rewrite H. reflexivity. Qed.
Print Assumptions getAdminTransferAvailableAt_missing_key_default.
Theorem getAdminTransferAvailableAt_present_key_offsets : forall sto account payload value,
 sto (getAdminTransferAvailableAt_prefix ++ account) = Some payload ->
 decode_integer payload = OK (GInt value) -> integer_fitsb (value + 604800000%Z) = true ->
 getAdminTransferAvailableAt_binding sto account = OK (GInt (value + 604800000%Z)).
Proof. intros sto account payload value Hstore Hdecode Hsum.
 unfold getAdminTransferAvailableAt_binding, getter_outcome, getAdminTransferAvailableAt_decode.
 rewrite Hstore, Hdecode, Hsum. reflexivity. Qed.
Print Assumptions getAdminTransferAvailableAt_present_key_offsets.
Theorem getBackupOwner_source_miss : forall tok sto account,
 sto (account_state_prefix ++ account) = None ->
 account_state_outcome tok 2 sto account = Fault.
Proof. intros tok sto account H. unfold account_state_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getBackupOwner_source_miss.
Theorem getBackupOwner_source_hit : forall tok sto account payload xs v,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 2 = Some v ->
 account_state_outcome tok 2 sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold account_state_outcome. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getBackupOwner_source_hit.
Definition getContractAdmin_prefix : bytes := [17%nat].
Definition getContractAdmin_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getContractAdmin_prefix (GBytes hash160_default) decode_hash160 sto account.
Theorem getContractAdmin_missing_key_default : forall sto,
 sto (getContractAdmin_prefix) = None ->
 getContractAdmin_binding sto [] = OK (GBytes hash160_default).
Proof. intros sto H. unfold getContractAdmin_binding, getter_outcome. rewrite app_nil_r, H. reflexivity. Qed.
Print Assumptions getContractAdmin_missing_key_default.
Theorem getContractAdmin_present_key_decodes : forall sto payload,
 sto (getContractAdmin_prefix) = Some payload ->
 getContractAdmin_binding sto [] = match decode_hash160 payload with OK v => OK v | Fault => Fault end.
Proof. intros sto payload H. unfold getContractAdmin_binding, getter_outcome. rewrite app_nil_r, H. reflexivity. Qed.
Print Assumptions getContractAdmin_present_key_decodes.
Theorem getContractAdmin_short_payload_faults : forall sto payload,
 sto (getContractAdmin_prefix) = Some payload ->
 (length payload <> 20)%nat ->
 getContractAdmin_binding sto [] = Fault.
Proof. intros sto payload Hstore Hlen.
 unfold getContractAdmin_binding, getter_outcome, decode_hash160. rewrite app_nil_r, Hstore.
 destruct (valid_bytes payload); simpl.
 - apply Nat.eqb_neq in Hlen. rewrite Hlen. reflexivity.
 - reflexivity. Qed.
Print Assumptions getContractAdmin_short_payload_faults.
Theorem getEscapeTimelock_source_miss : forall tok sto account,
 sto (account_state_prefix ++ account) = None ->
 account_state_outcome tok 3 sto account = Fault.
Proof. intros tok sto account H. unfold account_state_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getEscapeTimelock_source_miss.
Theorem getEscapeTimelock_source_hit : forall tok sto account payload xs v,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 3 = Some v ->
 account_state_outcome tok 3 sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold account_state_outcome. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getEscapeTimelock_source_hit.
Theorem getEscapeTriggeredAt_source_miss : forall tok sto account,
 sto (account_state_prefix ++ account) = None ->
 account_state_outcome tok 4 sto account = Fault.
Proof. intros tok sto account H. unfold account_state_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getEscapeTriggeredAt_source_miss.
Theorem getEscapeTriggeredAt_source_hit : forall tok sto account payload xs v,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 4 = Some v ->
 account_state_outcome tok 4 sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold account_state_outcome. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getEscapeTriggeredAt_source_hit.
Theorem getHook_source_miss : forall tok sto account,
 sto (account_state_prefix ++ account) = None ->
 account_state_outcome tok 1 sto account = Fault.
Proof. intros tok sto account H. unfold account_state_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getHook_source_miss.
Theorem getHook_source_hit : forall tok sto account payload xs v,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 1 = Some v ->
 account_state_outcome tok 1 sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold account_state_outcome. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getHook_source_hit.
Definition getMarketEscrowContract_prefix : bytes := [6%nat].
Definition getMarketEscrowContract_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getMarketEscrowContract_prefix (GBytes hash160_default) decode_hash160 sto account.
Theorem getMarketEscrowContract_missing_key_default : forall sto account,
 sto (getMarketEscrowContract_prefix ++ account) = None ->
 getMarketEscrowContract_binding sto account = OK (GBytes hash160_default).
Proof. intros sto account H. unfold getMarketEscrowContract_binding, getter_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getMarketEscrowContract_missing_key_default.
Theorem getMarketEscrowContract_present_key_decodes : forall sto account payload,
 sto (getMarketEscrowContract_prefix ++ account) = Some payload ->
 getMarketEscrowContract_binding sto account = match decode_hash160 payload with OK v => OK v | Fault => Fault end.
Proof. intros sto account payload H. unfold getMarketEscrowContract_binding, getter_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getMarketEscrowContract_present_key_decodes.
Theorem getMarketEscrowContract_short_payload_faults : forall sto account payload,
 sto (getMarketEscrowContract_prefix ++ account) = Some payload ->
 (length payload <> 20)%nat ->
 getMarketEscrowContract_binding sto account = Fault.
Proof. intros sto account payload Hstore Hlen.
 unfold getMarketEscrowContract_binding, getter_outcome, decode_hash160. rewrite Hstore.
 destruct (valid_bytes payload); simpl.
 - apply Nat.eqb_neq in Hlen. rewrite Hlen. reflexivity.
 - reflexivity. Qed.
Print Assumptions getMarketEscrowContract_short_payload_faults.
Definition getMarketEscrowListingId_prefix : bytes := [7%nat].
Definition getMarketEscrowListingId_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getMarketEscrowListingId_prefix (GInt 0%Z) decode_integer sto account.
Theorem getMarketEscrowListingId_missing_key_default : forall sto account,
 sto (getMarketEscrowListingId_prefix ++ account) = None ->
 getMarketEscrowListingId_binding sto account = OK (GInt 0%Z).
Proof. intros sto account H. unfold getMarketEscrowListingId_binding, getter_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getMarketEscrowListingId_missing_key_default.
Theorem getMarketEscrowListingId_present_key_decodes : forall sto account payload,
 sto (getMarketEscrowListingId_prefix ++ account) = Some payload ->
 getMarketEscrowListingId_binding sto account = match decode_integer payload with OK v => OK v | Fault => Fault end.
Proof. intros sto account payload H. unfold getMarketEscrowListingId_binding, getter_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getMarketEscrowListingId_present_key_decodes.
Theorem getMarketEscrowListingId_zero_payload_is_zero : forall sto account,
 sto (getMarketEscrowListingId_prefix ++ account) = Some [] ->
 getMarketEscrowListingId_binding sto account = OK (GInt 0).
Proof. intros sto account H. unfold getMarketEscrowListingId_binding, getter_outcome, decode_integer.
 rewrite H. simpl. reflexivity. Qed.
Print Assumptions getMarketEscrowListingId_zero_payload_is_zero.
Definition getMarketEscrowOwnerCancelTime_prefix : bytes := [29%nat].
Definition getMarketEscrowOwnerCancelTime_decode (b : bytes) : Outcome :=
 match decode_integer b with
 | OK (GInt v) => if integer_fitsb (v + 604800000%Z) then OK (GInt (v + 604800000%Z)) else Fault
 | OK _ => Fault
 | Fault => Fault
 end.
Definition getMarketEscrowOwnerCancelTime_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getMarketEscrowOwnerCancelTime_prefix (GInt 0%Z) getMarketEscrowOwnerCancelTime_decode sto account.
Theorem getMarketEscrowOwnerCancelTime_source_miss : forall sto account,
 sto (getMarketEscrowOwnerCancelTime_prefix ++ account) = None ->
 getMarketEscrowOwnerCancelTime_binding sto account = OK (GInt 0%Z).
Proof. intros sto account H. unfold getMarketEscrowOwnerCancelTime_binding, getter_outcome.
 rewrite H. reflexivity. Qed.
Print Assumptions getMarketEscrowOwnerCancelTime_source_miss.
Theorem getMarketEscrowOwnerCancelTime_source_hit : forall sto account payload value,
 sto (getMarketEscrowOwnerCancelTime_prefix ++ account) = Some payload ->
 decode_integer payload = OK (GInt value) -> integer_fitsb (value + 604800000%Z) = true ->
 getMarketEscrowOwnerCancelTime_binding sto account = OK (GInt (value + 604800000%Z)).
Proof. intros sto account payload value Hstore Hdecode Hsum.
 unfold getMarketEscrowOwnerCancelTime_binding, getter_outcome, getMarketEscrowOwnerCancelTime_decode.
 rewrite Hstore, Hdecode, Hsum. reflexivity. Qed.
Print Assumptions getMarketEscrowOwnerCancelTime_source_hit.
Definition getMetadataUri_prefix : bytes := [12%nat].
Definition getMetadataUri_decode (b : bytes) : Outcome := OK (GBytes b).
Definition getMetadataUri_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getMetadataUri_prefix (GBytes []) getMetadataUri_decode sto account.
Theorem getMetadataUri_missing_key_default : forall sto account,
 sto (getMetadataUri_prefix ++ account) = None ->
 getMetadataUri_binding sto account = OK (GBytes []).
Proof. intros sto account H. unfold getMetadataUri_binding, getter_outcome.
 rewrite H. reflexivity. Qed.
Print Assumptions getMetadataUri_missing_key_default.
Theorem getMetadataUri_present_key_verbatim : forall sto account payload,
 sto (getMetadataUri_prefix ++ account) = Some payload ->
 getMetadataUri_binding sto account = OK (GBytes payload).
Proof. intros sto account payload H. unfold getMetadataUri_binding, getter_outcome, getMetadataUri_decode.
 rewrite H. reflexivity. Qed.
Print Assumptions getMetadataUri_present_key_verbatim.
Definition getPendingContractAdmin_prefix : bytes := [21%nat].
Definition getPendingContractAdmin_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getPendingContractAdmin_prefix (GBytes hash160_default) decode_hash160 sto account.
Theorem getPendingContractAdmin_missing_key_default : forall sto,
 sto (getPendingContractAdmin_prefix) = None ->
 getPendingContractAdmin_binding sto [] = OK (GBytes hash160_default).
Proof. intros sto H. unfold getPendingContractAdmin_binding, getter_outcome. rewrite app_nil_r, H. reflexivity. Qed.
Print Assumptions getPendingContractAdmin_missing_key_default.
Theorem getPendingContractAdmin_present_key_decodes : forall sto payload,
 sto (getPendingContractAdmin_prefix) = Some payload ->
 getPendingContractAdmin_binding sto [] = match decode_hash160 payload with OK v => OK v | Fault => Fault end.
Proof. intros sto payload H. unfold getPendingContractAdmin_binding, getter_outcome. rewrite app_nil_r, H. reflexivity. Qed.
Print Assumptions getPendingContractAdmin_present_key_decodes.
Theorem getPendingContractAdmin_short_payload_faults : forall sto payload,
 sto (getPendingContractAdmin_prefix) = Some payload ->
 (length payload <> 20)%nat ->
 getPendingContractAdmin_binding sto [] = Fault.
Proof. intros sto payload Hstore Hlen.
 unfold getPendingContractAdmin_binding, getter_outcome, decode_hash160. rewrite app_nil_r, Hstore.
 destruct (valid_bytes payload); simpl.
 - apply Nat.eqb_neq in Hlen. rewrite Hlen. reflexivity.
 - reflexivity. Qed.
Print Assumptions getPendingContractAdmin_short_payload_faults.
Definition getPendingHookCallHash_prefix : bytes := [16%nat].
Definition getPendingHookCallHash_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (getPendingHookCallHash_prefix ++ account) with
 | None => OK (GBytes [])
 | Some payload =>
     match tok 4%nat (GBytes payload) with
     | GArray xs => match nth_error xs 1 with
                     | Some v => OK v
                     | None => Fault
                     end
     | _ => Fault
     end
 end.
Theorem getPendingHookCallHash_source_miss : forall tok sto account,
 sto (getPendingHookCallHash_prefix ++ account) = None ->
 getPendingHookCallHash_binding tok sto account = OK (GBytes []).
Proof. intros tok sto account H. unfold getPendingHookCallHash_binding. rewrite H. reflexivity. Qed.
Print Assumptions getPendingHookCallHash_source_miss.
Theorem getPendingHookCallHash_source_hit : forall tok sto account payload xs v,
 sto (getPendingHookCallHash_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 1 = Some v ->
 
 getPendingHookCallHash_binding tok sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold getPendingHookCallHash_binding. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getPendingHookCallHash_source_hit.
Definition getPendingHookCallModule_prefix : bytes := [16%nat].
Definition getPendingHookCallModule_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (getPendingHookCallModule_prefix ++ account) with
 | None => OK (GBytes hash160_default)
 | Some payload =>
     match tok 4%nat (GBytes payload) with
     | GArray xs => match nth_error xs 0 with
                     | Some v => OK v
                     | None => Fault
                     end
     | _ => Fault
     end
 end.
Theorem getPendingHookCallModule_source_miss : forall tok sto account,
 sto (getPendingHookCallModule_prefix ++ account) = None ->
 getPendingHookCallModule_binding tok sto account = OK (GBytes hash160_default).
Proof. intros tok sto account H. unfold getPendingHookCallModule_binding. rewrite H. reflexivity. Qed.
Print Assumptions getPendingHookCallModule_source_miss.
Theorem getPendingHookCallModule_source_hit : forall tok sto account payload xs v,
 sto (getPendingHookCallModule_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 0 = Some v ->
 
 getPendingHookCallModule_binding tok sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold getPendingHookCallModule_binding. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getPendingHookCallModule_source_hit.
Definition getPendingHookCallTime_prefix : bytes := [16%nat].
Definition getPendingHookCallTime_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (getPendingHookCallTime_prefix ++ account) with
 | None => OK (GInt 0%Z)
 | Some payload =>
     match tok 4%nat (GBytes payload) with
     | GArray xs => match nth_error xs 2 with
                     | Some (GInt z) => if integer_fitsb (z + 86400000%Z) then OK (GInt (z + 86400000%Z)) else Fault
                     | Some _ => Fault
                     | None => Fault
                     end
     | _ => Fault
     end
 end.
Theorem getPendingHookCallTime_source_miss : forall tok sto account,
 sto (getPendingHookCallTime_prefix ++ account) = None ->
 getPendingHookCallTime_binding tok sto account = OK (GInt 0%Z).
Proof. intros tok sto account H. unfold getPendingHookCallTime_binding. rewrite H. reflexivity. Qed.
Print Assumptions getPendingHookCallTime_source_miss.
Theorem getPendingHookCallTime_source_hit : forall tok sto account payload xs z,
 sto (getPendingHookCallTime_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 2 = Some (GInt z) ->
 integer_fitsb (z + 86400000%Z) = true ->
 getPendingHookCallTime_binding tok sto account = OK (GInt (z + 86400000%Z)).
Proof. intros tok sto account payload xs z H Htok Hnth Hsum.
 unfold getPendingHookCallTime_binding. rewrite H, Htok, Hnth, Hsum. reflexivity. Qed.
Print Assumptions getPendingHookCallTime_source_hit.
Definition getPendingHookUpdateTime_prefix : bytes := [10%nat].
Definition getPendingHookUpdateTime_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (getPendingHookUpdateTime_prefix ++ account) with
 | None => OK (GInt 0%Z)
 | Some payload =>
     match tok 4%nat (GBytes payload) with
     | GArray xs => match nth_error xs 3 with
                     | Some (GInt z) => if integer_fitsb (z + 86400000%Z) then OK (GInt (z + 86400000%Z)) else Fault
                     | Some _ => Fault
                     | None => Fault
                     end
     | _ => Fault
     end
 end.
Theorem getPendingHookUpdateTime_source_miss : forall tok sto account,
 sto (getPendingHookUpdateTime_prefix ++ account) = None ->
 getPendingHookUpdateTime_binding tok sto account = OK (GInt 0%Z).
Proof. intros tok sto account H. unfold getPendingHookUpdateTime_binding. rewrite H. reflexivity. Qed.
Print Assumptions getPendingHookUpdateTime_source_miss.
Theorem getPendingHookUpdateTime_source_hit : forall tok sto account payload xs z,
 sto (getPendingHookUpdateTime_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 3 = Some (GInt z) ->
 integer_fitsb (z + 86400000%Z) = true ->
 getPendingHookUpdateTime_binding tok sto account = OK (GInt (z + 86400000%Z)).
Proof. intros tok sto account payload xs z H Htok Hnth Hsum.
 unfold getPendingHookUpdateTime_binding. rewrite H, Htok, Hnth, Hsum. reflexivity. Qed.
Print Assumptions getPendingHookUpdateTime_source_hit.
Definition getPendingPlatformRegistrar_prefix : bytes := [24%nat].
Definition getPendingPlatformRegistrar_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getPendingPlatformRegistrar_prefix (GBytes hash160_default) decode_hash160 sto account.
Theorem getPendingPlatformRegistrar_missing_key_default : forall sto,
 sto (getPendingPlatformRegistrar_prefix) = None ->
 getPendingPlatformRegistrar_binding sto [] = OK (GBytes hash160_default).
Proof. intros sto H. unfold getPendingPlatformRegistrar_binding, getter_outcome. rewrite app_nil_r, H. reflexivity. Qed.
Print Assumptions getPendingPlatformRegistrar_missing_key_default.
Theorem getPendingPlatformRegistrar_present_key_decodes : forall sto payload,
 sto (getPendingPlatformRegistrar_prefix) = Some payload ->
 getPendingPlatformRegistrar_binding sto [] = match decode_hash160 payload with OK v => OK v | Fault => Fault end.
Proof. intros sto payload H. unfold getPendingPlatformRegistrar_binding, getter_outcome. rewrite app_nil_r, H. reflexivity. Qed.
Print Assumptions getPendingPlatformRegistrar_present_key_decodes.
Theorem getPendingPlatformRegistrar_short_payload_faults : forall sto payload,
 sto (getPendingPlatformRegistrar_prefix) = Some payload ->
 (length payload <> 20)%nat ->
 getPendingPlatformRegistrar_binding sto [] = Fault.
Proof. intros sto payload Hstore Hlen.
 unfold getPendingPlatformRegistrar_binding, getter_outcome, decode_hash160. rewrite app_nil_r, Hstore.
 destruct (valid_bytes payload); simpl.
 - apply Nat.eqb_neq in Hlen. rewrite Hlen. reflexivity.
 - reflexivity. Qed.
Print Assumptions getPendingPlatformRegistrar_short_payload_faults.
Definition getPendingVerifierCallHash_prefix : bytes := [15%nat].
Definition getPendingVerifierCallHash_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (getPendingVerifierCallHash_prefix ++ account) with
 | None => OK (GBytes [])
 | Some payload =>
     match tok 4%nat (GBytes payload) with
     | GArray xs => match nth_error xs 1 with
                     | Some v => OK v
                     | None => Fault
                     end
     | _ => Fault
     end
 end.
Theorem getPendingVerifierCallHash_source_miss : forall tok sto account,
 sto (getPendingVerifierCallHash_prefix ++ account) = None ->
 getPendingVerifierCallHash_binding tok sto account = OK (GBytes []).
Proof. intros tok sto account H. unfold getPendingVerifierCallHash_binding. rewrite H. reflexivity. Qed.
Print Assumptions getPendingVerifierCallHash_source_miss.
Theorem getPendingVerifierCallHash_source_hit : forall tok sto account payload xs v,
 sto (getPendingVerifierCallHash_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 1 = Some v ->
 
 getPendingVerifierCallHash_binding tok sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold getPendingVerifierCallHash_binding. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getPendingVerifierCallHash_source_hit.
Definition getPendingVerifierCallModule_prefix : bytes := [15%nat].
Definition getPendingVerifierCallModule_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (getPendingVerifierCallModule_prefix ++ account) with
 | None => OK (GBytes hash160_default)
 | Some payload =>
     match tok 4%nat (GBytes payload) with
     | GArray xs => match nth_error xs 0 with
                     | Some v => OK v
                     | None => Fault
                     end
     | _ => Fault
     end
 end.
Theorem getPendingVerifierCallModule_source_miss : forall tok sto account,
 sto (getPendingVerifierCallModule_prefix ++ account) = None ->
 getPendingVerifierCallModule_binding tok sto account = OK (GBytes hash160_default).
Proof. intros tok sto account H. unfold getPendingVerifierCallModule_binding. rewrite H. reflexivity. Qed.
Print Assumptions getPendingVerifierCallModule_source_miss.
Theorem getPendingVerifierCallModule_source_hit : forall tok sto account payload xs v,
 sto (getPendingVerifierCallModule_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 0 = Some v ->
 
 getPendingVerifierCallModule_binding tok sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold getPendingVerifierCallModule_binding. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getPendingVerifierCallModule_source_hit.
Definition getPendingVerifierCallTime_prefix : bytes := [15%nat].
Definition getPendingVerifierCallTime_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (getPendingVerifierCallTime_prefix ++ account) with
 | None => OK (GInt 0%Z)
 | Some payload =>
     match tok 4%nat (GBytes payload) with
     | GArray xs => match nth_error xs 2 with
                     | Some (GInt z) => if integer_fitsb (z + 86400000%Z) then OK (GInt (z + 86400000%Z)) else Fault
                     | Some _ => Fault
                     | None => Fault
                     end
     | _ => Fault
     end
 end.
Theorem getPendingVerifierCallTime_source_miss : forall tok sto account,
 sto (getPendingVerifierCallTime_prefix ++ account) = None ->
 getPendingVerifierCallTime_binding tok sto account = OK (GInt 0%Z).
Proof. intros tok sto account H. unfold getPendingVerifierCallTime_binding. rewrite H. reflexivity. Qed.
Print Assumptions getPendingVerifierCallTime_source_miss.
Theorem getPendingVerifierCallTime_source_hit : forall tok sto account payload xs z,
 sto (getPendingVerifierCallTime_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 2 = Some (GInt z) ->
 integer_fitsb (z + 86400000%Z) = true ->
 getPendingVerifierCallTime_binding tok sto account = OK (GInt (z + 86400000%Z)).
Proof. intros tok sto account payload xs z H Htok Hnth Hsum.
 unfold getPendingVerifierCallTime_binding. rewrite H, Htok, Hnth, Hsum. reflexivity. Qed.
Print Assumptions getPendingVerifierCallTime_source_hit.
Definition getPendingVerifierUpdateTime_prefix : bytes := [9%nat].
Definition getPendingVerifierUpdateTime_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (getPendingVerifierUpdateTime_prefix ++ account) with
 | None => OK (GInt 0%Z)
 | Some payload =>
     match tok 4%nat (GBytes payload) with
     | GArray xs => match nth_error xs 3 with
                     | Some (GInt z) => if integer_fitsb (z + 86400000%Z) then OK (GInt (z + 86400000%Z)) else Fault
                     | Some _ => Fault
                     | None => Fault
                     end
     | _ => Fault
     end
 end.
Theorem getPendingVerifierUpdateTime_source_miss : forall tok sto account,
 sto (getPendingVerifierUpdateTime_prefix ++ account) = None ->
 getPendingVerifierUpdateTime_binding tok sto account = OK (GInt 0%Z).
Proof. intros tok sto account H. unfold getPendingVerifierUpdateTime_binding. rewrite H. reflexivity. Qed.
Print Assumptions getPendingVerifierUpdateTime_source_miss.
Theorem getPendingVerifierUpdateTime_source_hit : forall tok sto account payload xs z,
 sto (getPendingVerifierUpdateTime_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 3 = Some (GInt z) ->
 integer_fitsb (z + 86400000%Z) = true ->
 getPendingVerifierUpdateTime_binding tok sto account = OK (GInt (z + 86400000%Z)).
Proof. intros tok sto account payload xs z H Htok Hnth Hsum.
 unfold getPendingVerifierUpdateTime_binding. rewrite H, Htok, Hnth, Hsum. reflexivity. Qed.
Print Assumptions getPendingVerifierUpdateTime_source_hit.
Definition getPlatformRegistrar_prefix : bytes := [23%nat].
Definition getPlatformRegistrar_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getPlatformRegistrar_prefix (GBytes hash160_default) decode_hash160 sto account.
Theorem getPlatformRegistrar_missing_key_default : forall sto,
 sto (getPlatformRegistrar_prefix) = None ->
 getPlatformRegistrar_binding sto [] = OK (GBytes hash160_default).
Proof. intros sto H. unfold getPlatformRegistrar_binding, getter_outcome. rewrite app_nil_r, H. reflexivity. Qed.
Print Assumptions getPlatformRegistrar_missing_key_default.
Theorem getPlatformRegistrar_present_key_decodes : forall sto payload,
 sto (getPlatformRegistrar_prefix) = Some payload ->
 getPlatformRegistrar_binding sto [] = match decode_hash160 payload with OK v => OK v | Fault => Fault end.
Proof. intros sto payload H. unfold getPlatformRegistrar_binding, getter_outcome. rewrite app_nil_r, H. reflexivity. Qed.
Print Assumptions getPlatformRegistrar_present_key_decodes.
Theorem getPlatformRegistrar_short_payload_faults : forall sto payload,
 sto (getPlatformRegistrar_prefix) = Some payload ->
 (length payload <> 20)%nat ->
 getPlatformRegistrar_binding sto [] = Fault.
Proof. intros sto payload Hstore Hlen.
 unfold getPlatformRegistrar_binding, getter_outcome, decode_hash160. rewrite app_nil_r, Hstore.
 destruct (valid_bytes payload); simpl.
 - apply Nat.eqb_neq in Hlen. rewrite Hlen. reflexivity.
 - reflexivity. Qed.
Print Assumptions getPlatformRegistrar_short_payload_faults.
Definition getPlatformRegistrarAvailableAt_prefix : bytes := [25%nat].
Definition getPlatformRegistrarAvailableAt_decode (b : bytes) : Outcome :=
 match decode_integer b with
 | OK (GInt v) => if integer_fitsb (v + 604800000%Z) then OK (GInt (v + 604800000%Z)) else Fault
 | OK _ => Fault
 | Fault => Fault
 end.
Definition getPlatformRegistrarAvailableAt_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getPlatformRegistrarAvailableAt_prefix (GInt 0%Z) getPlatformRegistrarAvailableAt_decode sto account.
Theorem getPlatformRegistrarAvailableAt_missing_key_default : forall sto account,
 sto (getPlatformRegistrarAvailableAt_prefix ++ account) = None ->
 getPlatformRegistrarAvailableAt_binding sto account = OK (GInt 0%Z).
Proof. intros sto account H. unfold getPlatformRegistrarAvailableAt_binding, getter_outcome.
 rewrite H. reflexivity. Qed.
Print Assumptions getPlatformRegistrarAvailableAt_missing_key_default.
Theorem getPlatformRegistrarAvailableAt_present_key_offsets : forall sto account payload value,
 sto (getPlatformRegistrarAvailableAt_prefix ++ account) = Some payload ->
 decode_integer payload = OK (GInt value) -> integer_fitsb (value + 604800000%Z) = true ->
 getPlatformRegistrarAvailableAt_binding sto account = OK (GInt (value + 604800000%Z)).
Proof. intros sto account payload value Hstore Hdecode Hsum.
 unfold getPlatformRegistrarAvailableAt_binding, getter_outcome, getPlatformRegistrarAvailableAt_decode.
 rewrite Hstore, Hdecode, Hsum. reflexivity. Qed.
Print Assumptions getPlatformRegistrarAvailableAt_present_key_offsets.
Theorem getVerifier_source_miss : forall tok sto account,
 sto (account_state_prefix ++ account) = None ->
 account_state_outcome tok 0 sto account = Fault.
Proof. intros tok sto account H. unfold account_state_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getVerifier_source_miss.
Theorem getVerifier_source_hit : forall tok sto account payload xs v,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 0 = Some v ->
 account_state_outcome tok 0 sto account = OK v.
Proof. intros tok sto account payload xs v H Htok Hnth.
 unfold account_state_outcome. rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions getVerifier_source_hit.
Definition getVerifyScopeTarget_prefix : bytes := [28%nat].
Definition getVerifyScopeTarget_binding (sto : storage) (account : bytes) : Outcome :=
 getter_outcome getVerifyScopeTarget_prefix (GBytes hash160_default) decode_hash160 sto account.
Theorem getVerifyScopeTarget_missing_key_default : forall sto account,
 sto (getVerifyScopeTarget_prefix ++ account) = None ->
 getVerifyScopeTarget_binding sto account = OK (GBytes hash160_default).
Proof. intros sto account H. unfold getVerifyScopeTarget_binding, getter_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getVerifyScopeTarget_missing_key_default.
Theorem getVerifyScopeTarget_present_key_decodes : forall sto account payload,
 sto (getVerifyScopeTarget_prefix ++ account) = Some payload ->
 getVerifyScopeTarget_binding sto account = match decode_hash160 payload with OK v => OK v | Fault => Fault end.
Proof. intros sto account payload H. unfold getVerifyScopeTarget_binding, getter_outcome. rewrite H. reflexivity. Qed.
Print Assumptions getVerifyScopeTarget_present_key_decodes.
Theorem getVerifyScopeTarget_short_payload_faults : forall sto account payload,
 sto (getVerifyScopeTarget_prefix ++ account) = Some payload ->
 (length payload <> 20)%nat ->
 getVerifyScopeTarget_binding sto account = Fault.
Proof. intros sto account payload Hstore Hlen.
 unfold getVerifyScopeTarget_binding, getter_outcome, decode_hash160. rewrite Hstore.
 destruct (valid_bytes payload); simpl.
 - apply Nat.eqb_neq in Hlen. rewrite Hlen. reflexivity.
 - reflexivity. Qed.
Print Assumptions getVerifyScopeTarget_short_payload_faults.
Definition hasMarketEscrowOwnerCancel_prefix : bytes := [29%nat].
Definition hasMarketEscrowOwnerCancel_reader (sto : storage) (account : bytes) : GVal :=
 match sto (hasMarketEscrowOwnerCancel_prefix ++ account) with
 | None => GNull
 | Some payload => GBytes payload
 end.
Definition hasMarketEscrowOwnerCancel_binding (sto : storage) (account : bytes) : Outcome :=
 OK (GBool (negb (gval_eqb GNull (hasMarketEscrowOwnerCancel_reader sto account)))).
Theorem hasMarketEscrowOwnerCancel_source_miss : forall sto account,
 sto (hasMarketEscrowOwnerCancel_prefix ++ account) = None ->
 hasMarketEscrowOwnerCancel_binding sto account = OK (GBool false).
Proof. intros sto account Hstore.
 unfold hasMarketEscrowOwnerCancel_binding, hasMarketEscrowOwnerCancel_reader. rewrite Hstore. reflexivity. Qed.
Print Assumptions hasMarketEscrowOwnerCancel_source_miss.
Theorem hasMarketEscrowOwnerCancel_source_hit : forall sto account payload,
 sto (hasMarketEscrowOwnerCancel_prefix ++ account) = Some payload ->
 hasMarketEscrowOwnerCancel_binding sto account = OK (GBool true).
Proof. intros sto account payload Hstore.
 unfold hasMarketEscrowOwnerCancel_binding, hasMarketEscrowOwnerCancel_reader. rewrite Hstore. reflexivity. Qed.
Print Assumptions hasMarketEscrowOwnerCancel_source_hit.
Definition hasPendingHookCall_prefix : bytes := [16%nat].
Definition hasPendingHookCall_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (hasPendingHookCall_prefix ++ account) with
 | None => OK (GBool false)
 | Some payload =>
     OK (GBool (negb (gval_eqb GNull (tok 4%nat (GBytes payload)))))
 end.
Theorem hasPendingHookCall_source_miss : forall tok sto account,
 sto (hasPendingHookCall_prefix ++ account) = None ->
 hasPendingHookCall_binding tok sto account = OK (GBool false).
Proof. intros tok sto account H. unfold hasPendingHookCall_binding. rewrite H. reflexivity. Qed.
Print Assumptions hasPendingHookCall_source_miss.
Theorem hasPendingHookCall_source_hit : forall tok sto account payload,
 sto (hasPendingHookCall_prefix ++ account) = Some payload ->
 gval_eqb GNull (tok 4%nat (GBytes payload)) = false ->
 hasPendingHookCall_binding tok sto account = OK (GBool true).
Proof. intros tok sto account payload Hstore Hne.
 unfold hasPendingHookCall_binding. rewrite Hstore, Hne. reflexivity. Qed.
Print Assumptions hasPendingHookCall_source_hit.
Definition hasPendingHookUpdate_prefix : bytes := [10%nat].
Definition hasPendingHookUpdate_binding (sto : storage) (account : bytes) : Outcome :=
 match sto (hasPendingHookUpdate_prefix ++ account) with
 | None => OK (GBool false)
 | Some _ => OK (GBool true)
 end.
Theorem hasPendingHookUpdate_source_miss : forall sto account,
 sto (hasPendingHookUpdate_prefix ++ account) = None ->
 hasPendingHookUpdate_binding sto account = OK (GBool false).
Proof. intros sto account H. unfold hasPendingHookUpdate_binding. rewrite H. reflexivity. Qed.
Print Assumptions hasPendingHookUpdate_source_miss.
Theorem hasPendingHookUpdate_source_hit : forall sto account payload,
 sto (hasPendingHookUpdate_prefix ++ account) = Some payload ->
 hasPendingHookUpdate_binding sto account = OK (GBool true).
Proof. intros sto account payload H. unfold hasPendingHookUpdate_binding. rewrite H. reflexivity. Qed.
Print Assumptions hasPendingHookUpdate_source_hit.
Definition hasPendingVerifierCall_prefix : bytes := [15%nat].
Definition hasPendingVerifierCall_binding (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match sto (hasPendingVerifierCall_prefix ++ account) with
 | None => OK (GBool false)
 | Some payload =>
     OK (GBool (negb (gval_eqb GNull (tok 4%nat (GBytes payload)))))
 end.
Theorem hasPendingVerifierCall_source_miss : forall tok sto account,
 sto (hasPendingVerifierCall_prefix ++ account) = None ->
 hasPendingVerifierCall_binding tok sto account = OK (GBool false).
Proof. intros tok sto account H. unfold hasPendingVerifierCall_binding. rewrite H. reflexivity. Qed.
Print Assumptions hasPendingVerifierCall_source_miss.
Theorem hasPendingVerifierCall_source_hit : forall tok sto account payload,
 sto (hasPendingVerifierCall_prefix ++ account) = Some payload ->
 gval_eqb GNull (tok 4%nat (GBytes payload)) = false ->
 hasPendingVerifierCall_binding tok sto account = OK (GBool true).
Proof. intros tok sto account payload Hstore Hne.
 unfold hasPendingVerifierCall_binding. rewrite Hstore, Hne. reflexivity. Qed.
Print Assumptions hasPendingVerifierCall_source_hit.
Definition hasPendingVerifierUpdate_prefix : bytes := [9%nat].
Definition hasPendingVerifierUpdate_binding (sto : storage) (account : bytes) : Outcome :=
 match sto (hasPendingVerifierUpdate_prefix ++ account) with
 | None => OK (GBool false)
 | Some _ => OK (GBool true)
 end.
Theorem hasPendingVerifierUpdate_source_miss : forall sto account,
 sto (hasPendingVerifierUpdate_prefix ++ account) = None ->
 hasPendingVerifierUpdate_binding sto account = OK (GBool false).
Proof. intros sto account H. unfold hasPendingVerifierUpdate_binding. rewrite H. reflexivity. Qed.
Print Assumptions hasPendingVerifierUpdate_source_miss.
Theorem hasPendingVerifierUpdate_source_hit : forall sto account payload,
 sto (hasPendingVerifierUpdate_prefix ++ account) = Some payload ->
 hasPendingVerifierUpdate_binding sto account = OK (GBool true).
Proof. intros sto account payload H. unfold hasPendingVerifierUpdate_binding. rewrite H. reflexivity. Qed.
Print Assumptions hasPendingVerifierUpdate_source_hit.
Definition escape_active_outcome (tok : nat -> GVal -> GVal)
  (sto : storage) (account : bytes) : Outcome :=
 match account_state_outcome tok 4 sto account with
 | OK (GInt z) => OK (GBool (Z.ltb 0 z))
 | OK _ => Fault
 | Fault => Fault
 end.
Theorem isEscapeActive_source_miss : forall tok sto account,
 sto (account_state_prefix ++ account) = None ->
 escape_active_outcome tok sto account = Fault.
Proof. intros tok sto account H. unfold escape_active_outcome,
 account_state_outcome. rewrite H. reflexivity. Qed.
Print Assumptions isEscapeActive_source_miss.
Theorem isEscapeActive_source_hit : forall tok sto account payload xs z,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 4 = Some (GInt z) ->
 escape_active_outcome tok sto account = OK (GBool (Z.ltb 0 z)).
Proof. intros tok sto account payload xs z H Htok Hnth.
 unfold escape_active_outcome, account_state_outcome.
 rewrite H, Htok, Hnth. reflexivity. Qed.
Print Assumptions isEscapeActive_source_hit.
Definition isExecutionActive_prefix : bytes := [11%nat].
Definition isExecutionActive_binding (sto : storage) (account : bytes) : Outcome :=
 match sto (isExecutionActive_prefix ++ account) with
 | None => OK (GBool false)
 | Some _ => OK (GBool true)
 end.
Theorem isExecutionActive_source_miss : forall sto account,
 sto (isExecutionActive_prefix ++ account) = None ->
 isExecutionActive_binding sto account = OK (GBool false).
Proof. intros sto account H. unfold isExecutionActive_binding. rewrite H. reflexivity. Qed.
Print Assumptions isExecutionActive_source_miss.
Theorem isExecutionActive_source_hit : forall sto account payload,
 sto (isExecutionActive_prefix ++ account) = Some payload ->
 isExecutionActive_binding sto account = OK (GBool true).
Proof. intros sto account payload H. unfold isExecutionActive_binding. rewrite H. reflexivity. Qed.
Print Assumptions isExecutionActive_source_hit.
Theorem getter_prefixes_distinct : forall account,
 getAdminTransferAvailableAt_prefix ++ account <> getContractAdmin_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getMarketEscrowContract_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getMarketEscrowListingId_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getMarketEscrowOwnerCancelTime_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getMetadataUri_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getPendingContractAdmin_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getPendingHookCallHash_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getPendingHookUpdateTime_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> isExecutionActive_prefix ++ account /\ getAdminTransferAvailableAt_prefix ++ account <> account_state_prefix ++ account /\ getContractAdmin_prefix ++ account <> getMarketEscrowContract_prefix ++ account /\ getContractAdmin_prefix ++ account <> getMarketEscrowListingId_prefix ++ account /\ getContractAdmin_prefix ++ account <> getMarketEscrowOwnerCancelTime_prefix ++ account /\ getContractAdmin_prefix ++ account <> getMetadataUri_prefix ++ account /\ getContractAdmin_prefix ++ account <> getPendingContractAdmin_prefix ++ account /\ getContractAdmin_prefix ++ account <> getPendingHookCallHash_prefix ++ account /\ getContractAdmin_prefix ++ account <> getPendingHookUpdateTime_prefix ++ account /\ getContractAdmin_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getContractAdmin_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getContractAdmin_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getContractAdmin_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getContractAdmin_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getContractAdmin_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getContractAdmin_prefix ++ account <> isExecutionActive_prefix ++ account /\ getContractAdmin_prefix ++ account <> account_state_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getMarketEscrowListingId_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getMarketEscrowOwnerCancelTime_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getMetadataUri_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getPendingContractAdmin_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getPendingHookCallHash_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getPendingHookUpdateTime_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> isExecutionActive_prefix ++ account /\ getMarketEscrowContract_prefix ++ account <> account_state_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getMarketEscrowOwnerCancelTime_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getMetadataUri_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getPendingContractAdmin_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getPendingHookCallHash_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getPendingHookUpdateTime_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> isExecutionActive_prefix ++ account /\ getMarketEscrowListingId_prefix ++ account <> account_state_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getMetadataUri_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getPendingContractAdmin_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getPendingHookCallHash_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getPendingHookUpdateTime_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> isExecutionActive_prefix ++ account /\ getMarketEscrowOwnerCancelTime_prefix ++ account <> account_state_prefix ++ account /\ getMetadataUri_prefix ++ account <> getPendingContractAdmin_prefix ++ account /\ getMetadataUri_prefix ++ account <> getPendingHookCallHash_prefix ++ account /\ getMetadataUri_prefix ++ account <> getPendingHookUpdateTime_prefix ++ account /\ getMetadataUri_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getMetadataUri_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getMetadataUri_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getMetadataUri_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getMetadataUri_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getMetadataUri_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getMetadataUri_prefix ++ account <> isExecutionActive_prefix ++ account /\ getMetadataUri_prefix ++ account <> account_state_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> getPendingHookCallHash_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> getPendingHookUpdateTime_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> isExecutionActive_prefix ++ account /\ getPendingContractAdmin_prefix ++ account <> account_state_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> getPendingHookUpdateTime_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> isExecutionActive_prefix ++ account /\ getPendingHookCallHash_prefix ++ account <> account_state_prefix ++ account /\ getPendingHookUpdateTime_prefix ++ account <> getPendingPlatformRegistrar_prefix ++ account /\ getPendingHookUpdateTime_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getPendingHookUpdateTime_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getPendingHookUpdateTime_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getPendingHookUpdateTime_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getPendingHookUpdateTime_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getPendingHookUpdateTime_prefix ++ account <> isExecutionActive_prefix ++ account /\ getPendingHookUpdateTime_prefix ++ account <> account_state_prefix ++ account /\ getPendingPlatformRegistrar_prefix ++ account <> getPendingVerifierCallHash_prefix ++ account /\ getPendingPlatformRegistrar_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getPendingPlatformRegistrar_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getPendingPlatformRegistrar_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getPendingPlatformRegistrar_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getPendingPlatformRegistrar_prefix ++ account <> isExecutionActive_prefix ++ account /\ getPendingPlatformRegistrar_prefix ++ account <> account_state_prefix ++ account /\ getPendingVerifierCallHash_prefix ++ account <> getPendingVerifierUpdateTime_prefix ++ account /\ getPendingVerifierCallHash_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getPendingVerifierCallHash_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getPendingVerifierCallHash_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getPendingVerifierCallHash_prefix ++ account <> isExecutionActive_prefix ++ account /\ getPendingVerifierCallHash_prefix ++ account <> account_state_prefix ++ account /\ getPendingVerifierUpdateTime_prefix ++ account <> getPlatformRegistrar_prefix ++ account /\ getPendingVerifierUpdateTime_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getPendingVerifierUpdateTime_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getPendingVerifierUpdateTime_prefix ++ account <> isExecutionActive_prefix ++ account /\ getPendingVerifierUpdateTime_prefix ++ account <> account_state_prefix ++ account /\ getPlatformRegistrar_prefix ++ account <> getPlatformRegistrarAvailableAt_prefix ++ account /\ getPlatformRegistrar_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getPlatformRegistrar_prefix ++ account <> isExecutionActive_prefix ++ account /\ getPlatformRegistrar_prefix ++ account <> account_state_prefix ++ account /\ getPlatformRegistrarAvailableAt_prefix ++ account <> getVerifyScopeTarget_prefix ++ account /\ getPlatformRegistrarAvailableAt_prefix ++ account <> isExecutionActive_prefix ++ account /\ getPlatformRegistrarAvailableAt_prefix ++ account <> account_state_prefix ++ account /\ getVerifyScopeTarget_prefix ++ account <> isExecutionActive_prefix ++ account /\ getVerifyScopeTarget_prefix ++ account <> account_state_prefix ++ account /\ isExecutionActive_prefix ++ account <> account_state_prefix ++ account.
Proof. intros account. repeat split; discriminate. Qed.
Print Assumptions getter_prefixes_distinct.
