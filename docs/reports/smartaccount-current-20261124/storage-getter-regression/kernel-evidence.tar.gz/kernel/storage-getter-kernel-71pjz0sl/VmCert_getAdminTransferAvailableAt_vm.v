From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getAdminTransferAvailableAt_vm_program : list Ins :=
 [InitSlot 1 0; LdStatic 29; GetContext; StorageGet; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 11; Push (GInt 0); Jump 21; LdLoc 0; Dup; IsNull; JumpIfNot 18; Drop; Push (GInt 0); Jump 19; Convert 33; LdStatic 27; AddIns; Jump 22; Ret].
Definition getAdminTransferAvailableAt_vm_code (pc : nat) : Ins := nth pc getAdminTransferAvailableAt_vm_program Unsupported.
Definition getAdminTransferAvailableAt_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 29 then Some (GBytes getAdminTransferAvailableAt_prefix)
          else if Nat.eqb i 27 then Some (GInt 604800000%Z) else None.
Definition getAdminTransferAvailableAt_vm_init (sto : storage) : Machine :=
 machine [] (repeat GNull 1) [] getAdminTransferAvailableAt_vm_statics sto [] (fun _ _ => GNull).

Definition M0_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 getAdminTransferAvailableAt_vm_init sto.

Definition M1_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes getAdminTransferAvailableAt_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getAdminTransferAvailableAt_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBool true]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getAdminTransferAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 25 0 getAdminTransferAvailableAt_vm_code (M0_getAdminTransferAvailableAt_vm_miss sto) =
 run 24 1 getAdminTransferAvailableAt_vm_code (M1_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M0_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getAdminTransferAvailableAt_vm_miss.

Lemma t1_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 24 1 getAdminTransferAvailableAt_vm_code (M1_getAdminTransferAvailableAt_vm_miss sto) =
 run 23 2 getAdminTransferAvailableAt_vm_code (M2_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M1_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getAdminTransferAvailableAt_vm_miss.

Lemma t2_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 23 2 getAdminTransferAvailableAt_vm_code (M2_getAdminTransferAvailableAt_vm_miss sto) =
 run 22 3 getAdminTransferAvailableAt_vm_code (M3_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M2_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getAdminTransferAvailableAt_vm_miss.

Lemma t3_getAdminTransferAvailableAt_vm_miss : forall (sto : storage) (Hstore : sto (getAdminTransferAvailableAt_prefix) = None),
 run 22 3 getAdminTransferAvailableAt_vm_code (M3_getAdminTransferAvailableAt_vm_miss sto) =
 run 21 4 getAdminTransferAvailableAt_vm_code (M4_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto Hstore.
 rewrite run_S.
 cbn [M3_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getAdminTransferAvailableAt_vm_miss.

Lemma t4_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 21 4 getAdminTransferAvailableAt_vm_code (M4_getAdminTransferAvailableAt_vm_miss sto) =
 run 20 5 getAdminTransferAvailableAt_vm_code (M5_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M4_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getAdminTransferAvailableAt_vm_miss.

Lemma t5_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 20 5 getAdminTransferAvailableAt_vm_code (M5_getAdminTransferAvailableAt_vm_miss sto) =
 run 19 6 getAdminTransferAvailableAt_vm_code (M6_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M5_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getAdminTransferAvailableAt_vm_miss.

Lemma t6_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 19 6 getAdminTransferAvailableAt_vm_code (M6_getAdminTransferAvailableAt_vm_miss sto) =
 run 18 7 getAdminTransferAvailableAt_vm_code (M7_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M6_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getAdminTransferAvailableAt_vm_miss.

Lemma t7_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 18 7 getAdminTransferAvailableAt_vm_code (M7_getAdminTransferAvailableAt_vm_miss sto) =
 run 17 8 getAdminTransferAvailableAt_vm_code (M8_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M7_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getAdminTransferAvailableAt_vm_miss.

Lemma t8_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 17 8 getAdminTransferAvailableAt_vm_code (M8_getAdminTransferAvailableAt_vm_miss sto) =
 run 16 9 getAdminTransferAvailableAt_vm_code (M9_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M8_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getAdminTransferAvailableAt_vm_miss.

Lemma t9_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 16 9 getAdminTransferAvailableAt_vm_code (M9_getAdminTransferAvailableAt_vm_miss sto) =
 run 15 10 getAdminTransferAvailableAt_vm_code (M10_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M9_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getAdminTransferAvailableAt_vm_miss.

Lemma t10_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 15 10 getAdminTransferAvailableAt_vm_code (M10_getAdminTransferAvailableAt_vm_miss sto) =
 run 14 21 getAdminTransferAvailableAt_vm_code (M11_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M10_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getAdminTransferAvailableAt_vm_miss.

Lemma t11_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 14 21 getAdminTransferAvailableAt_vm_code (M11_getAdminTransferAvailableAt_vm_miss sto) =
 run 13 22 getAdminTransferAvailableAt_vm_code (M12_getAdminTransferAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M11_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getAdminTransferAvailableAt_vm_miss.

Lemma t12_getAdminTransferAvailableAt_vm_miss : forall (sto : storage),
 run 13 22 getAdminTransferAvailableAt_vm_code (M12_getAdminTransferAvailableAt_vm_miss sto) = Done (GInt 0%Z).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M12_getAdminTransferAvailableAt_vm_miss getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getAdminTransferAvailableAt_vm_miss.
Definition M0_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 getAdminTransferAvailableAt_vm_init sto.

Definition M1_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes getAdminTransferAvailableAt_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getAdminTransferAvailableAt_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GNull]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt value]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt 604800000%Z; GInt value]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z)]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z)]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getAdminTransferAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z)]; mlocals := [GBytes payload]; margs := [];
    mstatics := getAdminTransferAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 25 0 getAdminTransferAvailableAt_vm_code (M0_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 24 1 getAdminTransferAvailableAt_vm_code (M1_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M0_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getAdminTransferAvailableAt_vm_hitoff.

Lemma t1_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 24 1 getAdminTransferAvailableAt_vm_code (M1_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 23 2 getAdminTransferAvailableAt_vm_code (M2_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M1_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getAdminTransferAvailableAt_vm_hitoff.

Lemma t2_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 23 2 getAdminTransferAvailableAt_vm_code (M2_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 22 3 getAdminTransferAvailableAt_vm_code (M3_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M2_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getAdminTransferAvailableAt_vm_hitoff.

Lemma t3_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z) (Hstore : sto (getAdminTransferAvailableAt_prefix) = Some payload),
 run 22 3 getAdminTransferAvailableAt_vm_code (M3_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 21 4 getAdminTransferAvailableAt_vm_code (M4_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value Hstore.
 rewrite run_S.
 cbn [M3_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getAdminTransferAvailableAt_vm_hitoff.

Lemma t4_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 21 4 getAdminTransferAvailableAt_vm_code (M4_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 20 5 getAdminTransferAvailableAt_vm_code (M5_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M4_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getAdminTransferAvailableAt_vm_hitoff.

Lemma t5_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 20 5 getAdminTransferAvailableAt_vm_code (M5_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 19 6 getAdminTransferAvailableAt_vm_code (M6_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M5_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getAdminTransferAvailableAt_vm_hitoff.

Lemma t6_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 19 6 getAdminTransferAvailableAt_vm_code (M6_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 18 7 getAdminTransferAvailableAt_vm_code (M7_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M6_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getAdminTransferAvailableAt_vm_hitoff.

Lemma t7_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 18 7 getAdminTransferAvailableAt_vm_code (M7_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 17 8 getAdminTransferAvailableAt_vm_code (M8_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M7_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getAdminTransferAvailableAt_vm_hitoff.

Lemma t8_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 17 8 getAdminTransferAvailableAt_vm_code (M8_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 16 11 getAdminTransferAvailableAt_vm_code (M9_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M8_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getAdminTransferAvailableAt_vm_hitoff.

Lemma t9_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 16 11 getAdminTransferAvailableAt_vm_code (M9_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 15 12 getAdminTransferAvailableAt_vm_code (M10_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M9_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getAdminTransferAvailableAt_vm_hitoff.

Lemma t10_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 15 12 getAdminTransferAvailableAt_vm_code (M10_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 14 13 getAdminTransferAvailableAt_vm_code (M11_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M10_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getAdminTransferAvailableAt_vm_hitoff.

Lemma t11_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 14 13 getAdminTransferAvailableAt_vm_code (M11_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 13 14 getAdminTransferAvailableAt_vm_code (M12_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M11_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getAdminTransferAvailableAt_vm_hitoff.

Lemma t12_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 13 14 getAdminTransferAvailableAt_vm_code (M12_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 12 18 getAdminTransferAvailableAt_vm_code (M13_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M12_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getAdminTransferAvailableAt_vm_hitoff.

Lemma t13_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z) (Hdecode : decode_integer payload = OK (GInt value)),
 run 12 18 getAdminTransferAvailableAt_vm_code (M13_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 11 19 getAdminTransferAvailableAt_vm_code (M14_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value Hdecode.
 rewrite run_S.
 cbn [M13_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hdecode.
 reflexivity.
Qed.
Print Assumptions t13_getAdminTransferAvailableAt_vm_hitoff.

Lemma t14_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 11 19 getAdminTransferAvailableAt_vm_code (M14_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 10 20 getAdminTransferAvailableAt_vm_code (M15_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M14_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getAdminTransferAvailableAt_vm_hitoff.

Lemma t15_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z) (Hsum : integer_fitsb (value + 604800000) = true),
 run 10 20 getAdminTransferAvailableAt_vm_code (M15_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 9 21 getAdminTransferAvailableAt_vm_code (M16_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value Hsum.
 rewrite run_S.
 cbn [M15_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hsum.
 reflexivity.
Qed.
Print Assumptions t15_getAdminTransferAvailableAt_vm_hitoff.

Lemma t16_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 9 21 getAdminTransferAvailableAt_vm_code (M16_getAdminTransferAvailableAt_vm_hitoff sto payload value) =
 run 8 22 getAdminTransferAvailableAt_vm_code (M17_getAdminTransferAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M16_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getAdminTransferAvailableAt_vm_hitoff.

Lemma t17_getAdminTransferAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 8 22 getAdminTransferAvailableAt_vm_code (M17_getAdminTransferAvailableAt_vm_hitoff sto payload value) = Done (GInt (value + 604800000%Z)).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M17_getAdminTransferAvailableAt_vm_hitoff getAdminTransferAvailableAt_vm_init getAdminTransferAvailableAt_vm_code getAdminTransferAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getAdminTransferAvailableAt_vm_hitoff.

Theorem getAdminTransferAvailableAt_vm_miss : forall sto,
 sto (getAdminTransferAvailableAt_prefix) = None ->
 run 25 0 getAdminTransferAvailableAt_vm_code (getAdminTransferAvailableAt_vm_init sto) = Done (GInt 0%Z) /\
 getter_outcome getAdminTransferAvailableAt_prefix (GInt 0%Z) getAdminTransferAvailableAt_decode sto [] = OK (GInt 0%Z).
Proof.
 intros sto Hstore. split.
 - exact (eq_trans (t0_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t1_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t2_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t3_getAdminTransferAvailableAt_vm_miss sto Hstore) (eq_trans (t4_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t5_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t6_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t7_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t8_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t9_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t10_getAdminTransferAvailableAt_vm_miss sto) (eq_trans (t11_getAdminTransferAvailableAt_vm_miss sto) (t12_getAdminTransferAvailableAt_vm_miss sto))))))))))))).
 - unfold getter_outcome. rewrite app_nil_r, Hstore. reflexivity.
Qed.
Print Assumptions getAdminTransferAvailableAt_vm_miss.
Theorem getAdminTransferAvailableAt_vm_hit_offset : forall sto payload value,
 sto (getAdminTransferAvailableAt_prefix) = Some payload ->
 decode_integer payload = OK (GInt value) ->
 integer_fitsb (value + 604800000%Z) = true ->
 run 25 0 getAdminTransferAvailableAt_vm_code (getAdminTransferAvailableAt_vm_init sto) = Done (GInt (value + 604800000%Z)) /\
 getter_outcome getAdminTransferAvailableAt_prefix (GInt 0%Z) getAdminTransferAvailableAt_decode sto [] = OK (GInt (value + 604800000%Z)).
Proof.
 intros sto payload value Hstore Hdecode Hsum. split.
 - exact (eq_trans (t0_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t1_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t2_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t3_getAdminTransferAvailableAt_vm_hitoff sto payload value Hstore) (eq_trans (t4_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t5_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t6_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t7_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t8_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t9_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t10_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t11_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t12_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t13_getAdminTransferAvailableAt_vm_hitoff sto payload value Hdecode) (eq_trans (t14_getAdminTransferAvailableAt_vm_hitoff sto payload value) (eq_trans (t15_getAdminTransferAvailableAt_vm_hitoff sto payload value Hsum) (eq_trans (t16_getAdminTransferAvailableAt_vm_hitoff sto payload value) (t17_getAdminTransferAvailableAt_vm_hitoff sto payload value)))))))))))))))))).
 - unfold getter_outcome, getAdminTransferAvailableAt_decode.
   rewrite app_nil_r, Hstore, Hdecode, Hsum. reflexivity.
Qed.
Print Assumptions getAdminTransferAvailableAt_vm_hit_offset.
