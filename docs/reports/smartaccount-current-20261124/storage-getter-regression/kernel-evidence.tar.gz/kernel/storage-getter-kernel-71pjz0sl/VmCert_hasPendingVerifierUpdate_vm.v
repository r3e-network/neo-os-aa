From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition hasPendingVerifierUpdate_vm_program : list Ins :=
 [InitSlot 1 1; LdStatic 15; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; Push GNull; NotEqualIns; Jump 12; Ret].
Definition hasPendingVerifierUpdate_vm_code (pc : nat) : Ins := nth pc hasPendingVerifierUpdate_vm_program Unsupported.
Definition hasPendingVerifierUpdate_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 15 then Some (GBytes hasPendingVerifierUpdate_prefix) else None.
Definition hasPendingVerifierUpdate_vm_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 1) [GBytes account] hasPendingVerifierUpdate_vm_statics sto [] (fun _ _ => GNull).

Definition M0_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 hasPendingVerifierUpdate_vm_init sto account.

Definition M1_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingVerifierUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingVerifierUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingVerifierUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (hasPendingVerifierUpdate_prefix ++ account)]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_hasPendingVerifierUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 15 0 hasPendingVerifierUpdate_vm_code (M0_hasPendingVerifierUpdate_vm_miss sto account) =
 run 14 1 hasPendingVerifierUpdate_vm_code (M1_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M0_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_hasPendingVerifierUpdate_vm_miss.

Lemma t1_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 14 1 hasPendingVerifierUpdate_vm_code (M1_hasPendingVerifierUpdate_vm_miss sto account) =
 run 13 2 hasPendingVerifierUpdate_vm_code (M2_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M1_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_hasPendingVerifierUpdate_vm_miss.

Lemma t2_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 13 2 hasPendingVerifierUpdate_vm_code (M2_hasPendingVerifierUpdate_vm_miss sto account) =
 run 12 3 hasPendingVerifierUpdate_vm_code (M3_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M2_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_hasPendingVerifierUpdate_vm_miss.

Lemma t3_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 12 3 hasPendingVerifierUpdate_vm_code (M3_hasPendingVerifierUpdate_vm_miss sto account) =
 run 11 4 hasPendingVerifierUpdate_vm_code (M4_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M3_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_hasPendingVerifierUpdate_vm_miss.

Lemma t4_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 11 4 hasPendingVerifierUpdate_vm_code (M4_hasPendingVerifierUpdate_vm_miss sto account) =
 run 10 5 hasPendingVerifierUpdate_vm_code (M5_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M4_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_hasPendingVerifierUpdate_vm_miss.

Lemma t5_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 10 5 hasPendingVerifierUpdate_vm_code (M5_hasPendingVerifierUpdate_vm_miss sto account) =
 run 9 6 hasPendingVerifierUpdate_vm_code (M6_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M5_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_hasPendingVerifierUpdate_vm_miss.

Lemma t6_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 9 6 hasPendingVerifierUpdate_vm_code (M6_hasPendingVerifierUpdate_vm_miss sto account) =
 run 8 7 hasPendingVerifierUpdate_vm_code (M7_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M6_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_hasPendingVerifierUpdate_vm_miss.

Lemma t7_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 8 7 hasPendingVerifierUpdate_vm_code (M7_hasPendingVerifierUpdate_vm_miss sto account) =
 run 7 8 hasPendingVerifierUpdate_vm_code (M8_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M7_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_hasPendingVerifierUpdate_vm_miss.

Lemma t8_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes) (Hstore : sto (hasPendingVerifierUpdate_prefix ++ account) = None),
 run 7 8 hasPendingVerifierUpdate_vm_code (M8_hasPendingVerifierUpdate_vm_miss sto account) =
 run 6 9 hasPendingVerifierUpdate_vm_code (M9_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account Hstore.
 rewrite run_S.
 cbn [M8_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_hasPendingVerifierUpdate_vm_miss.

Lemma t9_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 6 9 hasPendingVerifierUpdate_vm_code (M9_hasPendingVerifierUpdate_vm_miss sto account) =
 run 5 10 hasPendingVerifierUpdate_vm_code (M10_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M9_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_hasPendingVerifierUpdate_vm_miss.

Lemma t10_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 5 10 hasPendingVerifierUpdate_vm_code (M10_hasPendingVerifierUpdate_vm_miss sto account) =
 run 4 11 hasPendingVerifierUpdate_vm_code (M11_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M10_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_hasPendingVerifierUpdate_vm_miss.

Lemma t11_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 4 11 hasPendingVerifierUpdate_vm_code (M11_hasPendingVerifierUpdate_vm_miss sto account) =
 run 3 12 hasPendingVerifierUpdate_vm_code (M12_hasPendingVerifierUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M11_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_hasPendingVerifierUpdate_vm_miss.

Lemma t12_hasPendingVerifierUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 3 12 hasPendingVerifierUpdate_vm_code (M12_hasPendingVerifierUpdate_vm_miss sto account) = Done (GBool false).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M12_hasPendingVerifierUpdate_vm_miss hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_hasPendingVerifierUpdate_vm_miss.
Definition M0_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 hasPendingVerifierUpdate_vm_init sto account.

Definition M1_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingVerifierUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingVerifierUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingVerifierUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (hasPendingVerifierUpdate_prefix ++ account)]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_hasPendingVerifierUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (hasPendingVerifierUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingVerifierUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 15 0 hasPendingVerifierUpdate_vm_code (M0_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 14 1 hasPendingVerifierUpdate_vm_code (M1_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M0_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_hasPendingVerifierUpdate_vm_hit.

Lemma t1_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 14 1 hasPendingVerifierUpdate_vm_code (M1_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 13 2 hasPendingVerifierUpdate_vm_code (M2_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M1_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_hasPendingVerifierUpdate_vm_hit.

Lemma t2_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 13 2 hasPendingVerifierUpdate_vm_code (M2_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 12 3 hasPendingVerifierUpdate_vm_code (M3_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M2_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_hasPendingVerifierUpdate_vm_hit.

Lemma t3_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 12 3 hasPendingVerifierUpdate_vm_code (M3_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 11 4 hasPendingVerifierUpdate_vm_code (M4_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M3_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_hasPendingVerifierUpdate_vm_hit.

Lemma t4_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 11 4 hasPendingVerifierUpdate_vm_code (M4_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 10 5 hasPendingVerifierUpdate_vm_code (M5_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M4_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_hasPendingVerifierUpdate_vm_hit.

Lemma t5_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 10 5 hasPendingVerifierUpdate_vm_code (M5_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 9 6 hasPendingVerifierUpdate_vm_code (M6_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M5_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_hasPendingVerifierUpdate_vm_hit.

Lemma t6_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 9 6 hasPendingVerifierUpdate_vm_code (M6_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 8 7 hasPendingVerifierUpdate_vm_code (M7_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M6_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_hasPendingVerifierUpdate_vm_hit.

Lemma t7_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 8 7 hasPendingVerifierUpdate_vm_code (M7_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 7 8 hasPendingVerifierUpdate_vm_code (M8_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M7_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_hasPendingVerifierUpdate_vm_hit.

Lemma t8_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (Hstore : sto (hasPendingVerifierUpdate_prefix ++ account) = Some payload),
 run 7 8 hasPendingVerifierUpdate_vm_code (M8_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 6 9 hasPendingVerifierUpdate_vm_code (M9_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload Hstore.
 rewrite run_S.
 cbn [M8_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_hasPendingVerifierUpdate_vm_hit.

Lemma t9_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 6 9 hasPendingVerifierUpdate_vm_code (M9_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 5 10 hasPendingVerifierUpdate_vm_code (M10_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M9_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_hasPendingVerifierUpdate_vm_hit.

Lemma t10_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 5 10 hasPendingVerifierUpdate_vm_code (M10_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 4 11 hasPendingVerifierUpdate_vm_code (M11_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M10_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_hasPendingVerifierUpdate_vm_hit.

Lemma t11_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 4 11 hasPendingVerifierUpdate_vm_code (M11_hasPendingVerifierUpdate_vm_hit sto account payload) =
 run 3 12 hasPendingVerifierUpdate_vm_code (M12_hasPendingVerifierUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M11_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_hasPendingVerifierUpdate_vm_hit.

Lemma t12_hasPendingVerifierUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 3 12 hasPendingVerifierUpdate_vm_code (M12_hasPendingVerifierUpdate_vm_hit sto account payload) = Done (GBool true).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M12_hasPendingVerifierUpdate_vm_hit hasPendingVerifierUpdate_vm_init hasPendingVerifierUpdate_vm_code hasPendingVerifierUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_hasPendingVerifierUpdate_vm_hit.

Theorem hasPendingVerifierUpdate_vm_miss : forall sto account,
 sto (hasPendingVerifierUpdate_prefix ++ account) = None ->
 run 15 0 hasPendingVerifierUpdate_vm_code (hasPendingVerifierUpdate_vm_init sto account) = Done (GBool false) /\
 hasPendingVerifierUpdate_binding sto account = OK (GBool false).
Proof.
 intros sto account Hstore. split.
 - exact (eq_trans (t0_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t1_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t2_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t3_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t4_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t5_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t6_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t7_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t8_hasPendingVerifierUpdate_vm_miss sto account Hstore) (eq_trans (t9_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t10_hasPendingVerifierUpdate_vm_miss sto account) (eq_trans (t11_hasPendingVerifierUpdate_vm_miss sto account) (t12_hasPendingVerifierUpdate_vm_miss sto account))))))))))))).
 - apply hasPendingVerifierUpdate_source_miss. exact Hstore.
Qed.
Print Assumptions hasPendingVerifierUpdate_vm_miss.
Theorem hasPendingVerifierUpdate_vm_hit : forall sto account payload,
 sto (hasPendingVerifierUpdate_prefix ++ account) = Some payload ->
 run 15 0 hasPendingVerifierUpdate_vm_code (hasPendingVerifierUpdate_vm_init sto account) = Done (GBool true) /\
 hasPendingVerifierUpdate_binding sto account = OK (GBool true).
Proof.
 intros sto account payload Hstore. split.
 - exact (eq_trans (t0_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t1_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t2_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t3_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t4_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t5_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t6_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t7_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t8_hasPendingVerifierUpdate_vm_hit sto account payload Hstore) (eq_trans (t9_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t10_hasPendingVerifierUpdate_vm_hit sto account payload) (eq_trans (t11_hasPendingVerifierUpdate_vm_hit sto account payload) (t12_hasPendingVerifierUpdate_vm_hit sto account payload))))))))))))).
 - apply hasPendingVerifierUpdate_source_hit with (payload := payload). exact Hstore.
Qed.
Print Assumptions hasPendingVerifierUpdate_vm_hit.
