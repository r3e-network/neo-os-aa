From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getPlatformRegistrarAvailableAt_vm_program : list Ins :=
 [InitSlot 1 0; LdStatic 47; GetContext; StorageGet; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 11; Push (GInt 0); Jump 21; LdLoc 0; Dup; IsNull; JumpIfNot 18; Drop; Push (GInt 0); Jump 19; Convert 33; LdStatic 27; AddIns; Jump 22; Ret].
Definition getPlatformRegistrarAvailableAt_vm_code (pc : nat) : Ins := nth pc getPlatformRegistrarAvailableAt_vm_program Unsupported.
Definition getPlatformRegistrarAvailableAt_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 47 then Some (GBytes getPlatformRegistrarAvailableAt_prefix)
          else if Nat.eqb i 27 then Some (GInt 604800000%Z) else None.
Definition getPlatformRegistrarAvailableAt_vm_init (sto : storage) : Machine :=
 machine [] (repeat GNull 1) [] getPlatformRegistrarAvailableAt_vm_statics sto [] (fun _ _ => GNull).

Definition M0_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 getPlatformRegistrarAvailableAt_vm_init sto.

Definition M1_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes getPlatformRegistrarAvailableAt_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getPlatformRegistrarAvailableAt_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBool true]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getPlatformRegistrarAvailableAt_vm_miss (sto : storage) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 25 0 getPlatformRegistrarAvailableAt_vm_code (M0_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 24 1 getPlatformRegistrarAvailableAt_vm_code (M1_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M0_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t1_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 24 1 getPlatformRegistrarAvailableAt_vm_code (M1_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 23 2 getPlatformRegistrarAvailableAt_vm_code (M2_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M1_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t2_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 23 2 getPlatformRegistrarAvailableAt_vm_code (M2_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 22 3 getPlatformRegistrarAvailableAt_vm_code (M3_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M2_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t3_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage) (Hstore : sto (getPlatformRegistrarAvailableAt_prefix) = None),
 run 22 3 getPlatformRegistrarAvailableAt_vm_code (M3_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 21 4 getPlatformRegistrarAvailableAt_vm_code (M4_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto Hstore.
 rewrite run_S.
 cbn [M3_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t4_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 21 4 getPlatformRegistrarAvailableAt_vm_code (M4_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 20 5 getPlatformRegistrarAvailableAt_vm_code (M5_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M4_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t5_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 20 5 getPlatformRegistrarAvailableAt_vm_code (M5_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 19 6 getPlatformRegistrarAvailableAt_vm_code (M6_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M5_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t6_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 19 6 getPlatformRegistrarAvailableAt_vm_code (M6_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 18 7 getPlatformRegistrarAvailableAt_vm_code (M7_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M6_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t7_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 18 7 getPlatformRegistrarAvailableAt_vm_code (M7_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 17 8 getPlatformRegistrarAvailableAt_vm_code (M8_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M7_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t8_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 17 8 getPlatformRegistrarAvailableAt_vm_code (M8_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 16 9 getPlatformRegistrarAvailableAt_vm_code (M9_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M8_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t9_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 16 9 getPlatformRegistrarAvailableAt_vm_code (M9_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 15 10 getPlatformRegistrarAvailableAt_vm_code (M10_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M9_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t10_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 15 10 getPlatformRegistrarAvailableAt_vm_code (M10_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 14 21 getPlatformRegistrarAvailableAt_vm_code (M11_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M10_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t11_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 14 21 getPlatformRegistrarAvailableAt_vm_code (M11_getPlatformRegistrarAvailableAt_vm_miss sto) =
 run 13 22 getPlatformRegistrarAvailableAt_vm_code (M12_getPlatformRegistrarAvailableAt_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M11_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPlatformRegistrarAvailableAt_vm_miss.

Lemma t12_getPlatformRegistrarAvailableAt_vm_miss : forall (sto : storage),
 run 13 22 getPlatformRegistrarAvailableAt_vm_code (M12_getPlatformRegistrarAvailableAt_vm_miss sto) = Done (GInt 0%Z).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M12_getPlatformRegistrarAvailableAt_vm_miss getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPlatformRegistrarAvailableAt_vm_miss.
Definition M0_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 getPlatformRegistrarAvailableAt_vm_init sto.

Definition M1_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes getPlatformRegistrarAvailableAt_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getPlatformRegistrarAvailableAt_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt value]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt 604800000%Z; GInt value]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z)]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z)]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getPlatformRegistrarAvailableAt_vm_hitoff (sto : storage) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z)]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrarAvailableAt_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 25 0 getPlatformRegistrarAvailableAt_vm_code (M0_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 24 1 getPlatformRegistrarAvailableAt_vm_code (M1_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M0_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t1_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 24 1 getPlatformRegistrarAvailableAt_vm_code (M1_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 23 2 getPlatformRegistrarAvailableAt_vm_code (M2_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M1_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t2_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 23 2 getPlatformRegistrarAvailableAt_vm_code (M2_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 22 3 getPlatformRegistrarAvailableAt_vm_code (M3_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M2_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t3_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z) (Hstore : sto (getPlatformRegistrarAvailableAt_prefix) = Some payload),
 run 22 3 getPlatformRegistrarAvailableAt_vm_code (M3_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 21 4 getPlatformRegistrarAvailableAt_vm_code (M4_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value Hstore.
 rewrite run_S.
 cbn [M3_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t4_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 21 4 getPlatformRegistrarAvailableAt_vm_code (M4_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 20 5 getPlatformRegistrarAvailableAt_vm_code (M5_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M4_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t5_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 20 5 getPlatformRegistrarAvailableAt_vm_code (M5_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 19 6 getPlatformRegistrarAvailableAt_vm_code (M6_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M5_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t6_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 19 6 getPlatformRegistrarAvailableAt_vm_code (M6_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 18 7 getPlatformRegistrarAvailableAt_vm_code (M7_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M6_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t7_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 18 7 getPlatformRegistrarAvailableAt_vm_code (M7_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 17 8 getPlatformRegistrarAvailableAt_vm_code (M8_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M7_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t8_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 17 8 getPlatformRegistrarAvailableAt_vm_code (M8_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 16 11 getPlatformRegistrarAvailableAt_vm_code (M9_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M8_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t9_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 16 11 getPlatformRegistrarAvailableAt_vm_code (M9_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 15 12 getPlatformRegistrarAvailableAt_vm_code (M10_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M9_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t10_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 15 12 getPlatformRegistrarAvailableAt_vm_code (M10_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 14 13 getPlatformRegistrarAvailableAt_vm_code (M11_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M10_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t11_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 14 13 getPlatformRegistrarAvailableAt_vm_code (M11_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 13 14 getPlatformRegistrarAvailableAt_vm_code (M12_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M11_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t12_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 13 14 getPlatformRegistrarAvailableAt_vm_code (M12_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 12 18 getPlatformRegistrarAvailableAt_vm_code (M13_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M12_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t13_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z) (Hdecode : decode_integer payload = OK (GInt value)),
 run 12 18 getPlatformRegistrarAvailableAt_vm_code (M13_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 11 19 getPlatformRegistrarAvailableAt_vm_code (M14_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value Hdecode.
 rewrite run_S.
 cbn [M13_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hdecode.
 reflexivity.
Qed.
Print Assumptions t13_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t14_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 11 19 getPlatformRegistrarAvailableAt_vm_code (M14_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 10 20 getPlatformRegistrarAvailableAt_vm_code (M15_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M14_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t15_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z) (Hsum : integer_fitsb (value + 604800000) = true),
 run 10 20 getPlatformRegistrarAvailableAt_vm_code (M15_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 9 21 getPlatformRegistrarAvailableAt_vm_code (M16_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value Hsum.
 rewrite run_S.
 cbn [M15_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hsum.
 reflexivity.
Qed.
Print Assumptions t15_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t16_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 9 21 getPlatformRegistrarAvailableAt_vm_code (M16_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) =
 run 8 22 getPlatformRegistrarAvailableAt_vm_code (M17_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M16_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPlatformRegistrarAvailableAt_vm_hitoff.

Lemma t17_getPlatformRegistrarAvailableAt_vm_hitoff : forall (sto : storage) (payload : bytes) (value : Z),
 run 8 22 getPlatformRegistrarAvailableAt_vm_code (M17_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) = Done (GInt (value + 604800000%Z)).
Proof.
 intros sto payload value.
 rewrite run_S.
 cbn [M17_getPlatformRegistrarAvailableAt_vm_hitoff getPlatformRegistrarAvailableAt_vm_init getPlatformRegistrarAvailableAt_vm_code getPlatformRegistrarAvailableAt_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPlatformRegistrarAvailableAt_vm_hitoff.

Theorem getPlatformRegistrarAvailableAt_vm_miss : forall sto,
 sto (getPlatformRegistrarAvailableAt_prefix) = None ->
 run 25 0 getPlatformRegistrarAvailableAt_vm_code (getPlatformRegistrarAvailableAt_vm_init sto) = Done (GInt 0%Z) /\
 getter_outcome getPlatformRegistrarAvailableAt_prefix (GInt 0%Z) getPlatformRegistrarAvailableAt_decode sto [] = OK (GInt 0%Z).
Proof.
 intros sto Hstore. split.
 - exact (eq_trans (t0_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t1_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t2_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t3_getPlatformRegistrarAvailableAt_vm_miss sto Hstore) (eq_trans (t4_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t5_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t6_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t7_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t8_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t9_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t10_getPlatformRegistrarAvailableAt_vm_miss sto) (eq_trans (t11_getPlatformRegistrarAvailableAt_vm_miss sto) (t12_getPlatformRegistrarAvailableAt_vm_miss sto))))))))))))).
 - unfold getter_outcome. rewrite app_nil_r, Hstore. reflexivity.
Qed.
Print Assumptions getPlatformRegistrarAvailableAt_vm_miss.
Theorem getPlatformRegistrarAvailableAt_vm_hit_offset : forall sto payload value,
 sto (getPlatformRegistrarAvailableAt_prefix) = Some payload ->
 decode_integer payload = OK (GInt value) ->
 integer_fitsb (value + 604800000%Z) = true ->
 run 25 0 getPlatformRegistrarAvailableAt_vm_code (getPlatformRegistrarAvailableAt_vm_init sto) = Done (GInt (value + 604800000%Z)) /\
 getter_outcome getPlatformRegistrarAvailableAt_prefix (GInt 0%Z) getPlatformRegistrarAvailableAt_decode sto [] = OK (GInt (value + 604800000%Z)).
Proof.
 intros sto payload value Hstore Hdecode Hsum. split.
 - exact (eq_trans (t0_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t1_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t2_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t3_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value Hstore) (eq_trans (t4_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t5_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t6_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t7_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t8_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t9_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t10_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t11_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t12_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t13_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value Hdecode) (eq_trans (t14_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (eq_trans (t15_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value Hsum) (eq_trans (t16_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value) (t17_getPlatformRegistrarAvailableAt_vm_hitoff sto payload value)))))))))))))))))).
 - unfold getter_outcome, getPlatformRegistrarAvailableAt_decode.
   rewrite app_nil_r, Hstore, Hdecode, Hsum. reflexivity.
Qed.
Print Assumptions getPlatformRegistrarAvailableAt_vm_hit_offset.
