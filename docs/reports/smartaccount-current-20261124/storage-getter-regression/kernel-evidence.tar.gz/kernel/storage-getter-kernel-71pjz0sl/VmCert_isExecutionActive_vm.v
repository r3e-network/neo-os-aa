From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition isExecutionActive_vm_program : list Ins :=
 [InitSlot 1 1; LdStatic 2; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; Push GNull; NotEqualIns; Jump 12; Ret].
Definition isExecutionActive_vm_code (pc : nat) : Ins := nth pc isExecutionActive_vm_program Unsupported.
Definition isExecutionActive_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 2 then Some (GBytes isExecutionActive_prefix) else None.
Definition isExecutionActive_vm_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 1) [GBytes account] isExecutionActive_vm_statics sto [] (fun _ _ => GNull).

Definition M0_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 isExecutionActive_vm_init sto account.

Definition M1_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes isExecutionActive_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes isExecutionActive_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes isExecutionActive_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (isExecutionActive_prefix ++ account)]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (isExecutionActive_prefix ++ account)]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (isExecutionActive_prefix ++ account)]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_isExecutionActive_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 15 0 isExecutionActive_vm_code (M0_isExecutionActive_vm_miss sto account) =
 run 14 1 isExecutionActive_vm_code (M1_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M0_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_isExecutionActive_vm_miss.

Lemma t1_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 14 1 isExecutionActive_vm_code (M1_isExecutionActive_vm_miss sto account) =
 run 13 2 isExecutionActive_vm_code (M2_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M1_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_isExecutionActive_vm_miss.

Lemma t2_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 13 2 isExecutionActive_vm_code (M2_isExecutionActive_vm_miss sto account) =
 run 12 3 isExecutionActive_vm_code (M3_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M2_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_isExecutionActive_vm_miss.

Lemma t3_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 12 3 isExecutionActive_vm_code (M3_isExecutionActive_vm_miss sto account) =
 run 11 4 isExecutionActive_vm_code (M4_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M3_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_isExecutionActive_vm_miss.

Lemma t4_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 11 4 isExecutionActive_vm_code (M4_isExecutionActive_vm_miss sto account) =
 run 10 5 isExecutionActive_vm_code (M5_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M4_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_isExecutionActive_vm_miss.

Lemma t5_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 10 5 isExecutionActive_vm_code (M5_isExecutionActive_vm_miss sto account) =
 run 9 6 isExecutionActive_vm_code (M6_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M5_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_isExecutionActive_vm_miss.

Lemma t6_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 9 6 isExecutionActive_vm_code (M6_isExecutionActive_vm_miss sto account) =
 run 8 7 isExecutionActive_vm_code (M7_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M6_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_isExecutionActive_vm_miss.

Lemma t7_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 8 7 isExecutionActive_vm_code (M7_isExecutionActive_vm_miss sto account) =
 run 7 8 isExecutionActive_vm_code (M8_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M7_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_isExecutionActive_vm_miss.

Lemma t8_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes) (Hstore : sto (isExecutionActive_prefix ++ account) = None),
 run 7 8 isExecutionActive_vm_code (M8_isExecutionActive_vm_miss sto account) =
 run 6 9 isExecutionActive_vm_code (M9_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account Hstore.
 rewrite run_S.
 cbn [M8_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_isExecutionActive_vm_miss.

Lemma t9_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 6 9 isExecutionActive_vm_code (M9_isExecutionActive_vm_miss sto account) =
 run 5 10 isExecutionActive_vm_code (M10_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M9_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_isExecutionActive_vm_miss.

Lemma t10_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 5 10 isExecutionActive_vm_code (M10_isExecutionActive_vm_miss sto account) =
 run 4 11 isExecutionActive_vm_code (M11_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M10_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_isExecutionActive_vm_miss.

Lemma t11_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 4 11 isExecutionActive_vm_code (M11_isExecutionActive_vm_miss sto account) =
 run 3 12 isExecutionActive_vm_code (M12_isExecutionActive_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M11_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_isExecutionActive_vm_miss.

Lemma t12_isExecutionActive_vm_miss : forall (sto : storage) (account : bytes),
 run 3 12 isExecutionActive_vm_code (M12_isExecutionActive_vm_miss sto account) = Done (GBool false).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M12_isExecutionActive_vm_miss isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_isExecutionActive_vm_miss.
Definition M0_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 isExecutionActive_vm_init sto account.

Definition M1_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes isExecutionActive_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes isExecutionActive_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes isExecutionActive_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (isExecutionActive_prefix ++ account)]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (isExecutionActive_prefix ++ account)]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (isExecutionActive_prefix ++ account)]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_isExecutionActive_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (isExecutionActive_prefix ++ account)]; margs := [GBytes account];
    mstatics := isExecutionActive_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 15 0 isExecutionActive_vm_code (M0_isExecutionActive_vm_hit sto account payload) =
 run 14 1 isExecutionActive_vm_code (M1_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M0_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_isExecutionActive_vm_hit.

Lemma t1_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 14 1 isExecutionActive_vm_code (M1_isExecutionActive_vm_hit sto account payload) =
 run 13 2 isExecutionActive_vm_code (M2_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M1_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_isExecutionActive_vm_hit.

Lemma t2_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 13 2 isExecutionActive_vm_code (M2_isExecutionActive_vm_hit sto account payload) =
 run 12 3 isExecutionActive_vm_code (M3_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M2_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_isExecutionActive_vm_hit.

Lemma t3_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 12 3 isExecutionActive_vm_code (M3_isExecutionActive_vm_hit sto account payload) =
 run 11 4 isExecutionActive_vm_code (M4_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M3_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_isExecutionActive_vm_hit.

Lemma t4_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 11 4 isExecutionActive_vm_code (M4_isExecutionActive_vm_hit sto account payload) =
 run 10 5 isExecutionActive_vm_code (M5_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M4_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_isExecutionActive_vm_hit.

Lemma t5_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 10 5 isExecutionActive_vm_code (M5_isExecutionActive_vm_hit sto account payload) =
 run 9 6 isExecutionActive_vm_code (M6_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M5_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_isExecutionActive_vm_hit.

Lemma t6_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 9 6 isExecutionActive_vm_code (M6_isExecutionActive_vm_hit sto account payload) =
 run 8 7 isExecutionActive_vm_code (M7_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M6_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_isExecutionActive_vm_hit.

Lemma t7_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 8 7 isExecutionActive_vm_code (M7_isExecutionActive_vm_hit sto account payload) =
 run 7 8 isExecutionActive_vm_code (M8_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M7_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_isExecutionActive_vm_hit.

Lemma t8_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (Hstore : sto (isExecutionActive_prefix ++ account) = Some payload),
 run 7 8 isExecutionActive_vm_code (M8_isExecutionActive_vm_hit sto account payload) =
 run 6 9 isExecutionActive_vm_code (M9_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload Hstore.
 rewrite run_S.
 cbn [M8_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_isExecutionActive_vm_hit.

Lemma t9_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 6 9 isExecutionActive_vm_code (M9_isExecutionActive_vm_hit sto account payload) =
 run 5 10 isExecutionActive_vm_code (M10_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M9_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_isExecutionActive_vm_hit.

Lemma t10_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 5 10 isExecutionActive_vm_code (M10_isExecutionActive_vm_hit sto account payload) =
 run 4 11 isExecutionActive_vm_code (M11_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M10_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_isExecutionActive_vm_hit.

Lemma t11_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 4 11 isExecutionActive_vm_code (M11_isExecutionActive_vm_hit sto account payload) =
 run 3 12 isExecutionActive_vm_code (M12_isExecutionActive_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M11_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_isExecutionActive_vm_hit.

Lemma t12_isExecutionActive_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 3 12 isExecutionActive_vm_code (M12_isExecutionActive_vm_hit sto account payload) = Done (GBool true).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M12_isExecutionActive_vm_hit isExecutionActive_vm_init isExecutionActive_vm_code isExecutionActive_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_isExecutionActive_vm_hit.

Theorem isExecutionActive_vm_miss : forall sto account,
 sto (isExecutionActive_prefix ++ account) = None ->
 run 15 0 isExecutionActive_vm_code (isExecutionActive_vm_init sto account) = Done (GBool false) /\
 isExecutionActive_binding sto account = OK (GBool false).
Proof.
 intros sto account Hstore. split.
 - exact (eq_trans (t0_isExecutionActive_vm_miss sto account) (eq_trans (t1_isExecutionActive_vm_miss sto account) (eq_trans (t2_isExecutionActive_vm_miss sto account) (eq_trans (t3_isExecutionActive_vm_miss sto account) (eq_trans (t4_isExecutionActive_vm_miss sto account) (eq_trans (t5_isExecutionActive_vm_miss sto account) (eq_trans (t6_isExecutionActive_vm_miss sto account) (eq_trans (t7_isExecutionActive_vm_miss sto account) (eq_trans (t8_isExecutionActive_vm_miss sto account Hstore) (eq_trans (t9_isExecutionActive_vm_miss sto account) (eq_trans (t10_isExecutionActive_vm_miss sto account) (eq_trans (t11_isExecutionActive_vm_miss sto account) (t12_isExecutionActive_vm_miss sto account))))))))))))).
 - apply isExecutionActive_source_miss. exact Hstore.
Qed.
Print Assumptions isExecutionActive_vm_miss.
Theorem isExecutionActive_vm_hit : forall sto account payload,
 sto (isExecutionActive_prefix ++ account) = Some payload ->
 run 15 0 isExecutionActive_vm_code (isExecutionActive_vm_init sto account) = Done (GBool true) /\
 isExecutionActive_binding sto account = OK (GBool true).
Proof.
 intros sto account payload Hstore. split.
 - exact (eq_trans (t0_isExecutionActive_vm_hit sto account payload) (eq_trans (t1_isExecutionActive_vm_hit sto account payload) (eq_trans (t2_isExecutionActive_vm_hit sto account payload) (eq_trans (t3_isExecutionActive_vm_hit sto account payload) (eq_trans (t4_isExecutionActive_vm_hit sto account payload) (eq_trans (t5_isExecutionActive_vm_hit sto account payload) (eq_trans (t6_isExecutionActive_vm_hit sto account payload) (eq_trans (t7_isExecutionActive_vm_hit sto account payload) (eq_trans (t8_isExecutionActive_vm_hit sto account payload Hstore) (eq_trans (t9_isExecutionActive_vm_hit sto account payload) (eq_trans (t10_isExecutionActive_vm_hit sto account payload) (eq_trans (t11_isExecutionActive_vm_hit sto account payload) (t12_isExecutionActive_vm_hit sto account payload))))))))))))).
 - apply isExecutionActive_source_hit with (payload := payload). exact Hstore.
Qed.
Print Assumptions isExecutionActive_vm_hit.
