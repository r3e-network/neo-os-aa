From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getPendingHookCallHash_vm_program : list Ins :=
 [InitSlot 1 1; LdArg; LdStatic 22; Call 18; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 13; Push (GInt 0); NewBuffer; Convert 40; Jump 16; LdLoc 0; Push (GInt 1); PickItem; Jump 17; Ret; InitSlot 2 2; LdArgN 1; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 34; Push GNull; Jump 37; LdLoc 1; CallToken 4; Jump 37; Ret].
Definition getPendingHookCallHash_vm_code (pc : nat) : Ins := nth pc getPendingHookCallHash_vm_program Unsupported.
Definition getPendingHookCallHash_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 22 then Some (GBytes getPendingHookCallHash_prefix) else None.
Definition getPendingHookCallHash_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account; GBytes getPendingHookCallHash_prefix] getPendingHookCallHash_vm_statics sto [] tok.

Definition M0_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 getPendingHookCallHash_vm_init tok sto account.

Definition M1_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M5_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M6_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M7_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookCallHash_prefix; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M8_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookCallHash_prefix; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M9_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M10_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M11_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M12_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingHookCallHash_prefix ++ account); GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M13_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M14_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M15_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M16_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M17_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M18_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M19_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M20_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M21_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M26_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M27_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M28_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M29_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M30_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M31_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M32_getPendingHookCallHash_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 40 0 getPendingHookCallHash_vm_code (M0_getPendingHookCallHash_vm_miss tok sto account) =
 run 39 1 getPendingHookCallHash_vm_code (M1_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingHookCallHash_vm_miss.

Lemma t1_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 39 1 getPendingHookCallHash_vm_code (M1_getPendingHookCallHash_vm_miss tok sto account) =
 run 38 2 getPendingHookCallHash_vm_code (M2_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingHookCallHash_vm_miss.

Lemma t2_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 38 2 getPendingHookCallHash_vm_code (M2_getPendingHookCallHash_vm_miss tok sto account) =
 run 37 3 getPendingHookCallHash_vm_code (M3_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingHookCallHash_vm_miss.

Lemma t3_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 37 3 getPendingHookCallHash_vm_code (M3_getPendingHookCallHash_vm_miss tok sto account) =
 run 36 18 getPendingHookCallHash_vm_code (M4_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingHookCallHash_vm_miss.

Lemma t4_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 36 18 getPendingHookCallHash_vm_code (M4_getPendingHookCallHash_vm_miss tok sto account) =
 run 35 19 getPendingHookCallHash_vm_code (M5_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingHookCallHash_vm_miss.

Lemma t5_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 35 19 getPendingHookCallHash_vm_code (M5_getPendingHookCallHash_vm_miss tok sto account) =
 run 34 20 getPendingHookCallHash_vm_code (M6_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingHookCallHash_vm_miss.

Lemma t6_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 34 20 getPendingHookCallHash_vm_code (M6_getPendingHookCallHash_vm_miss tok sto account) =
 run 33 21 getPendingHookCallHash_vm_code (M7_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingHookCallHash_vm_miss.

Lemma t7_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 33 21 getPendingHookCallHash_vm_code (M7_getPendingHookCallHash_vm_miss tok sto account) =
 run 32 22 getPendingHookCallHash_vm_code (M8_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingHookCallHash_vm_miss.

Lemma t8_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 32 22 getPendingHookCallHash_vm_code (M8_getPendingHookCallHash_vm_miss tok sto account) =
 run 31 23 getPendingHookCallHash_vm_code (M9_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M8_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingHookCallHash_vm_miss.

Lemma t9_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 31 23 getPendingHookCallHash_vm_code (M9_getPendingHookCallHash_vm_miss tok sto account) =
 run 30 24 getPendingHookCallHash_vm_code (M10_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingHookCallHash_vm_miss.

Lemma t10_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 30 24 getPendingHookCallHash_vm_code (M10_getPendingHookCallHash_vm_miss tok sto account) =
 run 29 25 getPendingHookCallHash_vm_code (M11_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingHookCallHash_vm_miss.

Lemma t11_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 29 25 getPendingHookCallHash_vm_code (M11_getPendingHookCallHash_vm_miss tok sto account) =
 run 28 26 getPendingHookCallHash_vm_code (M12_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M11_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingHookCallHash_vm_miss.

Lemma t12_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (Hstore : sto (getPendingHookCallHash_prefix ++ account) = None),
 run 28 26 getPendingHookCallHash_vm_code (M12_getPendingHookCallHash_vm_miss tok sto account) =
 run 27 27 getPendingHookCallHash_vm_code (M13_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account Hstore.
 rewrite run_S.
 cbn [M12_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t12_getPendingHookCallHash_vm_miss.

Lemma t13_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 27 getPendingHookCallHash_vm_code (M13_getPendingHookCallHash_vm_miss tok sto account) =
 run 26 28 getPendingHookCallHash_vm_code (M14_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingHookCallHash_vm_miss.

Lemma t14_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 28 getPendingHookCallHash_vm_code (M14_getPendingHookCallHash_vm_miss tok sto account) =
 run 25 29 getPendingHookCallHash_vm_code (M15_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingHookCallHash_vm_miss.

Lemma t15_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 29 getPendingHookCallHash_vm_code (M15_getPendingHookCallHash_vm_miss tok sto account) =
 run 24 30 getPendingHookCallHash_vm_code (M16_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingHookCallHash_vm_miss.

Lemma t16_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 30 getPendingHookCallHash_vm_code (M16_getPendingHookCallHash_vm_miss tok sto account) =
 run 23 31 getPendingHookCallHash_vm_code (M17_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingHookCallHash_vm_miss.

Lemma t17_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 31 getPendingHookCallHash_vm_code (M17_getPendingHookCallHash_vm_miss tok sto account) =
 run 22 32 getPendingHookCallHash_vm_code (M18_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M17_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingHookCallHash_vm_miss.

Lemma t18_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 32 getPendingHookCallHash_vm_code (M18_getPendingHookCallHash_vm_miss tok sto account) =
 run 21 33 getPendingHookCallHash_vm_code (M19_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M18_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingHookCallHash_vm_miss.

Lemma t19_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 33 getPendingHookCallHash_vm_code (M19_getPendingHookCallHash_vm_miss tok sto account) =
 run 20 37 getPendingHookCallHash_vm_code (M20_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M19_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getPendingHookCallHash_vm_miss.

Lemma t20_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 20 37 getPendingHookCallHash_vm_code (M20_getPendingHookCallHash_vm_miss tok sto account) =
 run 19 4 getPendingHookCallHash_vm_code (M21_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M20_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getPendingHookCallHash_vm_miss.

Lemma t21_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 4 getPendingHookCallHash_vm_code (M21_getPendingHookCallHash_vm_miss tok sto account) =
 run 18 5 getPendingHookCallHash_vm_code (M22_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M21_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getPendingHookCallHash_vm_miss.

Lemma t22_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 18 5 getPendingHookCallHash_vm_code (M22_getPendingHookCallHash_vm_miss tok sto account) =
 run 17 6 getPendingHookCallHash_vm_code (M23_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M22_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getPendingHookCallHash_vm_miss.

Lemma t23_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 6 getPendingHookCallHash_vm_code (M23_getPendingHookCallHash_vm_miss tok sto account) =
 run 16 7 getPendingHookCallHash_vm_code (M24_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M23_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getPendingHookCallHash_vm_miss.

Lemma t24_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 7 getPendingHookCallHash_vm_code (M24_getPendingHookCallHash_vm_miss tok sto account) =
 run 15 8 getPendingHookCallHash_vm_code (M25_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M24_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getPendingHookCallHash_vm_miss.

Lemma t25_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 8 getPendingHookCallHash_vm_code (M25_getPendingHookCallHash_vm_miss tok sto account) =
 run 14 9 getPendingHookCallHash_vm_code (M26_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M25_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t25_getPendingHookCallHash_vm_miss.

Lemma t26_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 9 getPendingHookCallHash_vm_code (M26_getPendingHookCallHash_vm_miss tok sto account) =
 run 13 10 getPendingHookCallHash_vm_code (M27_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M26_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t26_getPendingHookCallHash_vm_miss.

Lemma t27_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 10 getPendingHookCallHash_vm_code (M27_getPendingHookCallHash_vm_miss tok sto account) =
 run 12 11 getPendingHookCallHash_vm_code (M28_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M27_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t27_getPendingHookCallHash_vm_miss.

Lemma t28_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 11 getPendingHookCallHash_vm_code (M28_getPendingHookCallHash_vm_miss tok sto account) =
 run 11 12 getPendingHookCallHash_vm_code (M29_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M28_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t28_getPendingHookCallHash_vm_miss.

Lemma t29_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 11 12 getPendingHookCallHash_vm_code (M29_getPendingHookCallHash_vm_miss tok sto account) =
 run 10 16 getPendingHookCallHash_vm_code (M30_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M29_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t29_getPendingHookCallHash_vm_miss.

Lemma t30_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 10 16 getPendingHookCallHash_vm_code (M30_getPendingHookCallHash_vm_miss tok sto account) =
 run 9 17 getPendingHookCallHash_vm_code (M31_getPendingHookCallHash_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M30_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t30_getPendingHookCallHash_vm_miss.

Lemma t31_getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 9 17 getPendingHookCallHash_vm_code (M31_getPendingHookCallHash_vm_miss tok sto account) = Done (GBytes []).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M31_getPendingHookCallHash_vm_miss getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t31_getPendingHookCallHash_vm_miss.
Definition M0_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 getPendingHookCallHash_vm_init tok sto account.

Definition M1_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M5_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M6_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M7_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookCallHash_prefix; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M8_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookCallHash_prefix; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M9_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M10_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M11_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M12_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingHookCallHash_prefix ++ account); GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M13_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M14_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M15_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M16_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M17_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBool false; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M18_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M19_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M20_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M21_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M22_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallHash_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GNull; GArray xs; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M26_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBool false; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M27_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M28_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M29_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GInt 1%Z; GArray xs; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M30_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M31_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M32_getPendingHookCallHash_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes getPendingHookCallHash_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallHash_prefix];
    mstatics := getPendingHookCallHash_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 40 0 getPendingHookCallHash_vm_code (M0_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 39 1 getPendingHookCallHash_vm_code (M1_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M0_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingHookCallHash_vm_hit.

Lemma t1_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 39 1 getPendingHookCallHash_vm_code (M1_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 38 2 getPendingHookCallHash_vm_code (M2_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M1_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingHookCallHash_vm_hit.

Lemma t2_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 38 2 getPendingHookCallHash_vm_code (M2_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 37 3 getPendingHookCallHash_vm_code (M3_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M2_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingHookCallHash_vm_hit.

Lemma t3_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 37 3 getPendingHookCallHash_vm_code (M3_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 36 18 getPendingHookCallHash_vm_code (M4_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M3_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingHookCallHash_vm_hit.

Lemma t4_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 36 18 getPendingHookCallHash_vm_code (M4_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 35 19 getPendingHookCallHash_vm_code (M5_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M4_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingHookCallHash_vm_hit.

Lemma t5_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 35 19 getPendingHookCallHash_vm_code (M5_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 34 20 getPendingHookCallHash_vm_code (M6_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M5_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingHookCallHash_vm_hit.

Lemma t6_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 34 20 getPendingHookCallHash_vm_code (M6_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 33 21 getPendingHookCallHash_vm_code (M7_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M6_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingHookCallHash_vm_hit.

Lemma t7_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 33 21 getPendingHookCallHash_vm_code (M7_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 32 22 getPendingHookCallHash_vm_code (M8_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M7_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingHookCallHash_vm_hit.

Lemma t8_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 32 22 getPendingHookCallHash_vm_code (M8_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 31 23 getPendingHookCallHash_vm_code (M9_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M8_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingHookCallHash_vm_hit.

Lemma t9_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 31 23 getPendingHookCallHash_vm_code (M9_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 30 24 getPendingHookCallHash_vm_code (M10_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M9_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingHookCallHash_vm_hit.

Lemma t10_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 30 24 getPendingHookCallHash_vm_code (M10_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 29 25 getPendingHookCallHash_vm_code (M11_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M10_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingHookCallHash_vm_hit.

Lemma t11_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 29 25 getPendingHookCallHash_vm_code (M11_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 28 26 getPendingHookCallHash_vm_code (M12_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M11_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingHookCallHash_vm_hit.

Lemma t12_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Hstore : sto (getPendingHookCallHash_prefix ++ account) = Some payload),
 run 28 26 getPendingHookCallHash_vm_code (M12_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 27 27 getPendingHookCallHash_vm_code (M13_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Hstore.
 rewrite run_S.
 cbn [M12_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t12_getPendingHookCallHash_vm_hit.

Lemma t13_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 27 27 getPendingHookCallHash_vm_code (M13_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 26 28 getPendingHookCallHash_vm_code (M14_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M13_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingHookCallHash_vm_hit.

Lemma t14_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 26 28 getPendingHookCallHash_vm_code (M14_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 25 29 getPendingHookCallHash_vm_code (M15_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M14_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingHookCallHash_vm_hit.

Lemma t15_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 25 29 getPendingHookCallHash_vm_code (M15_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 24 30 getPendingHookCallHash_vm_code (M16_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M15_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingHookCallHash_vm_hit.

Lemma t16_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 24 30 getPendingHookCallHash_vm_code (M16_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 23 31 getPendingHookCallHash_vm_code (M17_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M16_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingHookCallHash_vm_hit.

Lemma t17_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 23 31 getPendingHookCallHash_vm_code (M17_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 22 34 getPendingHookCallHash_vm_code (M18_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M17_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingHookCallHash_vm_hit.

Lemma t18_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 22 34 getPendingHookCallHash_vm_code (M18_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 21 35 getPendingHookCallHash_vm_code (M19_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M18_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingHookCallHash_vm_hit.

Lemma t19_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 21 35 getPendingHookCallHash_vm_code (M19_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 20 36 getPendingHookCallHash_vm_code (M20_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Htok.
 rewrite run_S.
 cbn [M19_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t19_getPendingHookCallHash_vm_hit.

Lemma t20_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 20 36 getPendingHookCallHash_vm_code (M20_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 19 37 getPendingHookCallHash_vm_code (M21_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M20_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getPendingHookCallHash_vm_hit.

Lemma t21_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 19 37 getPendingHookCallHash_vm_code (M21_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 18 4 getPendingHookCallHash_vm_code (M22_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M21_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getPendingHookCallHash_vm_hit.

Lemma t22_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 18 4 getPendingHookCallHash_vm_code (M22_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 17 5 getPendingHookCallHash_vm_code (M23_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M22_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getPendingHookCallHash_vm_hit.

Lemma t23_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 17 5 getPendingHookCallHash_vm_code (M23_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 16 6 getPendingHookCallHash_vm_code (M24_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M23_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getPendingHookCallHash_vm_hit.

Lemma t24_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 16 6 getPendingHookCallHash_vm_code (M24_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 15 7 getPendingHookCallHash_vm_code (M25_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M24_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getPendingHookCallHash_vm_hit.

Lemma t25_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 15 7 getPendingHookCallHash_vm_code (M25_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 14 8 getPendingHookCallHash_vm_code (M26_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M25_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t25_getPendingHookCallHash_vm_hit.

Lemma t26_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 14 8 getPendingHookCallHash_vm_code (M26_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 13 13 getPendingHookCallHash_vm_code (M27_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M26_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t26_getPendingHookCallHash_vm_hit.

Lemma t27_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 13 13 getPendingHookCallHash_vm_code (M27_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 12 14 getPendingHookCallHash_vm_code (M28_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M27_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t27_getPendingHookCallHash_vm_hit.

Lemma t28_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 12 14 getPendingHookCallHash_vm_code (M28_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 11 15 getPendingHookCallHash_vm_code (M29_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M28_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t28_getPendingHookCallHash_vm_hit.

Lemma t29_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Hnth : nth_error xs (Z.to_nat 1%Z) = Some v),
 run 11 15 getPendingHookCallHash_vm_code (M29_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 10 16 getPendingHookCallHash_vm_code (M30_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Hnth.
 rewrite run_S.
 cbn [M29_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t29_getPendingHookCallHash_vm_hit.

Lemma t30_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 10 16 getPendingHookCallHash_vm_code (M30_getPendingHookCallHash_vm_hit tok sto account payload xs v) =
 run 9 17 getPendingHookCallHash_vm_code (M31_getPendingHookCallHash_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M30_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t30_getPendingHookCallHash_vm_hit.

Lemma t31_getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 9 17 getPendingHookCallHash_vm_code (M31_getPendingHookCallHash_vm_hit tok sto account payload xs v) = Done v.
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M31_getPendingHookCallHash_vm_hit getPendingHookCallHash_vm_init getPendingHookCallHash_vm_code getPendingHookCallHash_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t31_getPendingHookCallHash_vm_hit.

Theorem getPendingHookCallHash_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (getPendingHookCallHash_prefix ++ account) = None ->
 run 40 0 getPendingHookCallHash_vm_code (getPendingHookCallHash_vm_init tok sto account) = Done (GBytes []) /\
 getPendingHookCallHash_binding tok sto account = OK (GBytes []).
Proof.
 intros tok sto account Hstore. split.
 - exact (eq_trans (t0_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t1_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t2_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t3_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t4_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t5_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t6_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t7_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t8_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t9_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t10_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t11_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t12_getPendingHookCallHash_vm_miss tok sto account Hstore) (eq_trans (t13_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t14_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t15_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t16_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t17_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t18_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t19_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t20_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t21_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t22_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t23_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t24_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t25_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t26_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t27_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t28_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t29_getPendingHookCallHash_vm_miss tok sto account) (eq_trans (t30_getPendingHookCallHash_vm_miss tok sto account) (t31_getPendingHookCallHash_vm_miss tok sto account)))))))))))))))))))))))))))))))).
 - apply getPendingHookCallHash_source_miss. exact Hstore.
Qed.
Print Assumptions getPendingHookCallHash_vm_miss.
Theorem getPendingHookCallHash_vm_hit : forall (tok : nat -> GVal -> GVal) sto account (payload : bytes) (xs : list GVal) (v : GVal),
 sto (getPendingHookCallHash_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs (Z.to_nat 1%Z) = Some v ->
 run 40 0 getPendingHookCallHash_vm_code (getPendingHookCallHash_vm_init tok sto account) = Done v /\
 getPendingHookCallHash_binding tok sto account = OK v.
Proof.
 intros tok sto account payload xs v Hstore Htok Hnth. split.
 - exact (eq_trans (t0_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t1_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t2_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t3_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t4_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t5_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t6_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t7_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t8_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t9_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t10_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t11_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t12_getPendingHookCallHash_vm_hit tok sto account payload xs v Hstore) (eq_trans (t13_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t14_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t15_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t16_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t17_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t18_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t19_getPendingHookCallHash_vm_hit tok sto account payload xs v Htok) (eq_trans (t20_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t21_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t22_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t23_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t24_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t25_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t26_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t27_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t28_getPendingHookCallHash_vm_hit tok sto account payload xs v) (eq_trans (t29_getPendingHookCallHash_vm_hit tok sto account payload xs v Hnth) (eq_trans (t30_getPendingHookCallHash_vm_hit tok sto account payload xs v) (t31_getPendingHookCallHash_vm_hit tok sto account payload xs v)))))))))))))))))))))))))))))))).
 - apply getPendingHookCallHash_source_hit with (payload := payload) (xs := xs) (v := v); assumption.
Qed.
Print Assumptions getPendingHookCallHash_vm_hit.
