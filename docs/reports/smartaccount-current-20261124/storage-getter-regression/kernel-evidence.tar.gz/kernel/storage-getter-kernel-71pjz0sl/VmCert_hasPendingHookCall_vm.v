From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition hasPendingHookCall_vm_program : list Ins :=
 [InitSlot 0 1; LdArg; LdStatic 22; Call 8; Push GNull; NotEqualIns; Jump 7; Ret; InitSlot 2 2; LdArgN 1; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 24; Push GNull; Jump 27; LdLoc 1; CallToken 4; Jump 27; Ret].
Definition hasPendingHookCall_vm_code (pc : nat) : Ins := nth pc hasPendingHookCall_vm_program Unsupported.
Definition hasPendingHookCall_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 22 then Some (GBytes hasPendingHookCall_prefix) else None.
Definition hasPendingHookCall_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account; GBytes hasPendingHookCall_prefix] hasPendingHookCall_vm_statics sto [] tok.

Definition M0_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 hasPendingHookCall_vm_init tok sto account.

Definition M1_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := []; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := []; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M5_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M6_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M7_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingHookCall_prefix; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M8_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingHookCall_prefix; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M9_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingHookCall_prefix ++ account); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M10_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M11_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingHookCall_prefix ++ account); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M12_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (hasPendingHookCall_prefix ++ account); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M13_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M14_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M15_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M16_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M17_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M18_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M19_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M20_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M21_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_hasPendingHookCall_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 30 0 hasPendingHookCall_vm_code (M0_hasPendingHookCall_vm_miss tok sto account) =
 run 29 1 hasPendingHookCall_vm_code (M1_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_hasPendingHookCall_vm_miss.

Lemma t1_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 29 1 hasPendingHookCall_vm_code (M1_hasPendingHookCall_vm_miss tok sto account) =
 run 28 2 hasPendingHookCall_vm_code (M2_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_hasPendingHookCall_vm_miss.

Lemma t2_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 28 2 hasPendingHookCall_vm_code (M2_hasPendingHookCall_vm_miss tok sto account) =
 run 27 3 hasPendingHookCall_vm_code (M3_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_hasPendingHookCall_vm_miss.

Lemma t3_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 3 hasPendingHookCall_vm_code (M3_hasPendingHookCall_vm_miss tok sto account) =
 run 26 8 hasPendingHookCall_vm_code (M4_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_hasPendingHookCall_vm_miss.

Lemma t4_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 8 hasPendingHookCall_vm_code (M4_hasPendingHookCall_vm_miss tok sto account) =
 run 25 9 hasPendingHookCall_vm_code (M5_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_hasPendingHookCall_vm_miss.

Lemma t5_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 9 hasPendingHookCall_vm_code (M5_hasPendingHookCall_vm_miss tok sto account) =
 run 24 10 hasPendingHookCall_vm_code (M6_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_hasPendingHookCall_vm_miss.

Lemma t6_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 10 hasPendingHookCall_vm_code (M6_hasPendingHookCall_vm_miss tok sto account) =
 run 23 11 hasPendingHookCall_vm_code (M7_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_hasPendingHookCall_vm_miss.

Lemma t7_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 11 hasPendingHookCall_vm_code (M7_hasPendingHookCall_vm_miss tok sto account) =
 run 22 12 hasPendingHookCall_vm_code (M8_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_hasPendingHookCall_vm_miss.

Lemma t8_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 12 hasPendingHookCall_vm_code (M8_hasPendingHookCall_vm_miss tok sto account) =
 run 21 13 hasPendingHookCall_vm_code (M9_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M8_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_hasPendingHookCall_vm_miss.

Lemma t9_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 13 hasPendingHookCall_vm_code (M9_hasPendingHookCall_vm_miss tok sto account) =
 run 20 14 hasPendingHookCall_vm_code (M10_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_hasPendingHookCall_vm_miss.

Lemma t10_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 20 14 hasPendingHookCall_vm_code (M10_hasPendingHookCall_vm_miss tok sto account) =
 run 19 15 hasPendingHookCall_vm_code (M11_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_hasPendingHookCall_vm_miss.

Lemma t11_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 15 hasPendingHookCall_vm_code (M11_hasPendingHookCall_vm_miss tok sto account) =
 run 18 16 hasPendingHookCall_vm_code (M12_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M11_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_hasPendingHookCall_vm_miss.

Lemma t12_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (Hstore : sto (hasPendingHookCall_prefix ++ account) = None),
 run 18 16 hasPendingHookCall_vm_code (M12_hasPendingHookCall_vm_miss tok sto account) =
 run 17 17 hasPendingHookCall_vm_code (M13_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account Hstore.
 rewrite run_S.
 cbn [M12_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t12_hasPendingHookCall_vm_miss.

Lemma t13_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 17 hasPendingHookCall_vm_code (M13_hasPendingHookCall_vm_miss tok sto account) =
 run 16 18 hasPendingHookCall_vm_code (M14_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_hasPendingHookCall_vm_miss.

Lemma t14_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 18 hasPendingHookCall_vm_code (M14_hasPendingHookCall_vm_miss tok sto account) =
 run 15 19 hasPendingHookCall_vm_code (M15_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_hasPendingHookCall_vm_miss.

Lemma t15_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 19 hasPendingHookCall_vm_code (M15_hasPendingHookCall_vm_miss tok sto account) =
 run 14 20 hasPendingHookCall_vm_code (M16_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_hasPendingHookCall_vm_miss.

Lemma t16_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 20 hasPendingHookCall_vm_code (M16_hasPendingHookCall_vm_miss tok sto account) =
 run 13 21 hasPendingHookCall_vm_code (M17_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_hasPendingHookCall_vm_miss.

Lemma t17_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 21 hasPendingHookCall_vm_code (M17_hasPendingHookCall_vm_miss tok sto account) =
 run 12 22 hasPendingHookCall_vm_code (M18_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M17_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_hasPendingHookCall_vm_miss.

Lemma t18_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 22 hasPendingHookCall_vm_code (M18_hasPendingHookCall_vm_miss tok sto account) =
 run 11 23 hasPendingHookCall_vm_code (M19_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M18_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_hasPendingHookCall_vm_miss.

Lemma t19_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 11 23 hasPendingHookCall_vm_code (M19_hasPendingHookCall_vm_miss tok sto account) =
 run 10 27 hasPendingHookCall_vm_code (M20_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M19_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_hasPendingHookCall_vm_miss.

Lemma t20_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 10 27 hasPendingHookCall_vm_code (M20_hasPendingHookCall_vm_miss tok sto account) =
 run 9 4 hasPendingHookCall_vm_code (M21_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M20_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_hasPendingHookCall_vm_miss.

Lemma t21_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 9 4 hasPendingHookCall_vm_code (M21_hasPendingHookCall_vm_miss tok sto account) =
 run 8 5 hasPendingHookCall_vm_code (M22_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M21_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_hasPendingHookCall_vm_miss.

Lemma t22_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 8 5 hasPendingHookCall_vm_code (M22_hasPendingHookCall_vm_miss tok sto account) =
 run 7 6 hasPendingHookCall_vm_code (M23_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M22_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_hasPendingHookCall_vm_miss.

Lemma t23_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 7 6 hasPendingHookCall_vm_code (M23_hasPendingHookCall_vm_miss tok sto account) =
 run 6 7 hasPendingHookCall_vm_code (M24_hasPendingHookCall_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M23_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_hasPendingHookCall_vm_miss.

Lemma t24_hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 6 7 hasPendingHookCall_vm_code (M24_hasPendingHookCall_vm_miss tok sto account) = Done (GBool false).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M24_hasPendingHookCall_vm_miss hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_hasPendingHookCall_vm_miss.
Definition M0_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 hasPendingHookCall_vm_init tok sto account.

Definition M1_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := []; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := []; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M5_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M6_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M7_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingHookCall_prefix; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M8_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingHookCall_prefix; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M9_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingHookCall_prefix ++ account); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M10_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M11_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingHookCall_prefix ++ account); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M12_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (hasPendingHookCall_prefix ++ account); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M13_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GNull]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M14_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M15_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M16_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M17_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool false; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M18_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M19_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M20_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [tok 4%nat (GBytes payload); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M21_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [tok 4%nat (GBytes payload); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M22_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [tok 4%nat (GBytes payload); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; tok 4%nat (GBytes payload); GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M26_hasPendingHookCall_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true; GBytes hasPendingHookCall_prefix; GBytes account]; mlocals := [GBytes (hasPendingHookCall_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes hasPendingHookCall_prefix];
    mstatics := hasPendingHookCall_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 30 0 hasPendingHookCall_vm_code (M0_hasPendingHookCall_vm_hit tok sto account payload) =
 run 29 1 hasPendingHookCall_vm_code (M1_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M0_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_hasPendingHookCall_vm_hit.

Lemma t1_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 29 1 hasPendingHookCall_vm_code (M1_hasPendingHookCall_vm_hit tok sto account payload) =
 run 28 2 hasPendingHookCall_vm_code (M2_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M1_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_hasPendingHookCall_vm_hit.

Lemma t2_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 28 2 hasPendingHookCall_vm_code (M2_hasPendingHookCall_vm_hit tok sto account payload) =
 run 27 3 hasPendingHookCall_vm_code (M3_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M2_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_hasPendingHookCall_vm_hit.

Lemma t3_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 27 3 hasPendingHookCall_vm_code (M3_hasPendingHookCall_vm_hit tok sto account payload) =
 run 26 8 hasPendingHookCall_vm_code (M4_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M3_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_hasPendingHookCall_vm_hit.

Lemma t4_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 26 8 hasPendingHookCall_vm_code (M4_hasPendingHookCall_vm_hit tok sto account payload) =
 run 25 9 hasPendingHookCall_vm_code (M5_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M4_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_hasPendingHookCall_vm_hit.

Lemma t5_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 25 9 hasPendingHookCall_vm_code (M5_hasPendingHookCall_vm_hit tok sto account payload) =
 run 24 10 hasPendingHookCall_vm_code (M6_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M5_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_hasPendingHookCall_vm_hit.

Lemma t6_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 24 10 hasPendingHookCall_vm_code (M6_hasPendingHookCall_vm_hit tok sto account payload) =
 run 23 11 hasPendingHookCall_vm_code (M7_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M6_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_hasPendingHookCall_vm_hit.

Lemma t7_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 23 11 hasPendingHookCall_vm_code (M7_hasPendingHookCall_vm_hit tok sto account payload) =
 run 22 12 hasPendingHookCall_vm_code (M8_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M7_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_hasPendingHookCall_vm_hit.

Lemma t8_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 22 12 hasPendingHookCall_vm_code (M8_hasPendingHookCall_vm_hit tok sto account payload) =
 run 21 13 hasPendingHookCall_vm_code (M9_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M8_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_hasPendingHookCall_vm_hit.

Lemma t9_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 21 13 hasPendingHookCall_vm_code (M9_hasPendingHookCall_vm_hit tok sto account payload) =
 run 20 14 hasPendingHookCall_vm_code (M10_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M9_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_hasPendingHookCall_vm_hit.

Lemma t10_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 20 14 hasPendingHookCall_vm_code (M10_hasPendingHookCall_vm_hit tok sto account payload) =
 run 19 15 hasPendingHookCall_vm_code (M11_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M10_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_hasPendingHookCall_vm_hit.

Lemma t11_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 19 15 hasPendingHookCall_vm_code (M11_hasPendingHookCall_vm_hit tok sto account payload) =
 run 18 16 hasPendingHookCall_vm_code (M12_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M11_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_hasPendingHookCall_vm_hit.

Lemma t12_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (Hstore : sto (hasPendingHookCall_prefix ++ account) = Some payload),
 run 18 16 hasPendingHookCall_vm_code (M12_hasPendingHookCall_vm_hit tok sto account payload) =
 run 17 17 hasPendingHookCall_vm_code (M13_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload Hstore.
 rewrite run_S.
 cbn [M12_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t12_hasPendingHookCall_vm_hit.

Lemma t13_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 17 17 hasPendingHookCall_vm_code (M13_hasPendingHookCall_vm_hit tok sto account payload) =
 run 16 18 hasPendingHookCall_vm_code (M14_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M13_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_hasPendingHookCall_vm_hit.

Lemma t14_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 16 18 hasPendingHookCall_vm_code (M14_hasPendingHookCall_vm_hit tok sto account payload) =
 run 15 19 hasPendingHookCall_vm_code (M15_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M14_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_hasPendingHookCall_vm_hit.

Lemma t15_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 15 19 hasPendingHookCall_vm_code (M15_hasPendingHookCall_vm_hit tok sto account payload) =
 run 14 20 hasPendingHookCall_vm_code (M16_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M15_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_hasPendingHookCall_vm_hit.

Lemma t16_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 14 20 hasPendingHookCall_vm_code (M16_hasPendingHookCall_vm_hit tok sto account payload) =
 run 13 21 hasPendingHookCall_vm_code (M17_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M16_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_hasPendingHookCall_vm_hit.

Lemma t17_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 13 21 hasPendingHookCall_vm_code (M17_hasPendingHookCall_vm_hit tok sto account payload) =
 run 12 24 hasPendingHookCall_vm_code (M18_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M17_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_hasPendingHookCall_vm_hit.

Lemma t18_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 12 24 hasPendingHookCall_vm_code (M18_hasPendingHookCall_vm_hit tok sto account payload) =
 run 11 25 hasPendingHookCall_vm_code (M19_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M18_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_hasPendingHookCall_vm_hit.

Lemma t19_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 11 25 hasPendingHookCall_vm_code (M19_hasPendingHookCall_vm_hit tok sto account payload) =
 run 10 26 hasPendingHookCall_vm_code (M20_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M19_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_hasPendingHookCall_vm_hit.

Lemma t20_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 10 26 hasPendingHookCall_vm_code (M20_hasPendingHookCall_vm_hit tok sto account payload) =
 run 9 27 hasPendingHookCall_vm_code (M21_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M20_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_hasPendingHookCall_vm_hit.

Lemma t21_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 9 27 hasPendingHookCall_vm_code (M21_hasPendingHookCall_vm_hit tok sto account payload) =
 run 8 4 hasPendingHookCall_vm_code (M22_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M21_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_hasPendingHookCall_vm_hit.

Lemma t22_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 8 4 hasPendingHookCall_vm_code (M22_hasPendingHookCall_vm_hit tok sto account payload) =
 run 7 5 hasPendingHookCall_vm_code (M23_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M22_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_hasPendingHookCall_vm_hit.

Lemma t23_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (Hne : gval_eqb GNull (tok 4%nat (GBytes payload)) = false),
 run 7 5 hasPendingHookCall_vm_code (M23_hasPendingHookCall_vm_hit tok sto account payload) =
 run 6 6 hasPendingHookCall_vm_code (M24_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload Hne.
 rewrite run_S.
 cbn [M23_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens firstn skipn].
 rewrite Hne.
 reflexivity.
Qed.
Print Assumptions t23_hasPendingHookCall_vm_hit.

Lemma t24_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 6 6 hasPendingHookCall_vm_code (M24_hasPendingHookCall_vm_hit tok sto account payload) =
 run 5 7 hasPendingHookCall_vm_code (M25_hasPendingHookCall_vm_hit tok sto account payload).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M24_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_hasPendingHookCall_vm_hit.

Lemma t25_hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes),
 run 5 7 hasPendingHookCall_vm_code (M25_hasPendingHookCall_vm_hit tok sto account payload) = Done (GBool true).
Proof.
 intros tok sto account payload.
 rewrite run_S.
 cbn [M25_hasPendingHookCall_vm_hit hasPendingHookCall_vm_init hasPendingHookCall_vm_code hasPendingHookCall_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t25_hasPendingHookCall_vm_hit.

Theorem hasPendingHookCall_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (hasPendingHookCall_prefix ++ account) = None ->
 run 30 0 hasPendingHookCall_vm_code (hasPendingHookCall_vm_init tok sto account) = Done (GBool false) /\
 hasPendingHookCall_binding tok sto account = OK (GBool false).
Proof.
 intros tok sto account Hstore. split.
 - exact (eq_trans (t0_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t1_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t2_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t3_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t4_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t5_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t6_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t7_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t8_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t9_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t10_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t11_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t12_hasPendingHookCall_vm_miss tok sto account Hstore) (eq_trans (t13_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t14_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t15_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t16_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t17_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t18_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t19_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t20_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t21_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t22_hasPendingHookCall_vm_miss tok sto account) (eq_trans (t23_hasPendingHookCall_vm_miss tok sto account) (t24_hasPendingHookCall_vm_miss tok sto account))))))))))))))))))))))))).
 - apply hasPendingHookCall_source_miss. exact Hstore.
Qed.
Print Assumptions hasPendingHookCall_vm_miss.
Theorem hasPendingHookCall_vm_hit : forall (tok : nat -> GVal -> GVal) sto account payload,
 sto (hasPendingHookCall_prefix ++ account) = Some payload ->
 gval_eqb GNull (tok 4%nat (GBytes payload)) = false ->
 run 30 0 hasPendingHookCall_vm_code (hasPendingHookCall_vm_init tok sto account) = Done (GBool true) /\
 hasPendingHookCall_binding tok sto account = OK (GBool true).
Proof.
 intros tok sto account payload Hstore Hne. split.
 - exact (eq_trans (t0_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t1_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t2_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t3_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t4_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t5_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t6_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t7_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t8_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t9_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t10_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t11_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t12_hasPendingHookCall_vm_hit tok sto account payload Hstore) (eq_trans (t13_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t14_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t15_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t16_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t17_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t18_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t19_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t20_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t21_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t22_hasPendingHookCall_vm_hit tok sto account payload) (eq_trans (t23_hasPendingHookCall_vm_hit tok sto account payload Hne) (eq_trans (t24_hasPendingHookCall_vm_hit tok sto account payload) (t25_hasPendingHookCall_vm_hit tok sto account payload)))))))))))))))))))))))))).
 - apply hasPendingHookCall_source_hit with (payload := payload); assumption.
Qed.
Print Assumptions hasPendingHookCall_vm_hit.
