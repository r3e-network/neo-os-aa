From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getEscapeTimelock_vm_program : list Ins :=
 [InitSlot 0 1; LdArg; Call 7; Push (GInt 3); PickItem; Jump 6; Ret; InitSlot 2 1; LdStatic 8; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; NotEqualIns; JumpIf 23; Push (GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]); AbortMsg; LdLoc 1; CallToken 4; Jump 26; Ret].
Definition getEscapeTimelock_vm_code (pc : nat) : Ins := nth pc getEscapeTimelock_vm_program Unsupported.
Definition getEscapeTimelock_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 8 then Some (GBytes account_state_prefix) else None.
Definition getEscapeTimelock_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account] getEscapeTimelock_vm_statics sto [] tok.

Definition M0_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 getEscapeTimelock_vm_init tok sto account.

Definition M1_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M4_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M5_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M6_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M7_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M8_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M9_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M10_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M11_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M12_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M13_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M14_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M15_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M16_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M17_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M18_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M19_getEscapeTimelock_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Lemma t0_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 29 0 getEscapeTimelock_vm_code (M0_getEscapeTimelock_vm_miss tok sto account) =
 run 28 1 getEscapeTimelock_vm_code (M1_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getEscapeTimelock_vm_miss.

Lemma t1_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 28 1 getEscapeTimelock_vm_code (M1_getEscapeTimelock_vm_miss tok sto account) =
 run 27 2 getEscapeTimelock_vm_code (M2_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getEscapeTimelock_vm_miss.

Lemma t2_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 2 getEscapeTimelock_vm_code (M2_getEscapeTimelock_vm_miss tok sto account) =
 run 26 7 getEscapeTimelock_vm_code (M3_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getEscapeTimelock_vm_miss.

Lemma t3_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 7 getEscapeTimelock_vm_code (M3_getEscapeTimelock_vm_miss tok sto account) =
 run 25 8 getEscapeTimelock_vm_code (M4_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getEscapeTimelock_vm_miss.

Lemma t4_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 8 getEscapeTimelock_vm_code (M4_getEscapeTimelock_vm_miss tok sto account) =
 run 24 9 getEscapeTimelock_vm_code (M5_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getEscapeTimelock_vm_miss.

Lemma t5_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 9 getEscapeTimelock_vm_code (M5_getEscapeTimelock_vm_miss tok sto account) =
 run 23 10 getEscapeTimelock_vm_code (M6_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getEscapeTimelock_vm_miss.

Lemma t6_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 10 getEscapeTimelock_vm_code (M6_getEscapeTimelock_vm_miss tok sto account) =
 run 22 11 getEscapeTimelock_vm_code (M7_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getEscapeTimelock_vm_miss.

Lemma t7_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 11 getEscapeTimelock_vm_code (M7_getEscapeTimelock_vm_miss tok sto account) =
 run 21 12 getEscapeTimelock_vm_code (M8_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getEscapeTimelock_vm_miss.

Lemma t8_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 12 getEscapeTimelock_vm_code (M8_getEscapeTimelock_vm_miss tok sto account) =
 run 20 13 getEscapeTimelock_vm_code (M9_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M8_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getEscapeTimelock_vm_miss.

Lemma t9_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 20 13 getEscapeTimelock_vm_code (M9_getEscapeTimelock_vm_miss tok sto account) =
 run 19 14 getEscapeTimelock_vm_code (M10_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getEscapeTimelock_vm_miss.

Lemma t10_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 14 getEscapeTimelock_vm_code (M10_getEscapeTimelock_vm_miss tok sto account) =
 run 18 15 getEscapeTimelock_vm_code (M11_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getEscapeTimelock_vm_miss.

Lemma t11_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (H : sto (account_state_prefix ++ account) = None),
 run 18 15 getEscapeTimelock_vm_code (M11_getEscapeTimelock_vm_miss tok sto account) =
 run 17 16 getEscapeTimelock_vm_code (M12_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account H.
 rewrite run_S.
 cbn [M11_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite H.
 reflexivity.
Qed.
Print Assumptions t11_getEscapeTimelock_vm_miss.

Lemma t12_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 16 getEscapeTimelock_vm_code (M12_getEscapeTimelock_vm_miss tok sto account) =
 run 16 17 getEscapeTimelock_vm_code (M13_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M12_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getEscapeTimelock_vm_miss.

Lemma t13_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 17 getEscapeTimelock_vm_code (M13_getEscapeTimelock_vm_miss tok sto account) =
 run 15 18 getEscapeTimelock_vm_code (M14_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getEscapeTimelock_vm_miss.

Lemma t14_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 18 getEscapeTimelock_vm_code (M14_getEscapeTimelock_vm_miss tok sto account) =
 run 14 19 getEscapeTimelock_vm_code (M15_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getEscapeTimelock_vm_miss.

Lemma t15_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 19 getEscapeTimelock_vm_code (M15_getEscapeTimelock_vm_miss tok sto account) =
 run 13 20 getEscapeTimelock_vm_code (M16_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getEscapeTimelock_vm_miss.

Lemma t16_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 20 getEscapeTimelock_vm_code (M16_getEscapeTimelock_vm_miss tok sto account) =
 run 12 21 getEscapeTimelock_vm_code (M17_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getEscapeTimelock_vm_miss.

Lemma t17_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 21 getEscapeTimelock_vm_code (M17_getEscapeTimelock_vm_miss tok sto account) =
 run 11 22 getEscapeTimelock_vm_code (M18_getEscapeTimelock_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M17_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getEscapeTimelock_vm_miss.

Lemma t18_getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 11 22 getEscapeTimelock_vm_code (M18_getEscapeTimelock_vm_miss tok sto account) = Thrown.
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M18_getEscapeTimelock_vm_miss getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getEscapeTimelock_vm_miss.
Definition M0_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 getEscapeTimelock_vm_init tok sto account.

Definition M1_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M4_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M5_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M6_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M7_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M8_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M9_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M10_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M11_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M12_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M13_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M14_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M15_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M16_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBool true; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M17_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M18_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M19_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M20_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M21_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GInt 3%Z; GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getEscapeTimelock_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getEscapeTimelock_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 29 0 getEscapeTimelock_vm_code (M0_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 28 1 getEscapeTimelock_vm_code (M1_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M0_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getEscapeTimelock_vm_hit.

Lemma t1_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 28 1 getEscapeTimelock_vm_code (M1_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 27 2 getEscapeTimelock_vm_code (M2_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M1_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getEscapeTimelock_vm_hit.

Lemma t2_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 27 2 getEscapeTimelock_vm_code (M2_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 26 7 getEscapeTimelock_vm_code (M3_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M2_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getEscapeTimelock_vm_hit.

Lemma t3_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 26 7 getEscapeTimelock_vm_code (M3_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 25 8 getEscapeTimelock_vm_code (M4_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M3_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getEscapeTimelock_vm_hit.

Lemma t4_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 25 8 getEscapeTimelock_vm_code (M4_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 24 9 getEscapeTimelock_vm_code (M5_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M4_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getEscapeTimelock_vm_hit.

Lemma t5_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 24 9 getEscapeTimelock_vm_code (M5_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 23 10 getEscapeTimelock_vm_code (M6_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M5_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getEscapeTimelock_vm_hit.

Lemma t6_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 23 10 getEscapeTimelock_vm_code (M6_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 22 11 getEscapeTimelock_vm_code (M7_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M6_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getEscapeTimelock_vm_hit.

Lemma t7_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 22 11 getEscapeTimelock_vm_code (M7_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 21 12 getEscapeTimelock_vm_code (M8_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M7_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getEscapeTimelock_vm_hit.

Lemma t8_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 21 12 getEscapeTimelock_vm_code (M8_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 20 13 getEscapeTimelock_vm_code (M9_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M8_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getEscapeTimelock_vm_hit.

Lemma t9_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 20 13 getEscapeTimelock_vm_code (M9_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 19 14 getEscapeTimelock_vm_code (M10_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M9_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getEscapeTimelock_vm_hit.

Lemma t10_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 19 14 getEscapeTimelock_vm_code (M10_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 18 15 getEscapeTimelock_vm_code (M11_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M10_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getEscapeTimelock_vm_hit.

Lemma t11_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (H : sto (account_state_prefix ++ account) = Some payload),
 run 18 15 getEscapeTimelock_vm_code (M11_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 17 16 getEscapeTimelock_vm_code (M12_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v H.
 rewrite run_S.
 cbn [M11_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite H.
 reflexivity.
Qed.
Print Assumptions t11_getEscapeTimelock_vm_hit.

Lemma t12_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 17 16 getEscapeTimelock_vm_code (M12_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 16 17 getEscapeTimelock_vm_code (M13_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M12_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getEscapeTimelock_vm_hit.

Lemma t13_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 16 17 getEscapeTimelock_vm_code (M13_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 15 18 getEscapeTimelock_vm_code (M14_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M13_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getEscapeTimelock_vm_hit.

Lemma t14_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 15 18 getEscapeTimelock_vm_code (M14_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 14 19 getEscapeTimelock_vm_code (M15_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M14_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getEscapeTimelock_vm_hit.

Lemma t15_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 14 19 getEscapeTimelock_vm_code (M15_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 13 20 getEscapeTimelock_vm_code (M16_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M15_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getEscapeTimelock_vm_hit.

Lemma t16_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 13 20 getEscapeTimelock_vm_code (M16_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 12 23 getEscapeTimelock_vm_code (M17_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M16_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getEscapeTimelock_vm_hit.

Lemma t17_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 12 23 getEscapeTimelock_vm_code (M17_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 11 24 getEscapeTimelock_vm_code (M18_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M17_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getEscapeTimelock_vm_hit.

Lemma t18_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 11 24 getEscapeTimelock_vm_code (M18_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 10 25 getEscapeTimelock_vm_code (M19_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Htok.
 rewrite run_S.
 cbn [M18_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t18_getEscapeTimelock_vm_hit.

Lemma t19_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 10 25 getEscapeTimelock_vm_code (M19_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 9 26 getEscapeTimelock_vm_code (M20_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M19_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getEscapeTimelock_vm_hit.

Lemma t20_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 9 26 getEscapeTimelock_vm_code (M20_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 8 3 getEscapeTimelock_vm_code (M21_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M20_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getEscapeTimelock_vm_hit.

Lemma t21_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 8 3 getEscapeTimelock_vm_code (M21_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 7 4 getEscapeTimelock_vm_code (M22_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M21_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getEscapeTimelock_vm_hit.

Lemma t22_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Hnth : nth_error xs (Z.to_nat 3%Z) = Some v),
 run 7 4 getEscapeTimelock_vm_code (M22_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 6 5 getEscapeTimelock_vm_code (M23_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Hnth.
 rewrite run_S.
 cbn [M22_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t22_getEscapeTimelock_vm_hit.

Lemma t23_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 6 5 getEscapeTimelock_vm_code (M23_getEscapeTimelock_vm_hit tok sto account payload xs v) =
 run 5 6 getEscapeTimelock_vm_code (M24_getEscapeTimelock_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M23_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getEscapeTimelock_vm_hit.

Lemma t24_getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 5 6 getEscapeTimelock_vm_code (M24_getEscapeTimelock_vm_hit tok sto account payload xs v) = Done v.
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M24_getEscapeTimelock_vm_hit getEscapeTimelock_vm_init getEscapeTimelock_vm_code getEscapeTimelock_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getEscapeTimelock_vm_hit.

Theorem getEscapeTimelock_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (account_state_prefix ++ account) = None ->
 run 29 0 getEscapeTimelock_vm_code (getEscapeTimelock_vm_init tok sto account) = Thrown /\
 account_state_outcome tok 3 sto account = Fault.
Proof.
 intros tok sto account H. split.
 - exact (eq_trans (t0_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t1_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t2_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t3_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t4_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t5_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t6_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t7_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t8_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t9_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t10_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t11_getEscapeTimelock_vm_miss tok sto account H) (eq_trans (t12_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t13_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t14_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t15_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t16_getEscapeTimelock_vm_miss tok sto account) (eq_trans (t17_getEscapeTimelock_vm_miss tok sto account) (t18_getEscapeTimelock_vm_miss tok sto account))))))))))))))))))).
 - apply getEscapeTimelock_source_miss with (sto := sto) (account := account)
     (tok := tok). exact H.
Qed.
Print Assumptions getEscapeTimelock_vm_miss.
Theorem getEscapeTimelock_vm_hit : forall (tok : nat -> GVal -> GVal) sto account payload xs v,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 3%nat = Some v ->
 run 29 0 getEscapeTimelock_vm_code (getEscapeTimelock_vm_init tok sto account) = Done v /\
 account_state_outcome tok 3 sto account = OK v.
Proof.
 intros tok sto account payload xs v H Htok Hnth. split.
 - exact (eq_trans (t0_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t1_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t2_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t3_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t4_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t5_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t6_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t7_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t8_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t9_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t10_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t11_getEscapeTimelock_vm_hit tok sto account payload xs v H) (eq_trans (t12_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t13_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t14_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t15_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t16_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t17_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t18_getEscapeTimelock_vm_hit tok sto account payload xs v Htok) (eq_trans (t19_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t20_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t21_getEscapeTimelock_vm_hit tok sto account payload xs v) (eq_trans (t22_getEscapeTimelock_vm_hit tok sto account payload xs v Hnth) (eq_trans (t23_getEscapeTimelock_vm_hit tok sto account payload xs v) (t24_getEscapeTimelock_vm_hit tok sto account payload xs v))))))))))))))))))))))))).
 - apply getEscapeTimelock_source_hit with (payload := payload) (xs := xs) (v := v); assumption.
Qed.
Print Assumptions getEscapeTimelock_vm_hit.
