From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getMarketEscrowListingId_vm_program : list Ins :=
 [InitSlot 2 1; LdStatic 12; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 16; Push (GInt 0); Jump 24; LdLoc 1; Dup; IsNull; JumpIfNot 23; Drop; Push (GInt 0); Jump 24; Convert 33; Jump 25; Ret].
Definition getMarketEscrowListingId_vm_code (pc : nat) : Ins := nth pc getMarketEscrowListingId_vm_program Unsupported.
Definition getMarketEscrowListingId_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 12 then Some (GBytes getMarketEscrowListingId_prefix) else None.
Definition getMarketEscrowListingId_vm_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account] getMarketEscrowListingId_vm_statics sto [] (fun _ _ => GNull).

Definition M0_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 getMarketEscrowListingId_vm_init sto account.

Definition M1_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getMarketEscrowListingId_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getMarketEscrowListingId_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getMarketEscrowListingId_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getMarketEscrowListingId_prefix ++ account)]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getMarketEscrowListingId_prefix ++ account)]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getMarketEscrowListingId_prefix ++ account)]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getMarketEscrowListingId_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 28 0 getMarketEscrowListingId_vm_code (M0_getMarketEscrowListingId_vm_miss sto account) =
 run 27 1 getMarketEscrowListingId_vm_code (M1_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M0_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getMarketEscrowListingId_vm_miss.

Lemma t1_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 27 1 getMarketEscrowListingId_vm_code (M1_getMarketEscrowListingId_vm_miss sto account) =
 run 26 2 getMarketEscrowListingId_vm_code (M2_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M1_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getMarketEscrowListingId_vm_miss.

Lemma t2_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 26 2 getMarketEscrowListingId_vm_code (M2_getMarketEscrowListingId_vm_miss sto account) =
 run 25 3 getMarketEscrowListingId_vm_code (M3_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M2_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getMarketEscrowListingId_vm_miss.

Lemma t3_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 25 3 getMarketEscrowListingId_vm_code (M3_getMarketEscrowListingId_vm_miss sto account) =
 run 24 4 getMarketEscrowListingId_vm_code (M4_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M3_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getMarketEscrowListingId_vm_miss.

Lemma t4_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 24 4 getMarketEscrowListingId_vm_code (M4_getMarketEscrowListingId_vm_miss sto account) =
 run 23 5 getMarketEscrowListingId_vm_code (M5_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M4_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getMarketEscrowListingId_vm_miss.

Lemma t5_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 23 5 getMarketEscrowListingId_vm_code (M5_getMarketEscrowListingId_vm_miss sto account) =
 run 22 6 getMarketEscrowListingId_vm_code (M6_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M5_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getMarketEscrowListingId_vm_miss.

Lemma t6_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 22 6 getMarketEscrowListingId_vm_code (M6_getMarketEscrowListingId_vm_miss sto account) =
 run 21 7 getMarketEscrowListingId_vm_code (M7_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M6_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getMarketEscrowListingId_vm_miss.

Lemma t7_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 21 7 getMarketEscrowListingId_vm_code (M7_getMarketEscrowListingId_vm_miss sto account) =
 run 20 8 getMarketEscrowListingId_vm_code (M8_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M7_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getMarketEscrowListingId_vm_miss.

Lemma t8_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes) (Hstore : sto (getMarketEscrowListingId_prefix ++ account) = None),
 run 20 8 getMarketEscrowListingId_vm_code (M8_getMarketEscrowListingId_vm_miss sto account) =
 run 19 9 getMarketEscrowListingId_vm_code (M9_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account Hstore.
 rewrite run_S.
 cbn [M8_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getMarketEscrowListingId_vm_miss.

Lemma t9_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 19 9 getMarketEscrowListingId_vm_code (M9_getMarketEscrowListingId_vm_miss sto account) =
 run 18 10 getMarketEscrowListingId_vm_code (M10_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M9_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getMarketEscrowListingId_vm_miss.

Lemma t10_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 18 10 getMarketEscrowListingId_vm_code (M10_getMarketEscrowListingId_vm_miss sto account) =
 run 17 11 getMarketEscrowListingId_vm_code (M11_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M10_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getMarketEscrowListingId_vm_miss.

Lemma t11_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 17 11 getMarketEscrowListingId_vm_code (M11_getMarketEscrowListingId_vm_miss sto account) =
 run 16 12 getMarketEscrowListingId_vm_code (M12_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M11_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getMarketEscrowListingId_vm_miss.

Lemma t12_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 16 12 getMarketEscrowListingId_vm_code (M12_getMarketEscrowListingId_vm_miss sto account) =
 run 15 13 getMarketEscrowListingId_vm_code (M13_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M12_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getMarketEscrowListingId_vm_miss.

Lemma t13_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 15 13 getMarketEscrowListingId_vm_code (M13_getMarketEscrowListingId_vm_miss sto account) =
 run 14 14 getMarketEscrowListingId_vm_code (M14_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M13_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getMarketEscrowListingId_vm_miss.

Lemma t14_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 14 14 getMarketEscrowListingId_vm_code (M14_getMarketEscrowListingId_vm_miss sto account) =
 run 13 15 getMarketEscrowListingId_vm_code (M15_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M14_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getMarketEscrowListingId_vm_miss.

Lemma t15_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 13 15 getMarketEscrowListingId_vm_code (M15_getMarketEscrowListingId_vm_miss sto account) =
 run 12 24 getMarketEscrowListingId_vm_code (M16_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M15_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getMarketEscrowListingId_vm_miss.

Lemma t16_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 12 24 getMarketEscrowListingId_vm_code (M16_getMarketEscrowListingId_vm_miss sto account) =
 run 11 25 getMarketEscrowListingId_vm_code (M17_getMarketEscrowListingId_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M16_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getMarketEscrowListingId_vm_miss.

Lemma t17_getMarketEscrowListingId_vm_miss : forall (sto : storage) (account : bytes),
 run 11 25 getMarketEscrowListingId_vm_code (M17_getMarketEscrowListingId_vm_miss sto account) = Done (GInt 0%Z).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M17_getMarketEscrowListingId_vm_miss getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getMarketEscrowListingId_vm_miss.
Definition M0_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 getMarketEscrowListingId_vm_init sto account.

Definition M1_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes getMarketEscrowListingId_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getMarketEscrowListingId_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getMarketEscrowListingId_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes (getMarketEscrowListingId_prefix ++ account)]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes (getMarketEscrowListingId_prefix ++ account)]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getMarketEscrowListingId_prefix ++ account)]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M19_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt value]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M20_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt value]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M21_getMarketEscrowListingId_vm_hitint (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt value]; mlocals := [GBytes (getMarketEscrowListingId_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowListingId_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 28 0 getMarketEscrowListingId_vm_code (M0_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 27 1 getMarketEscrowListingId_vm_code (M1_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M0_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getMarketEscrowListingId_vm_hitint.

Lemma t1_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 27 1 getMarketEscrowListingId_vm_code (M1_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 26 2 getMarketEscrowListingId_vm_code (M2_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M1_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getMarketEscrowListingId_vm_hitint.

Lemma t2_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 26 2 getMarketEscrowListingId_vm_code (M2_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 25 3 getMarketEscrowListingId_vm_code (M3_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M2_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getMarketEscrowListingId_vm_hitint.

Lemma t3_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 25 3 getMarketEscrowListingId_vm_code (M3_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 24 4 getMarketEscrowListingId_vm_code (M4_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M3_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getMarketEscrowListingId_vm_hitint.

Lemma t4_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 24 4 getMarketEscrowListingId_vm_code (M4_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 23 5 getMarketEscrowListingId_vm_code (M5_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M4_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getMarketEscrowListingId_vm_hitint.

Lemma t5_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 23 5 getMarketEscrowListingId_vm_code (M5_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 22 6 getMarketEscrowListingId_vm_code (M6_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M5_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getMarketEscrowListingId_vm_hitint.

Lemma t6_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 22 6 getMarketEscrowListingId_vm_code (M6_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 21 7 getMarketEscrowListingId_vm_code (M7_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M6_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getMarketEscrowListingId_vm_hitint.

Lemma t7_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 21 7 getMarketEscrowListingId_vm_code (M7_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 20 8 getMarketEscrowListingId_vm_code (M8_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M7_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getMarketEscrowListingId_vm_hitint.

Lemma t8_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z) (Hstore : sto (getMarketEscrowListingId_prefix ++ account) = Some payload),
 run 20 8 getMarketEscrowListingId_vm_code (M8_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 19 9 getMarketEscrowListingId_vm_code (M9_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value Hstore.
 rewrite run_S.
 cbn [M8_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getMarketEscrowListingId_vm_hitint.

Lemma t9_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 19 9 getMarketEscrowListingId_vm_code (M9_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 18 10 getMarketEscrowListingId_vm_code (M10_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M9_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getMarketEscrowListingId_vm_hitint.

Lemma t10_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 18 10 getMarketEscrowListingId_vm_code (M10_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 17 11 getMarketEscrowListingId_vm_code (M11_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M10_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getMarketEscrowListingId_vm_hitint.

Lemma t11_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 17 11 getMarketEscrowListingId_vm_code (M11_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 16 12 getMarketEscrowListingId_vm_code (M12_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M11_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getMarketEscrowListingId_vm_hitint.

Lemma t12_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 16 12 getMarketEscrowListingId_vm_code (M12_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 15 13 getMarketEscrowListingId_vm_code (M13_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M12_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getMarketEscrowListingId_vm_hitint.

Lemma t13_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 15 13 getMarketEscrowListingId_vm_code (M13_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 14 16 getMarketEscrowListingId_vm_code (M14_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M13_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getMarketEscrowListingId_vm_hitint.

Lemma t14_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 14 16 getMarketEscrowListingId_vm_code (M14_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 13 17 getMarketEscrowListingId_vm_code (M15_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M14_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getMarketEscrowListingId_vm_hitint.

Lemma t15_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 13 17 getMarketEscrowListingId_vm_code (M15_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 12 18 getMarketEscrowListingId_vm_code (M16_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M15_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getMarketEscrowListingId_vm_hitint.

Lemma t16_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 12 18 getMarketEscrowListingId_vm_code (M16_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 11 19 getMarketEscrowListingId_vm_code (M17_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M16_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getMarketEscrowListingId_vm_hitint.

Lemma t17_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 11 19 getMarketEscrowListingId_vm_code (M17_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 10 23 getMarketEscrowListingId_vm_code (M18_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M17_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getMarketEscrowListingId_vm_hitint.

Lemma t18_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z) (Hdecode : decode_integer payload = OK (GInt value)),
 run 10 23 getMarketEscrowListingId_vm_code (M18_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 9 24 getMarketEscrowListingId_vm_code (M19_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value Hdecode.
 rewrite run_S.
 cbn [M18_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hdecode.
 reflexivity.
Qed.
Print Assumptions t18_getMarketEscrowListingId_vm_hitint.

Lemma t19_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 9 24 getMarketEscrowListingId_vm_code (M19_getMarketEscrowListingId_vm_hitint sto account payload value) =
 run 8 25 getMarketEscrowListingId_vm_code (M20_getMarketEscrowListingId_vm_hitint sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M19_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getMarketEscrowListingId_vm_hitint.

Lemma t20_getMarketEscrowListingId_vm_hitint : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 8 25 getMarketEscrowListingId_vm_code (M20_getMarketEscrowListingId_vm_hitint sto account payload value) = Done (GInt value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M20_getMarketEscrowListingId_vm_hitint getMarketEscrowListingId_vm_init getMarketEscrowListingId_vm_code getMarketEscrowListingId_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getMarketEscrowListingId_vm_hitint.

Theorem getMarketEscrowListingId_vm_miss : forall sto account,
 sto (getMarketEscrowListingId_prefix ++ account) = None ->
 run 28 0 getMarketEscrowListingId_vm_code (getMarketEscrowListingId_vm_init sto account) = Done (GInt 0%Z) /\
 getter_outcome getMarketEscrowListingId_prefix (GInt 0%Z) decode_integer sto account = OK (GInt 0%Z).
Proof.
 intros sto account Hstore. split.
 - exact (eq_trans (t0_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t1_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t2_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t3_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t4_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t5_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t6_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t7_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t8_getMarketEscrowListingId_vm_miss sto account Hstore) (eq_trans (t9_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t10_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t11_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t12_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t13_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t14_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t15_getMarketEscrowListingId_vm_miss sto account) (eq_trans (t16_getMarketEscrowListingId_vm_miss sto account) (t17_getMarketEscrowListingId_vm_miss sto account)))))))))))))))))).
 - unfold getter_outcome. rewrite Hstore. reflexivity.
Qed.
Print Assumptions getMarketEscrowListingId_vm_miss.
Theorem getMarketEscrowListingId_vm_hit_integer : forall sto account payload value,
 sto (getMarketEscrowListingId_prefix ++ account) = Some payload ->
 decode_integer payload = OK (GInt value) ->
 run 28 0 getMarketEscrowListingId_vm_code (getMarketEscrowListingId_vm_init sto account) = Done (GInt value) /\
 getter_outcome getMarketEscrowListingId_prefix (GInt 0%Z) decode_integer sto account = OK (GInt value).
Proof.
 intros sto account payload value Hstore Hdecode. split.
 - exact (eq_trans (t0_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t1_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t2_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t3_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t4_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t5_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t6_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t7_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t8_getMarketEscrowListingId_vm_hitint sto account payload value Hstore) (eq_trans (t9_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t10_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t11_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t12_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t13_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t14_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t15_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t16_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t17_getMarketEscrowListingId_vm_hitint sto account payload value) (eq_trans (t18_getMarketEscrowListingId_vm_hitint sto account payload value Hdecode) (eq_trans (t19_getMarketEscrowListingId_vm_hitint sto account payload value) (t20_getMarketEscrowListingId_vm_hitint sto account payload value))))))))))))))))))))).
 - unfold getter_outcome. rewrite Hstore, Hdecode. reflexivity.
Qed.
Print Assumptions getMarketEscrowListingId_vm_hit_integer.
