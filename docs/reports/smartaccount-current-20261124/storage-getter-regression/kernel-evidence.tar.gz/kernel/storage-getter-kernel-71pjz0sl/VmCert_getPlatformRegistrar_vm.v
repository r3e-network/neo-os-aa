From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getPlatformRegistrar_vm_program : list Ins :=
 [InitSlot 1 0; LdStatic 40; GetContext; StorageGet; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 11; Push (GBytes [0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat]); Jump 20; LdLoc 0; Dup; IsNull; JumpIf 20; Dup; SizeIns; Push (GInt 20%Z); JumpEq 20; Throw; Jump 21; Ret].
Definition getPlatformRegistrar_vm_code (pc : nat) : Ins := nth pc getPlatformRegistrar_vm_program Unsupported.
Definition getPlatformRegistrar_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 40 then Some (GBytes getPlatformRegistrar_prefix) else None.
Definition getPlatformRegistrar_vm_init (sto : storage) : Machine :=
 machine [] (repeat GNull 1) [] getPlatformRegistrar_vm_statics sto [] (fun _ _ => GNull).

Definition M0_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 getPlatformRegistrar_vm_init sto.

Definition M1_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes getPlatformRegistrar_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getPlatformRegistrar_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBool true]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getPlatformRegistrar_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 24 0 getPlatformRegistrar_vm_code (M0_getPlatformRegistrar_vm_miss sto) =
 run 23 1 getPlatformRegistrar_vm_code (M1_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M0_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPlatformRegistrar_vm_miss.

Lemma t1_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 23 1 getPlatformRegistrar_vm_code (M1_getPlatformRegistrar_vm_miss sto) =
 run 22 2 getPlatformRegistrar_vm_code (M2_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M1_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPlatformRegistrar_vm_miss.

Lemma t2_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 22 2 getPlatformRegistrar_vm_code (M2_getPlatformRegistrar_vm_miss sto) =
 run 21 3 getPlatformRegistrar_vm_code (M3_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M2_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPlatformRegistrar_vm_miss.

Lemma t3_getPlatformRegistrar_vm_miss : forall (sto : storage) (Hstore : sto (getPlatformRegistrar_prefix) = None),
 run 21 3 getPlatformRegistrar_vm_code (M3_getPlatformRegistrar_vm_miss sto) =
 run 20 4 getPlatformRegistrar_vm_code (M4_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto Hstore.
 rewrite run_S.
 cbn [M3_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getPlatformRegistrar_vm_miss.

Lemma t4_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 20 4 getPlatformRegistrar_vm_code (M4_getPlatformRegistrar_vm_miss sto) =
 run 19 5 getPlatformRegistrar_vm_code (M5_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M4_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPlatformRegistrar_vm_miss.

Lemma t5_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 19 5 getPlatformRegistrar_vm_code (M5_getPlatformRegistrar_vm_miss sto) =
 run 18 6 getPlatformRegistrar_vm_code (M6_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M5_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPlatformRegistrar_vm_miss.

Lemma t6_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 18 6 getPlatformRegistrar_vm_code (M6_getPlatformRegistrar_vm_miss sto) =
 run 17 7 getPlatformRegistrar_vm_code (M7_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M6_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPlatformRegistrar_vm_miss.

Lemma t7_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 17 7 getPlatformRegistrar_vm_code (M7_getPlatformRegistrar_vm_miss sto) =
 run 16 8 getPlatformRegistrar_vm_code (M8_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M7_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPlatformRegistrar_vm_miss.

Lemma t8_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 16 8 getPlatformRegistrar_vm_code (M8_getPlatformRegistrar_vm_miss sto) =
 run 15 9 getPlatformRegistrar_vm_code (M9_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M8_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPlatformRegistrar_vm_miss.

Lemma t9_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 15 9 getPlatformRegistrar_vm_code (M9_getPlatformRegistrar_vm_miss sto) =
 run 14 10 getPlatformRegistrar_vm_code (M10_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M9_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPlatformRegistrar_vm_miss.

Lemma t10_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 14 10 getPlatformRegistrar_vm_code (M10_getPlatformRegistrar_vm_miss sto) =
 run 13 20 getPlatformRegistrar_vm_code (M11_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M10_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPlatformRegistrar_vm_miss.

Lemma t11_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 13 20 getPlatformRegistrar_vm_code (M11_getPlatformRegistrar_vm_miss sto) =
 run 12 21 getPlatformRegistrar_vm_code (M12_getPlatformRegistrar_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M11_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPlatformRegistrar_vm_miss.

Lemma t12_getPlatformRegistrar_vm_miss : forall (sto : storage),
 run 12 21 getPlatformRegistrar_vm_code (M12_getPlatformRegistrar_vm_miss sto) = Done (GBytes hash160_default).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M12_getPlatformRegistrar_vm_miss getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPlatformRegistrar_vm_miss.
Definition M0_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 getPlatformRegistrar_vm_init sto.

Definition M1_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes getPlatformRegistrar_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getPlatformRegistrar_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GInt 20%Z; GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M19_getPlatformRegistrar_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 24 0 getPlatformRegistrar_vm_code (M0_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 23 1 getPlatformRegistrar_vm_code (M1_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M0_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPlatformRegistrar_vm_hitvalid.

Lemma t1_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 23 1 getPlatformRegistrar_vm_code (M1_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 22 2 getPlatformRegistrar_vm_code (M2_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M1_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPlatformRegistrar_vm_hitvalid.

Lemma t2_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 22 2 getPlatformRegistrar_vm_code (M2_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 21 3 getPlatformRegistrar_vm_code (M3_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M2_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPlatformRegistrar_vm_hitvalid.

Lemma t3_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes) (Hstore : sto (getPlatformRegistrar_prefix) = Some payload),
 run 21 3 getPlatformRegistrar_vm_code (M3_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 20 4 getPlatformRegistrar_vm_code (M4_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload Hstore.
 rewrite run_S.
 cbn [M3_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getPlatformRegistrar_vm_hitvalid.

Lemma t4_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 20 4 getPlatformRegistrar_vm_code (M4_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 19 5 getPlatformRegistrar_vm_code (M5_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M4_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPlatformRegistrar_vm_hitvalid.

Lemma t5_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 19 5 getPlatformRegistrar_vm_code (M5_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 18 6 getPlatformRegistrar_vm_code (M6_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M5_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPlatformRegistrar_vm_hitvalid.

Lemma t6_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 18 6 getPlatformRegistrar_vm_code (M6_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 17 7 getPlatformRegistrar_vm_code (M7_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M6_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPlatformRegistrar_vm_hitvalid.

Lemma t7_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 17 7 getPlatformRegistrar_vm_code (M7_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 16 8 getPlatformRegistrar_vm_code (M8_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M7_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPlatformRegistrar_vm_hitvalid.

Lemma t8_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 16 8 getPlatformRegistrar_vm_code (M8_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 15 11 getPlatformRegistrar_vm_code (M9_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M8_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPlatformRegistrar_vm_hitvalid.

Lemma t9_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 15 11 getPlatformRegistrar_vm_code (M9_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 14 12 getPlatformRegistrar_vm_code (M10_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M9_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPlatformRegistrar_vm_hitvalid.

Lemma t10_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 14 12 getPlatformRegistrar_vm_code (M10_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 13 13 getPlatformRegistrar_vm_code (M11_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M10_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPlatformRegistrar_vm_hitvalid.

Lemma t11_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 13 13 getPlatformRegistrar_vm_code (M11_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 12 14 getPlatformRegistrar_vm_code (M12_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M11_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPlatformRegistrar_vm_hitvalid.

Lemma t12_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 12 14 getPlatformRegistrar_vm_code (M12_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 11 15 getPlatformRegistrar_vm_code (M13_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M12_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPlatformRegistrar_vm_hitvalid.

Lemma t13_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 11 15 getPlatformRegistrar_vm_code (M13_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 10 16 getPlatformRegistrar_vm_code (M14_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M13_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPlatformRegistrar_vm_hitvalid.

Lemma t14_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 10 16 getPlatformRegistrar_vm_code (M14_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 9 17 getPlatformRegistrar_vm_code (M15_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M14_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPlatformRegistrar_vm_hitvalid.

Lemma t15_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 9 17 getPlatformRegistrar_vm_code (M15_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 8 18 getPlatformRegistrar_vm_code (M16_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M15_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPlatformRegistrar_vm_hitvalid.

Lemma t16_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes) (Hz : Z.eqb (Z.of_nat (length payload)) 20%Z = true),
 run 8 18 getPlatformRegistrar_vm_code (M16_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 7 20 getPlatformRegistrar_vm_code (M17_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload Hz.
 rewrite run_S.
 cbn [M16_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hz.
 reflexivity.
Qed.
Print Assumptions t16_getPlatformRegistrar_vm_hitvalid.

Lemma t17_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 7 20 getPlatformRegistrar_vm_code (M17_getPlatformRegistrar_vm_hitvalid sto payload) =
 run 6 21 getPlatformRegistrar_vm_code (M18_getPlatformRegistrar_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M17_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPlatformRegistrar_vm_hitvalid.

Lemma t18_getPlatformRegistrar_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 6 21 getPlatformRegistrar_vm_code (M18_getPlatformRegistrar_vm_hitvalid sto payload) = Done (GBytes payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M18_getPlatformRegistrar_vm_hitvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPlatformRegistrar_vm_hitvalid.
Definition M0_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 getPlatformRegistrar_vm_init sto.

Definition M1_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes getPlatformRegistrar_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getPlatformRegistrar_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GNull]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GInt 20%Z; GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getPlatformRegistrar_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPlatformRegistrar_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 24 0 getPlatformRegistrar_vm_code (M0_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 23 1 getPlatformRegistrar_vm_code (M1_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M0_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPlatformRegistrar_vm_hitinvalid.

Lemma t1_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 23 1 getPlatformRegistrar_vm_code (M1_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 22 2 getPlatformRegistrar_vm_code (M2_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M1_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPlatformRegistrar_vm_hitinvalid.

Lemma t2_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 22 2 getPlatformRegistrar_vm_code (M2_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 21 3 getPlatformRegistrar_vm_code (M3_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M2_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPlatformRegistrar_vm_hitinvalid.

Lemma t3_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes) (Hstore : sto (getPlatformRegistrar_prefix) = Some payload),
 run 21 3 getPlatformRegistrar_vm_code (M3_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 20 4 getPlatformRegistrar_vm_code (M4_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload Hstore.
 rewrite run_S.
 cbn [M3_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getPlatformRegistrar_vm_hitinvalid.

Lemma t4_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 20 4 getPlatformRegistrar_vm_code (M4_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 19 5 getPlatformRegistrar_vm_code (M5_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M4_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPlatformRegistrar_vm_hitinvalid.

Lemma t5_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 19 5 getPlatformRegistrar_vm_code (M5_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 18 6 getPlatformRegistrar_vm_code (M6_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M5_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPlatformRegistrar_vm_hitinvalid.

Lemma t6_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 18 6 getPlatformRegistrar_vm_code (M6_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 17 7 getPlatformRegistrar_vm_code (M7_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M6_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPlatformRegistrar_vm_hitinvalid.

Lemma t7_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 17 7 getPlatformRegistrar_vm_code (M7_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 16 8 getPlatformRegistrar_vm_code (M8_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M7_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPlatformRegistrar_vm_hitinvalid.

Lemma t8_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 16 8 getPlatformRegistrar_vm_code (M8_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 15 11 getPlatformRegistrar_vm_code (M9_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M8_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPlatformRegistrar_vm_hitinvalid.

Lemma t9_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 15 11 getPlatformRegistrar_vm_code (M9_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 14 12 getPlatformRegistrar_vm_code (M10_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M9_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPlatformRegistrar_vm_hitinvalid.

Lemma t10_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 14 12 getPlatformRegistrar_vm_code (M10_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 13 13 getPlatformRegistrar_vm_code (M11_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M10_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPlatformRegistrar_vm_hitinvalid.

Lemma t11_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 13 13 getPlatformRegistrar_vm_code (M11_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 12 14 getPlatformRegistrar_vm_code (M12_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M11_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPlatformRegistrar_vm_hitinvalid.

Lemma t12_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 12 14 getPlatformRegistrar_vm_code (M12_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 11 15 getPlatformRegistrar_vm_code (M13_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M12_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPlatformRegistrar_vm_hitinvalid.

Lemma t13_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 11 15 getPlatformRegistrar_vm_code (M13_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 10 16 getPlatformRegistrar_vm_code (M14_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M13_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPlatformRegistrar_vm_hitinvalid.

Lemma t14_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 10 16 getPlatformRegistrar_vm_code (M14_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 9 17 getPlatformRegistrar_vm_code (M15_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M14_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPlatformRegistrar_vm_hitinvalid.

Lemma t15_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 9 17 getPlatformRegistrar_vm_code (M15_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 8 18 getPlatformRegistrar_vm_code (M16_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M15_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPlatformRegistrar_vm_hitinvalid.

Lemma t16_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes) (Hz : Z.eqb (Z.of_nat (length payload)) 20%Z = false),
 run 8 18 getPlatformRegistrar_vm_code (M16_getPlatformRegistrar_vm_hitinvalid sto payload) =
 run 7 19 getPlatformRegistrar_vm_code (M17_getPlatformRegistrar_vm_hitinvalid sto payload).
Proof.
 intros sto payload Hz.
 rewrite run_S.
 cbn [M16_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hz.
 reflexivity.
Qed.
Print Assumptions t16_getPlatformRegistrar_vm_hitinvalid.

Lemma t17_getPlatformRegistrar_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 7 19 getPlatformRegistrar_vm_code (M17_getPlatformRegistrar_vm_hitinvalid sto payload) = Thrown.
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M17_getPlatformRegistrar_vm_hitinvalid getPlatformRegistrar_vm_init getPlatformRegistrar_vm_code getPlatformRegistrar_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPlatformRegistrar_vm_hitinvalid.

Theorem getPlatformRegistrar_vm_miss : forall sto,
 sto (getPlatformRegistrar_prefix) = None ->
 run 24 0 getPlatformRegistrar_vm_code (getPlatformRegistrar_vm_init sto) = Done (GBytes hash160_default) /\
 getter_outcome getPlatformRegistrar_prefix (GBytes hash160_default) decode_hash160 sto [] = OK (GBytes hash160_default).
Proof.
 intros sto Hstore. split.
 - exact (eq_trans (t0_getPlatformRegistrar_vm_miss sto) (eq_trans (t1_getPlatformRegistrar_vm_miss sto) (eq_trans (t2_getPlatformRegistrar_vm_miss sto) (eq_trans (t3_getPlatformRegistrar_vm_miss sto Hstore) (eq_trans (t4_getPlatformRegistrar_vm_miss sto) (eq_trans (t5_getPlatformRegistrar_vm_miss sto) (eq_trans (t6_getPlatformRegistrar_vm_miss sto) (eq_trans (t7_getPlatformRegistrar_vm_miss sto) (eq_trans (t8_getPlatformRegistrar_vm_miss sto) (eq_trans (t9_getPlatformRegistrar_vm_miss sto) (eq_trans (t10_getPlatformRegistrar_vm_miss sto) (eq_trans (t11_getPlatformRegistrar_vm_miss sto) (t12_getPlatformRegistrar_vm_miss sto))))))))))))).
 - unfold getter_outcome. rewrite app_nil_r, Hstore. reflexivity.
Qed.
Print Assumptions getPlatformRegistrar_vm_miss.
Theorem getPlatformRegistrar_vm_hit_valid : forall sto payload,
 sto (getPlatformRegistrar_prefix) = Some payload ->
 valid_bytes payload = true ->
 (length payload = 20)%nat ->
 run 24 0 getPlatformRegistrar_vm_code (getPlatformRegistrar_vm_init sto) = Done (GBytes payload) /\
 getter_outcome getPlatformRegistrar_prefix (GBytes hash160_default) decode_hash160 sto [] = OK (GBytes payload).
Proof.
 intros sto payload Hstore Hvalid Hlen.
 assert (Hz : Z.eqb (Z.of_nat (length payload)) 20 = true).
 { apply Z.eqb_eq. rewrite Hlen. reflexivity. }
 split.
 - exact (eq_trans (t0_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t1_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t2_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t3_getPlatformRegistrar_vm_hitvalid sto payload Hstore) (eq_trans (t4_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t5_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t6_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t7_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t8_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t9_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t10_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t11_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t12_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t13_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t14_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t15_getPlatformRegistrar_vm_hitvalid sto payload) (eq_trans (t16_getPlatformRegistrar_vm_hitvalid sto payload Hz) (eq_trans (t17_getPlatformRegistrar_vm_hitvalid sto payload) (t18_getPlatformRegistrar_vm_hitvalid sto payload))))))))))))))))))).
 - unfold getter_outcome, decode_hash160.
   rewrite app_nil_r, Hstore, Hvalid, Hlen. reflexivity.
Qed.
Print Assumptions getPlatformRegistrar_vm_hit_valid.
Theorem getPlatformRegistrar_vm_hit_invalid_size : forall sto payload,
 sto (getPlatformRegistrar_prefix) = Some payload ->
 (length payload <> 20)%nat ->
 run 24 0 getPlatformRegistrar_vm_code (getPlatformRegistrar_vm_init sto) = Thrown /\
 getter_outcome getPlatformRegistrar_prefix (GBytes hash160_default) decode_hash160 sto [] = Fault.
Proof.
 intros sto payload Hstore Hlen.
 assert (Hz : Z.eqb (Z.of_nat (length payload)) 20 = false).
 { apply Z.eqb_neq. intro He. apply Hlen.
   apply (Nat2Z.inj (length payload) 20 He). }
 split.
 - exact (eq_trans (t0_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t1_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t2_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t3_getPlatformRegistrar_vm_hitinvalid sto payload Hstore) (eq_trans (t4_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t5_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t6_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t7_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t8_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t9_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t10_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t11_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t12_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t13_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t14_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t15_getPlatformRegistrar_vm_hitinvalid sto payload) (eq_trans (t16_getPlatformRegistrar_vm_hitinvalid sto payload Hz) (t17_getPlatformRegistrar_vm_hitinvalid sto payload)))))))))))))))))).
 - unfold getter_outcome, decode_hash160. rewrite app_nil_r, Hstore.
   apply Nat.eqb_neq in Hlen. rewrite Hlen, andb_false_r. reflexivity.
Qed.
Print Assumptions getPlatformRegistrar_vm_hit_invalid_size.
