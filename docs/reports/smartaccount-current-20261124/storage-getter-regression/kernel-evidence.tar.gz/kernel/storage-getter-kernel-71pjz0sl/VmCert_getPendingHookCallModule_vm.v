From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getPendingHookCallModule_vm_program : list Ins :=
 [InitSlot 1 1; LdArg; LdStatic 22; Call 16; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 11; Push (GBytes [0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat]); Jump 14; LdLoc 0; Push (GInt 0); PickItem; Jump 15; Ret; InitSlot 2 2; LdArgN 1; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 32; Push GNull; Jump 35; LdLoc 1; CallToken 4; Jump 35; Ret].
Definition getPendingHookCallModule_vm_code (pc : nat) : Ins := nth pc getPendingHookCallModule_vm_program Unsupported.
Definition getPendingHookCallModule_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 22 then Some (GBytes getPendingHookCallModule_prefix) else None.
Definition getPendingHookCallModule_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account; GBytes getPendingHookCallModule_prefix] getPendingHookCallModule_vm_statics sto [] tok.

Definition M0_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 getPendingHookCallModule_vm_init tok sto account.

Definition M1_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M5_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M6_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M7_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookCallModule_prefix; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M8_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookCallModule_prefix; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M9_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M10_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M11_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M12_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingHookCallModule_prefix ++ account); GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M13_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M14_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M15_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M16_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M17_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M18_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M19_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M20_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M21_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M26_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M27_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hash160_default; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M28_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hash160_default; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M29_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hash160_default; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M30_getPendingHookCallModule_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hash160_default; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 38 0 getPendingHookCallModule_vm_code (M0_getPendingHookCallModule_vm_miss tok sto account) =
 run 37 1 getPendingHookCallModule_vm_code (M1_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingHookCallModule_vm_miss.

Lemma t1_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 37 1 getPendingHookCallModule_vm_code (M1_getPendingHookCallModule_vm_miss tok sto account) =
 run 36 2 getPendingHookCallModule_vm_code (M2_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingHookCallModule_vm_miss.

Lemma t2_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 36 2 getPendingHookCallModule_vm_code (M2_getPendingHookCallModule_vm_miss tok sto account) =
 run 35 3 getPendingHookCallModule_vm_code (M3_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingHookCallModule_vm_miss.

Lemma t3_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 35 3 getPendingHookCallModule_vm_code (M3_getPendingHookCallModule_vm_miss tok sto account) =
 run 34 16 getPendingHookCallModule_vm_code (M4_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingHookCallModule_vm_miss.

Lemma t4_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 34 16 getPendingHookCallModule_vm_code (M4_getPendingHookCallModule_vm_miss tok sto account) =
 run 33 17 getPendingHookCallModule_vm_code (M5_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingHookCallModule_vm_miss.

Lemma t5_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 33 17 getPendingHookCallModule_vm_code (M5_getPendingHookCallModule_vm_miss tok sto account) =
 run 32 18 getPendingHookCallModule_vm_code (M6_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingHookCallModule_vm_miss.

Lemma t6_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 32 18 getPendingHookCallModule_vm_code (M6_getPendingHookCallModule_vm_miss tok sto account) =
 run 31 19 getPendingHookCallModule_vm_code (M7_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingHookCallModule_vm_miss.

Lemma t7_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 31 19 getPendingHookCallModule_vm_code (M7_getPendingHookCallModule_vm_miss tok sto account) =
 run 30 20 getPendingHookCallModule_vm_code (M8_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingHookCallModule_vm_miss.

Lemma t8_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 30 20 getPendingHookCallModule_vm_code (M8_getPendingHookCallModule_vm_miss tok sto account) =
 run 29 21 getPendingHookCallModule_vm_code (M9_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M8_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingHookCallModule_vm_miss.

Lemma t9_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 29 21 getPendingHookCallModule_vm_code (M9_getPendingHookCallModule_vm_miss tok sto account) =
 run 28 22 getPendingHookCallModule_vm_code (M10_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingHookCallModule_vm_miss.

Lemma t10_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 28 22 getPendingHookCallModule_vm_code (M10_getPendingHookCallModule_vm_miss tok sto account) =
 run 27 23 getPendingHookCallModule_vm_code (M11_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingHookCallModule_vm_miss.

Lemma t11_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 23 getPendingHookCallModule_vm_code (M11_getPendingHookCallModule_vm_miss tok sto account) =
 run 26 24 getPendingHookCallModule_vm_code (M12_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M11_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingHookCallModule_vm_miss.

Lemma t12_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (Hstore : sto (getPendingHookCallModule_prefix ++ account) = None),
 run 26 24 getPendingHookCallModule_vm_code (M12_getPendingHookCallModule_vm_miss tok sto account) =
 run 25 25 getPendingHookCallModule_vm_code (M13_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account Hstore.
 rewrite run_S.
 cbn [M12_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t12_getPendingHookCallModule_vm_miss.

Lemma t13_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 25 getPendingHookCallModule_vm_code (M13_getPendingHookCallModule_vm_miss tok sto account) =
 run 24 26 getPendingHookCallModule_vm_code (M14_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingHookCallModule_vm_miss.

Lemma t14_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 26 getPendingHookCallModule_vm_code (M14_getPendingHookCallModule_vm_miss tok sto account) =
 run 23 27 getPendingHookCallModule_vm_code (M15_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingHookCallModule_vm_miss.

Lemma t15_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 27 getPendingHookCallModule_vm_code (M15_getPendingHookCallModule_vm_miss tok sto account) =
 run 22 28 getPendingHookCallModule_vm_code (M16_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingHookCallModule_vm_miss.

Lemma t16_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 28 getPendingHookCallModule_vm_code (M16_getPendingHookCallModule_vm_miss tok sto account) =
 run 21 29 getPendingHookCallModule_vm_code (M17_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingHookCallModule_vm_miss.

Lemma t17_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 29 getPendingHookCallModule_vm_code (M17_getPendingHookCallModule_vm_miss tok sto account) =
 run 20 30 getPendingHookCallModule_vm_code (M18_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M17_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingHookCallModule_vm_miss.

Lemma t18_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 20 30 getPendingHookCallModule_vm_code (M18_getPendingHookCallModule_vm_miss tok sto account) =
 run 19 31 getPendingHookCallModule_vm_code (M19_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M18_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingHookCallModule_vm_miss.

Lemma t19_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 31 getPendingHookCallModule_vm_code (M19_getPendingHookCallModule_vm_miss tok sto account) =
 run 18 35 getPendingHookCallModule_vm_code (M20_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M19_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getPendingHookCallModule_vm_miss.

Lemma t20_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 18 35 getPendingHookCallModule_vm_code (M20_getPendingHookCallModule_vm_miss tok sto account) =
 run 17 4 getPendingHookCallModule_vm_code (M21_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M20_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getPendingHookCallModule_vm_miss.

Lemma t21_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 4 getPendingHookCallModule_vm_code (M21_getPendingHookCallModule_vm_miss tok sto account) =
 run 16 5 getPendingHookCallModule_vm_code (M22_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M21_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getPendingHookCallModule_vm_miss.

Lemma t22_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 5 getPendingHookCallModule_vm_code (M22_getPendingHookCallModule_vm_miss tok sto account) =
 run 15 6 getPendingHookCallModule_vm_code (M23_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M22_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getPendingHookCallModule_vm_miss.

Lemma t23_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 6 getPendingHookCallModule_vm_code (M23_getPendingHookCallModule_vm_miss tok sto account) =
 run 14 7 getPendingHookCallModule_vm_code (M24_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M23_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getPendingHookCallModule_vm_miss.

Lemma t24_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 7 getPendingHookCallModule_vm_code (M24_getPendingHookCallModule_vm_miss tok sto account) =
 run 13 8 getPendingHookCallModule_vm_code (M25_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M24_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getPendingHookCallModule_vm_miss.

Lemma t25_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 8 getPendingHookCallModule_vm_code (M25_getPendingHookCallModule_vm_miss tok sto account) =
 run 12 9 getPendingHookCallModule_vm_code (M26_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M25_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t25_getPendingHookCallModule_vm_miss.

Lemma t26_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 9 getPendingHookCallModule_vm_code (M26_getPendingHookCallModule_vm_miss tok sto account) =
 run 11 10 getPendingHookCallModule_vm_code (M27_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M26_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t26_getPendingHookCallModule_vm_miss.

Lemma t27_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 11 10 getPendingHookCallModule_vm_code (M27_getPendingHookCallModule_vm_miss tok sto account) =
 run 10 14 getPendingHookCallModule_vm_code (M28_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M27_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t27_getPendingHookCallModule_vm_miss.

Lemma t28_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 10 14 getPendingHookCallModule_vm_code (M28_getPendingHookCallModule_vm_miss tok sto account) =
 run 9 15 getPendingHookCallModule_vm_code (M29_getPendingHookCallModule_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M28_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t28_getPendingHookCallModule_vm_miss.

Lemma t29_getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 9 15 getPendingHookCallModule_vm_code (M29_getPendingHookCallModule_vm_miss tok sto account) = Done (GBytes hash160_default).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M29_getPendingHookCallModule_vm_miss getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t29_getPendingHookCallModule_vm_miss.
Definition M0_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 getPendingHookCallModule_vm_init tok sto account.

Definition M1_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M5_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M6_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M7_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookCallModule_prefix; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M8_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookCallModule_prefix; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M9_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M10_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M11_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M12_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingHookCallModule_prefix ++ account); GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M13_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M14_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M15_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M16_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M17_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBool false; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M18_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M19_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M20_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M21_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M22_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GBytes (getPendingHookCallModule_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GNull; GArray xs; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M26_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBool false; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M27_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M28_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M29_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GInt 0%Z; GArray xs; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M30_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M31_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M32_getPendingHookCallModule_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes getPendingHookCallModule_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingHookCallModule_prefix];
    mstatics := getPendingHookCallModule_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 38 0 getPendingHookCallModule_vm_code (M0_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 37 1 getPendingHookCallModule_vm_code (M1_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M0_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingHookCallModule_vm_hit.

Lemma t1_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 37 1 getPendingHookCallModule_vm_code (M1_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 36 2 getPendingHookCallModule_vm_code (M2_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M1_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingHookCallModule_vm_hit.

Lemma t2_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 36 2 getPendingHookCallModule_vm_code (M2_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 35 3 getPendingHookCallModule_vm_code (M3_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M2_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingHookCallModule_vm_hit.

Lemma t3_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 35 3 getPendingHookCallModule_vm_code (M3_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 34 16 getPendingHookCallModule_vm_code (M4_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M3_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingHookCallModule_vm_hit.

Lemma t4_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 34 16 getPendingHookCallModule_vm_code (M4_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 33 17 getPendingHookCallModule_vm_code (M5_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M4_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingHookCallModule_vm_hit.

Lemma t5_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 33 17 getPendingHookCallModule_vm_code (M5_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 32 18 getPendingHookCallModule_vm_code (M6_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M5_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingHookCallModule_vm_hit.

Lemma t6_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 32 18 getPendingHookCallModule_vm_code (M6_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 31 19 getPendingHookCallModule_vm_code (M7_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M6_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingHookCallModule_vm_hit.

Lemma t7_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 31 19 getPendingHookCallModule_vm_code (M7_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 30 20 getPendingHookCallModule_vm_code (M8_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M7_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingHookCallModule_vm_hit.

Lemma t8_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 30 20 getPendingHookCallModule_vm_code (M8_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 29 21 getPendingHookCallModule_vm_code (M9_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M8_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingHookCallModule_vm_hit.

Lemma t9_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 29 21 getPendingHookCallModule_vm_code (M9_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 28 22 getPendingHookCallModule_vm_code (M10_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M9_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingHookCallModule_vm_hit.

Lemma t10_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 28 22 getPendingHookCallModule_vm_code (M10_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 27 23 getPendingHookCallModule_vm_code (M11_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M10_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingHookCallModule_vm_hit.

Lemma t11_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 27 23 getPendingHookCallModule_vm_code (M11_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 26 24 getPendingHookCallModule_vm_code (M12_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M11_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingHookCallModule_vm_hit.

Lemma t12_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Hstore : sto (getPendingHookCallModule_prefix ++ account) = Some payload),
 run 26 24 getPendingHookCallModule_vm_code (M12_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 25 25 getPendingHookCallModule_vm_code (M13_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Hstore.
 rewrite run_S.
 cbn [M12_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t12_getPendingHookCallModule_vm_hit.

Lemma t13_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 25 25 getPendingHookCallModule_vm_code (M13_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 24 26 getPendingHookCallModule_vm_code (M14_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M13_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingHookCallModule_vm_hit.

Lemma t14_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 24 26 getPendingHookCallModule_vm_code (M14_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 23 27 getPendingHookCallModule_vm_code (M15_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M14_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingHookCallModule_vm_hit.

Lemma t15_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 23 27 getPendingHookCallModule_vm_code (M15_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 22 28 getPendingHookCallModule_vm_code (M16_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M15_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingHookCallModule_vm_hit.

Lemma t16_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 22 28 getPendingHookCallModule_vm_code (M16_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 21 29 getPendingHookCallModule_vm_code (M17_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M16_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingHookCallModule_vm_hit.

Lemma t17_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 21 29 getPendingHookCallModule_vm_code (M17_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 20 32 getPendingHookCallModule_vm_code (M18_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M17_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingHookCallModule_vm_hit.

Lemma t18_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 20 32 getPendingHookCallModule_vm_code (M18_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 19 33 getPendingHookCallModule_vm_code (M19_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M18_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingHookCallModule_vm_hit.

Lemma t19_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 19 33 getPendingHookCallModule_vm_code (M19_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 18 34 getPendingHookCallModule_vm_code (M20_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Htok.
 rewrite run_S.
 cbn [M19_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t19_getPendingHookCallModule_vm_hit.

Lemma t20_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 18 34 getPendingHookCallModule_vm_code (M20_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 17 35 getPendingHookCallModule_vm_code (M21_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M20_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getPendingHookCallModule_vm_hit.

Lemma t21_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 17 35 getPendingHookCallModule_vm_code (M21_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 16 4 getPendingHookCallModule_vm_code (M22_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M21_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getPendingHookCallModule_vm_hit.

Lemma t22_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 16 4 getPendingHookCallModule_vm_code (M22_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 15 5 getPendingHookCallModule_vm_code (M23_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M22_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getPendingHookCallModule_vm_hit.

Lemma t23_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 15 5 getPendingHookCallModule_vm_code (M23_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 14 6 getPendingHookCallModule_vm_code (M24_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M23_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getPendingHookCallModule_vm_hit.

Lemma t24_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 14 6 getPendingHookCallModule_vm_code (M24_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 13 7 getPendingHookCallModule_vm_code (M25_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M24_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getPendingHookCallModule_vm_hit.

Lemma t25_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 13 7 getPendingHookCallModule_vm_code (M25_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 12 8 getPendingHookCallModule_vm_code (M26_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M25_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t25_getPendingHookCallModule_vm_hit.

Lemma t26_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 12 8 getPendingHookCallModule_vm_code (M26_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 11 11 getPendingHookCallModule_vm_code (M27_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M26_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t26_getPendingHookCallModule_vm_hit.

Lemma t27_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 11 11 getPendingHookCallModule_vm_code (M27_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 10 12 getPendingHookCallModule_vm_code (M28_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M27_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t27_getPendingHookCallModule_vm_hit.

Lemma t28_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 10 12 getPendingHookCallModule_vm_code (M28_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 9 13 getPendingHookCallModule_vm_code (M29_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M28_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t28_getPendingHookCallModule_vm_hit.

Lemma t29_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Hnth : nth_error xs (Z.to_nat 0%Z) = Some v),
 run 9 13 getPendingHookCallModule_vm_code (M29_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 8 14 getPendingHookCallModule_vm_code (M30_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Hnth.
 rewrite run_S.
 cbn [M29_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t29_getPendingHookCallModule_vm_hit.

Lemma t30_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 8 14 getPendingHookCallModule_vm_code (M30_getPendingHookCallModule_vm_hit tok sto account payload xs v) =
 run 7 15 getPendingHookCallModule_vm_code (M31_getPendingHookCallModule_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M30_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t30_getPendingHookCallModule_vm_hit.

Lemma t31_getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 7 15 getPendingHookCallModule_vm_code (M31_getPendingHookCallModule_vm_hit tok sto account payload xs v) = Done v.
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M31_getPendingHookCallModule_vm_hit getPendingHookCallModule_vm_init getPendingHookCallModule_vm_code getPendingHookCallModule_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t31_getPendingHookCallModule_vm_hit.

Theorem getPendingHookCallModule_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (getPendingHookCallModule_prefix ++ account) = None ->
 run 38 0 getPendingHookCallModule_vm_code (getPendingHookCallModule_vm_init tok sto account) = Done (GBytes hash160_default) /\
 getPendingHookCallModule_binding tok sto account = OK (GBytes hash160_default).
Proof.
 intros tok sto account Hstore. split.
 - exact (eq_trans (t0_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t1_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t2_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t3_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t4_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t5_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t6_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t7_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t8_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t9_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t10_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t11_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t12_getPendingHookCallModule_vm_miss tok sto account Hstore) (eq_trans (t13_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t14_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t15_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t16_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t17_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t18_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t19_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t20_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t21_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t22_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t23_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t24_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t25_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t26_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t27_getPendingHookCallModule_vm_miss tok sto account) (eq_trans (t28_getPendingHookCallModule_vm_miss tok sto account) (t29_getPendingHookCallModule_vm_miss tok sto account)))))))))))))))))))))))))))))).
 - apply getPendingHookCallModule_source_miss. exact Hstore.
Qed.
Print Assumptions getPendingHookCallModule_vm_miss.
Theorem getPendingHookCallModule_vm_hit : forall (tok : nat -> GVal -> GVal) sto account (payload : bytes) (xs : list GVal) (v : GVal),
 sto (getPendingHookCallModule_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs (Z.to_nat 0%Z) = Some v ->
 run 38 0 getPendingHookCallModule_vm_code (getPendingHookCallModule_vm_init tok sto account) = Done v /\
 getPendingHookCallModule_binding tok sto account = OK v.
Proof.
 intros tok sto account payload xs v Hstore Htok Hnth. split.
 - exact (eq_trans (t0_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t1_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t2_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t3_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t4_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t5_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t6_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t7_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t8_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t9_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t10_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t11_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t12_getPendingHookCallModule_vm_hit tok sto account payload xs v Hstore) (eq_trans (t13_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t14_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t15_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t16_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t17_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t18_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t19_getPendingHookCallModule_vm_hit tok sto account payload xs v Htok) (eq_trans (t20_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t21_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t22_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t23_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t24_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t25_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t26_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t27_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t28_getPendingHookCallModule_vm_hit tok sto account payload xs v) (eq_trans (t29_getPendingHookCallModule_vm_hit tok sto account payload xs v Hnth) (eq_trans (t30_getPendingHookCallModule_vm_hit tok sto account payload xs v) (t31_getPendingHookCallModule_vm_hit tok sto account payload xs v)))))))))))))))))))))))))))))))).
 - apply getPendingHookCallModule_source_hit with (payload := payload) (xs := xs) (v := v); assumption.
Qed.
Print Assumptions getPendingHookCallModule_vm_hit.
