From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getPendingContractAdmin_vm_program : list Ins :=
 [InitSlot 1 0; LdStatic 28; GetContext; StorageGet; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 11; Push (GBytes [0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat]); Jump 20; LdLoc 0; Dup; IsNull; JumpIf 20; Dup; SizeIns; Push (GInt 20%Z); JumpEq 20; Throw; Jump 21; Ret].
Definition getPendingContractAdmin_vm_code (pc : nat) : Ins := nth pc getPendingContractAdmin_vm_program Unsupported.
Definition getPendingContractAdmin_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 28 then Some (GBytes getPendingContractAdmin_prefix) else None.
Definition getPendingContractAdmin_vm_init (sto : storage) : Machine :=
 machine [] (repeat GNull 1) [] getPendingContractAdmin_vm_statics sto [] (fun _ _ => GNull).

Definition M0_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 getPendingContractAdmin_vm_init sto.

Definition M1_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes getPendingContractAdmin_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getPendingContractAdmin_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBool true]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getPendingContractAdmin_vm_miss (sto : storage) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 24 0 getPendingContractAdmin_vm_code (M0_getPendingContractAdmin_vm_miss sto) =
 run 23 1 getPendingContractAdmin_vm_code (M1_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M0_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingContractAdmin_vm_miss.

Lemma t1_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 23 1 getPendingContractAdmin_vm_code (M1_getPendingContractAdmin_vm_miss sto) =
 run 22 2 getPendingContractAdmin_vm_code (M2_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M1_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingContractAdmin_vm_miss.

Lemma t2_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 22 2 getPendingContractAdmin_vm_code (M2_getPendingContractAdmin_vm_miss sto) =
 run 21 3 getPendingContractAdmin_vm_code (M3_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M2_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingContractAdmin_vm_miss.

Lemma t3_getPendingContractAdmin_vm_miss : forall (sto : storage) (Hstore : sto (getPendingContractAdmin_prefix) = None),
 run 21 3 getPendingContractAdmin_vm_code (M3_getPendingContractAdmin_vm_miss sto) =
 run 20 4 getPendingContractAdmin_vm_code (M4_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto Hstore.
 rewrite run_S.
 cbn [M3_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getPendingContractAdmin_vm_miss.

Lemma t4_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 20 4 getPendingContractAdmin_vm_code (M4_getPendingContractAdmin_vm_miss sto) =
 run 19 5 getPendingContractAdmin_vm_code (M5_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M4_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingContractAdmin_vm_miss.

Lemma t5_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 19 5 getPendingContractAdmin_vm_code (M5_getPendingContractAdmin_vm_miss sto) =
 run 18 6 getPendingContractAdmin_vm_code (M6_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M5_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingContractAdmin_vm_miss.

Lemma t6_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 18 6 getPendingContractAdmin_vm_code (M6_getPendingContractAdmin_vm_miss sto) =
 run 17 7 getPendingContractAdmin_vm_code (M7_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M6_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingContractAdmin_vm_miss.

Lemma t7_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 17 7 getPendingContractAdmin_vm_code (M7_getPendingContractAdmin_vm_miss sto) =
 run 16 8 getPendingContractAdmin_vm_code (M8_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M7_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingContractAdmin_vm_miss.

Lemma t8_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 16 8 getPendingContractAdmin_vm_code (M8_getPendingContractAdmin_vm_miss sto) =
 run 15 9 getPendingContractAdmin_vm_code (M9_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M8_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingContractAdmin_vm_miss.

Lemma t9_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 15 9 getPendingContractAdmin_vm_code (M9_getPendingContractAdmin_vm_miss sto) =
 run 14 10 getPendingContractAdmin_vm_code (M10_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M9_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingContractAdmin_vm_miss.

Lemma t10_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 14 10 getPendingContractAdmin_vm_code (M10_getPendingContractAdmin_vm_miss sto) =
 run 13 20 getPendingContractAdmin_vm_code (M11_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M10_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingContractAdmin_vm_miss.

Lemma t11_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 13 20 getPendingContractAdmin_vm_code (M11_getPendingContractAdmin_vm_miss sto) =
 run 12 21 getPendingContractAdmin_vm_code (M12_getPendingContractAdmin_vm_miss sto).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M11_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingContractAdmin_vm_miss.

Lemma t12_getPendingContractAdmin_vm_miss : forall (sto : storage),
 run 12 21 getPendingContractAdmin_vm_code (M12_getPendingContractAdmin_vm_miss sto) = Done (GBytes hash160_default).
Proof.
 intros sto.
 rewrite run_S.
 cbn [M12_getPendingContractAdmin_vm_miss getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPendingContractAdmin_vm_miss.
Definition M0_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 getPendingContractAdmin_vm_init sto.

Definition M1_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes getPendingContractAdmin_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getPendingContractAdmin_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GInt 20%Z; GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M19_getPendingContractAdmin_vm_hitvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 24 0 getPendingContractAdmin_vm_code (M0_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 23 1 getPendingContractAdmin_vm_code (M1_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M0_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingContractAdmin_vm_hitvalid.

Lemma t1_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 23 1 getPendingContractAdmin_vm_code (M1_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 22 2 getPendingContractAdmin_vm_code (M2_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M1_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingContractAdmin_vm_hitvalid.

Lemma t2_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 22 2 getPendingContractAdmin_vm_code (M2_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 21 3 getPendingContractAdmin_vm_code (M3_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M2_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingContractAdmin_vm_hitvalid.

Lemma t3_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes) (Hstore : sto (getPendingContractAdmin_prefix) = Some payload),
 run 21 3 getPendingContractAdmin_vm_code (M3_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 20 4 getPendingContractAdmin_vm_code (M4_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload Hstore.
 rewrite run_S.
 cbn [M3_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getPendingContractAdmin_vm_hitvalid.

Lemma t4_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 20 4 getPendingContractAdmin_vm_code (M4_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 19 5 getPendingContractAdmin_vm_code (M5_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M4_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingContractAdmin_vm_hitvalid.

Lemma t5_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 19 5 getPendingContractAdmin_vm_code (M5_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 18 6 getPendingContractAdmin_vm_code (M6_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M5_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingContractAdmin_vm_hitvalid.

Lemma t6_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 18 6 getPendingContractAdmin_vm_code (M6_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 17 7 getPendingContractAdmin_vm_code (M7_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M6_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingContractAdmin_vm_hitvalid.

Lemma t7_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 17 7 getPendingContractAdmin_vm_code (M7_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 16 8 getPendingContractAdmin_vm_code (M8_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M7_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingContractAdmin_vm_hitvalid.

Lemma t8_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 16 8 getPendingContractAdmin_vm_code (M8_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 15 11 getPendingContractAdmin_vm_code (M9_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M8_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingContractAdmin_vm_hitvalid.

Lemma t9_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 15 11 getPendingContractAdmin_vm_code (M9_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 14 12 getPendingContractAdmin_vm_code (M10_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M9_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingContractAdmin_vm_hitvalid.

Lemma t10_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 14 12 getPendingContractAdmin_vm_code (M10_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 13 13 getPendingContractAdmin_vm_code (M11_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M10_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingContractAdmin_vm_hitvalid.

Lemma t11_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 13 13 getPendingContractAdmin_vm_code (M11_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 12 14 getPendingContractAdmin_vm_code (M12_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M11_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingContractAdmin_vm_hitvalid.

Lemma t12_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 12 14 getPendingContractAdmin_vm_code (M12_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 11 15 getPendingContractAdmin_vm_code (M13_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M12_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPendingContractAdmin_vm_hitvalid.

Lemma t13_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 11 15 getPendingContractAdmin_vm_code (M13_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 10 16 getPendingContractAdmin_vm_code (M14_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M13_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingContractAdmin_vm_hitvalid.

Lemma t14_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 10 16 getPendingContractAdmin_vm_code (M14_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 9 17 getPendingContractAdmin_vm_code (M15_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M14_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingContractAdmin_vm_hitvalid.

Lemma t15_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 9 17 getPendingContractAdmin_vm_code (M15_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 8 18 getPendingContractAdmin_vm_code (M16_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M15_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingContractAdmin_vm_hitvalid.

Lemma t16_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes) (Hz : Z.eqb (Z.of_nat (length payload)) 20%Z = true),
 run 8 18 getPendingContractAdmin_vm_code (M16_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 7 20 getPendingContractAdmin_vm_code (M17_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload Hz.
 rewrite run_S.
 cbn [M16_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hz.
 reflexivity.
Qed.
Print Assumptions t16_getPendingContractAdmin_vm_hitvalid.

Lemma t17_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 7 20 getPendingContractAdmin_vm_code (M17_getPendingContractAdmin_vm_hitvalid sto payload) =
 run 6 21 getPendingContractAdmin_vm_code (M18_getPendingContractAdmin_vm_hitvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M17_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingContractAdmin_vm_hitvalid.

Lemma t18_getPendingContractAdmin_vm_hitvalid : forall (sto : storage) (payload : bytes),
 run 6 21 getPendingContractAdmin_vm_code (M18_getPendingContractAdmin_vm_hitvalid sto payload) = Done (GBytes payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M18_getPendingContractAdmin_vm_hitvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingContractAdmin_vm_hitvalid.
Definition M0_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 getPendingContractAdmin_vm_init sto.

Definition M1_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes getPendingContractAdmin_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes getPendingContractAdmin_prefix]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GNull]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GInt 20%Z; GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getPendingContractAdmin_vm_hitinvalid (sto : storage) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes payload]; margs := [];
    mstatics := getPendingContractAdmin_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 24 0 getPendingContractAdmin_vm_code (M0_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 23 1 getPendingContractAdmin_vm_code (M1_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M0_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingContractAdmin_vm_hitinvalid.

Lemma t1_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 23 1 getPendingContractAdmin_vm_code (M1_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 22 2 getPendingContractAdmin_vm_code (M2_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M1_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingContractAdmin_vm_hitinvalid.

Lemma t2_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 22 2 getPendingContractAdmin_vm_code (M2_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 21 3 getPendingContractAdmin_vm_code (M3_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M2_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingContractAdmin_vm_hitinvalid.

Lemma t3_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes) (Hstore : sto (getPendingContractAdmin_prefix) = Some payload),
 run 21 3 getPendingContractAdmin_vm_code (M3_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 20 4 getPendingContractAdmin_vm_code (M4_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload Hstore.
 rewrite run_S.
 cbn [M3_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t3_getPendingContractAdmin_vm_hitinvalid.

Lemma t4_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 20 4 getPendingContractAdmin_vm_code (M4_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 19 5 getPendingContractAdmin_vm_code (M5_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M4_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingContractAdmin_vm_hitinvalid.

Lemma t5_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 19 5 getPendingContractAdmin_vm_code (M5_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 18 6 getPendingContractAdmin_vm_code (M6_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M5_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingContractAdmin_vm_hitinvalid.

Lemma t6_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 18 6 getPendingContractAdmin_vm_code (M6_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 17 7 getPendingContractAdmin_vm_code (M7_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M6_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingContractAdmin_vm_hitinvalid.

Lemma t7_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 17 7 getPendingContractAdmin_vm_code (M7_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 16 8 getPendingContractAdmin_vm_code (M8_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M7_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingContractAdmin_vm_hitinvalid.

Lemma t8_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 16 8 getPendingContractAdmin_vm_code (M8_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 15 11 getPendingContractAdmin_vm_code (M9_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M8_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingContractAdmin_vm_hitinvalid.

Lemma t9_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 15 11 getPendingContractAdmin_vm_code (M9_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 14 12 getPendingContractAdmin_vm_code (M10_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M9_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingContractAdmin_vm_hitinvalid.

Lemma t10_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 14 12 getPendingContractAdmin_vm_code (M10_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 13 13 getPendingContractAdmin_vm_code (M11_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M10_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingContractAdmin_vm_hitinvalid.

Lemma t11_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 13 13 getPendingContractAdmin_vm_code (M11_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 12 14 getPendingContractAdmin_vm_code (M12_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M11_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingContractAdmin_vm_hitinvalid.

Lemma t12_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 12 14 getPendingContractAdmin_vm_code (M12_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 11 15 getPendingContractAdmin_vm_code (M13_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M12_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPendingContractAdmin_vm_hitinvalid.

Lemma t13_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 11 15 getPendingContractAdmin_vm_code (M13_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 10 16 getPendingContractAdmin_vm_code (M14_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M13_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingContractAdmin_vm_hitinvalid.

Lemma t14_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 10 16 getPendingContractAdmin_vm_code (M14_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 9 17 getPendingContractAdmin_vm_code (M15_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M14_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingContractAdmin_vm_hitinvalid.

Lemma t15_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 9 17 getPendingContractAdmin_vm_code (M15_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 8 18 getPendingContractAdmin_vm_code (M16_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M15_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingContractAdmin_vm_hitinvalid.

Lemma t16_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes) (Hz : Z.eqb (Z.of_nat (length payload)) 20%Z = false),
 run 8 18 getPendingContractAdmin_vm_code (M16_getPendingContractAdmin_vm_hitinvalid sto payload) =
 run 7 19 getPendingContractAdmin_vm_code (M17_getPendingContractAdmin_vm_hitinvalid sto payload).
Proof.
 intros sto payload Hz.
 rewrite run_S.
 cbn [M16_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hz.
 reflexivity.
Qed.
Print Assumptions t16_getPendingContractAdmin_vm_hitinvalid.

Lemma t17_getPendingContractAdmin_vm_hitinvalid : forall (sto : storage) (payload : bytes),
 run 7 19 getPendingContractAdmin_vm_code (M17_getPendingContractAdmin_vm_hitinvalid sto payload) = Thrown.
Proof.
 intros sto payload.
 rewrite run_S.
 cbn [M17_getPendingContractAdmin_vm_hitinvalid getPendingContractAdmin_vm_init getPendingContractAdmin_vm_code getPendingContractAdmin_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingContractAdmin_vm_hitinvalid.

Theorem getPendingContractAdmin_vm_miss : forall sto,
 sto (getPendingContractAdmin_prefix) = None ->
 run 24 0 getPendingContractAdmin_vm_code (getPendingContractAdmin_vm_init sto) = Done (GBytes hash160_default) /\
 getter_outcome getPendingContractAdmin_prefix (GBytes hash160_default) decode_hash160 sto [] = OK (GBytes hash160_default).
Proof.
 intros sto Hstore. split.
 - exact (eq_trans (t0_getPendingContractAdmin_vm_miss sto) (eq_trans (t1_getPendingContractAdmin_vm_miss sto) (eq_trans (t2_getPendingContractAdmin_vm_miss sto) (eq_trans (t3_getPendingContractAdmin_vm_miss sto Hstore) (eq_trans (t4_getPendingContractAdmin_vm_miss sto) (eq_trans (t5_getPendingContractAdmin_vm_miss sto) (eq_trans (t6_getPendingContractAdmin_vm_miss sto) (eq_trans (t7_getPendingContractAdmin_vm_miss sto) (eq_trans (t8_getPendingContractAdmin_vm_miss sto) (eq_trans (t9_getPendingContractAdmin_vm_miss sto) (eq_trans (t10_getPendingContractAdmin_vm_miss sto) (eq_trans (t11_getPendingContractAdmin_vm_miss sto) (t12_getPendingContractAdmin_vm_miss sto))))))))))))).
 - unfold getter_outcome. rewrite app_nil_r, Hstore. reflexivity.
Qed.
Print Assumptions getPendingContractAdmin_vm_miss.
Theorem getPendingContractAdmin_vm_hit_valid : forall sto payload,
 sto (getPendingContractAdmin_prefix) = Some payload ->
 valid_bytes payload = true ->
 (length payload = 20)%nat ->
 run 24 0 getPendingContractAdmin_vm_code (getPendingContractAdmin_vm_init sto) = Done (GBytes payload) /\
 getter_outcome getPendingContractAdmin_prefix (GBytes hash160_default) decode_hash160 sto [] = OK (GBytes payload).
Proof.
 intros sto payload Hstore Hvalid Hlen.
 assert (Hz : Z.eqb (Z.of_nat (length payload)) 20 = true).
 { apply Z.eqb_eq. rewrite Hlen. reflexivity. }
 split.
 - exact (eq_trans (t0_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t1_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t2_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t3_getPendingContractAdmin_vm_hitvalid sto payload Hstore) (eq_trans (t4_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t5_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t6_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t7_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t8_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t9_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t10_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t11_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t12_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t13_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t14_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t15_getPendingContractAdmin_vm_hitvalid sto payload) (eq_trans (t16_getPendingContractAdmin_vm_hitvalid sto payload Hz) (eq_trans (t17_getPendingContractAdmin_vm_hitvalid sto payload) (t18_getPendingContractAdmin_vm_hitvalid sto payload))))))))))))))))))).
 - unfold getter_outcome, decode_hash160.
   rewrite app_nil_r, Hstore, Hvalid, Hlen. reflexivity.
Qed.
Print Assumptions getPendingContractAdmin_vm_hit_valid.
Theorem getPendingContractAdmin_vm_hit_invalid_size : forall sto payload,
 sto (getPendingContractAdmin_prefix) = Some payload ->
 (length payload <> 20)%nat ->
 run 24 0 getPendingContractAdmin_vm_code (getPendingContractAdmin_vm_init sto) = Thrown /\
 getter_outcome getPendingContractAdmin_prefix (GBytes hash160_default) decode_hash160 sto [] = Fault.
Proof.
 intros sto payload Hstore Hlen.
 assert (Hz : Z.eqb (Z.of_nat (length payload)) 20 = false).
 { apply Z.eqb_neq. intro He. apply Hlen.
   apply (Nat2Z.inj (length payload) 20 He). }
 split.
 - exact (eq_trans (t0_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t1_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t2_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t3_getPendingContractAdmin_vm_hitinvalid sto payload Hstore) (eq_trans (t4_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t5_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t6_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t7_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t8_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t9_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t10_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t11_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t12_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t13_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t14_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t15_getPendingContractAdmin_vm_hitinvalid sto payload) (eq_trans (t16_getPendingContractAdmin_vm_hitinvalid sto payload Hz) (t17_getPendingContractAdmin_vm_hitinvalid sto payload)))))))))))))))))).
 - unfold getter_outcome, decode_hash160. rewrite app_nil_r, Hstore.
   apply Nat.eqb_neq in Hlen. rewrite Hlen, andb_false_r. reflexivity.
Qed.
Print Assumptions getPendingContractAdmin_vm_hit_invalid_size.
