From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Definition bytes_eqb (a b : bytes) : bool :=
  match list_eq_dec Nat.eq_dec a b with left _ => true | right _ => false end.
Definition fixture_storage : storage := fun key => if bytes_eqb key [29%nat;1%nat] then Some [5%nat] else None.
Definition tok (i : nat) (v : GVal) : GVal := GNull.
Definition mutant_program : list Ins :=
 [InitSlot 1 1; LdArg; Call 22; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 10; Push (GInt 0); Jump 20; LdLoc 0; Dup; IsNull; JumpIfNot 17; Drop; Push (GInt 0); Jump 18; Convert 33; Push (GInt 0); AddIns; Jump 21; Ret; InitSlot 1 1; LdStatic 32; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; Jump 32; Ret].
Definition mutant_code (pc : nat) : Ins := nth pc mutant_program Unsupported.
Definition mutant_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 32 then Some (GBytes [29%nat])
          else if Nat.eqb i 37 then Some (GInt 604800000%Z) else None.
Definition mutant_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 1) [GBytes account] mutant_statics sto [] tok.
Ltac vm_drive_mut :=
  repeat (first
    [ progress (rewrite run_S)
    | progress cbn [mutant_code mutant_program mutant_statics fixture_storage bytes_eqb
                    tok nth Nat.eq_dec Nat.eqb step storage_lookup pop popn
                    pushv set_stack set_locals set_statics set_calls mstack
                    mlocals margs mstatics msto mcalls mtokens gval_eqb
                    gbytes_eqb gval_size repeat firstn skipn nth_error app
                    Z.eqb Z.ltb Z.to_nat negb andb] ]).
Example mutant_vm_matches_original :
 run 35 0 mutant_code (mutant_init fixture_storage [1%nat]) = Done (GInt 604800005).
Proof.
 vm_drive_mut. reflexivity.
Qed.
