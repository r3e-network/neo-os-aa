From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageMutant0.
Example mutant_matches_original : mutant_binding fixture_storage [1%nat] =
 original_binding fixture_storage [1%nat].
Proof. reflexivity. Qed.
