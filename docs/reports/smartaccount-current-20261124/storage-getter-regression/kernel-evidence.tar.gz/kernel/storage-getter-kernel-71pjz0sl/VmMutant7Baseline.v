From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Definition bytes_eqb (a b : bytes) : bool :=
  match list_eq_dec Nat.eq_dec a b with left _ => true | right _ => false end.
Definition fixture_storage : storage := fun _ => None.
Definition tok (i : nat) (v : GVal) : GVal := GNull.
Definition mutant_program : list Ins :=
 [InitSlot 1 1; LdStatic 15; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; Push GNull; NotEqualIns; Jump 12; Ret].
Definition mutant_code (pc : nat) : Ins := nth pc mutant_program Unsupported.
Definition mutant_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 15 then Some (GBytes [9%nat]) else None.
Definition mutant_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 1) [GBytes account] mutant_statics sto [] tok.
Ltac vm_drive_mut :=
  repeat (first
    [ progress (rewrite run_S)
    | progress cbn [mutant_code mutant_program mutant_statics fixture_storage bytes_eqb
                    tok nth Nat.eq_dec Nat.eqb step storage_lookup pop popn
                    pushv set_stack set_locals set_statics set_calls mstack
                    mlocals margs mstatics msto mcalls mtokens gval_eqb
                    gbytes_eqb gval_size repeat firstn skipn nth_error app
                    Z.eqb Z.ltb Z.to_nat negb andb] ]).
Example mutant_vm_matches_original :
 run 15 0 mutant_code (mutant_init fixture_storage [1%nat]) = Done (GBool false).
Proof.
 vm_drive_mut. reflexivity.
Qed.
