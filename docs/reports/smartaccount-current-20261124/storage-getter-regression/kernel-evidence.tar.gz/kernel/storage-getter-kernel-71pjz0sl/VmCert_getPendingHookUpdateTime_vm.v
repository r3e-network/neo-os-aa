From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getPendingHookUpdateTime_vm_program : list Ins :=
 [InitSlot 3 1; LdStatic 13; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 16; Push (GInt 0); Jump 25; LdLoc 1; CallToken 4; StLoc 2; LdLoc 2; Push (GInt 3); PickItem; LdStatic 14; AddIns; Jump 25; Ret].
Definition getPendingHookUpdateTime_vm_code (pc : nat) : Ins := nth pc getPendingHookUpdateTime_vm_program Unsupported.
Definition getPendingHookUpdateTime_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 13 then Some (GBytes getPendingHookUpdateTime_prefix)
          else if Nat.eqb i 14 then Some (GInt 86400000%Z) else None.
Definition getPendingHookUpdateTime_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 3) [GBytes account] getPendingHookUpdateTime_vm_statics sto [] tok.

Definition M0_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 getPendingHookUpdateTime_vm_init tok sto account.

Definition M1_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingHookUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M5_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingHookUpdateTime_prefix ++ account)]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M6_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M7_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingHookUpdateTime_prefix ++ account)]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M8_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingHookUpdateTime_prefix ++ account)]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M9_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M10_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M11_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M12_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M13_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M14_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M15_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M16_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M17_getPendingHookUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 28 0 getPendingHookUpdateTime_vm_code (M0_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 27 1 getPendingHookUpdateTime_vm_code (M1_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingHookUpdateTime_vm_miss.

Lemma t1_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 1 getPendingHookUpdateTime_vm_code (M1_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 26 2 getPendingHookUpdateTime_vm_code (M2_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingHookUpdateTime_vm_miss.

Lemma t2_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 2 getPendingHookUpdateTime_vm_code (M2_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 25 3 getPendingHookUpdateTime_vm_code (M3_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingHookUpdateTime_vm_miss.

Lemma t3_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 3 getPendingHookUpdateTime_vm_code (M3_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 24 4 getPendingHookUpdateTime_vm_code (M4_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingHookUpdateTime_vm_miss.

Lemma t4_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 4 getPendingHookUpdateTime_vm_code (M4_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 23 5 getPendingHookUpdateTime_vm_code (M5_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingHookUpdateTime_vm_miss.

Lemma t5_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 5 getPendingHookUpdateTime_vm_code (M5_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 22 6 getPendingHookUpdateTime_vm_code (M6_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingHookUpdateTime_vm_miss.

Lemma t6_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 6 getPendingHookUpdateTime_vm_code (M6_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 21 7 getPendingHookUpdateTime_vm_code (M7_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingHookUpdateTime_vm_miss.

Lemma t7_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 7 getPendingHookUpdateTime_vm_code (M7_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 20 8 getPendingHookUpdateTime_vm_code (M8_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingHookUpdateTime_vm_miss.

Lemma t8_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (Hstore : sto (getPendingHookUpdateTime_prefix ++ account) = None),
 run 20 8 getPendingHookUpdateTime_vm_code (M8_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 19 9 getPendingHookUpdateTime_vm_code (M9_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account Hstore.
 rewrite run_S.
 cbn [M8_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getPendingHookUpdateTime_vm_miss.

Lemma t9_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 9 getPendingHookUpdateTime_vm_code (M9_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 18 10 getPendingHookUpdateTime_vm_code (M10_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingHookUpdateTime_vm_miss.

Lemma t10_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 18 10 getPendingHookUpdateTime_vm_code (M10_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 17 11 getPendingHookUpdateTime_vm_code (M11_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingHookUpdateTime_vm_miss.

Lemma t11_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 11 getPendingHookUpdateTime_vm_code (M11_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 16 12 getPendingHookUpdateTime_vm_code (M12_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M11_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingHookUpdateTime_vm_miss.

Lemma t12_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 12 getPendingHookUpdateTime_vm_code (M12_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 15 13 getPendingHookUpdateTime_vm_code (M13_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M12_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPendingHookUpdateTime_vm_miss.

Lemma t13_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 13 getPendingHookUpdateTime_vm_code (M13_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 14 14 getPendingHookUpdateTime_vm_code (M14_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingHookUpdateTime_vm_miss.

Lemma t14_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 14 getPendingHookUpdateTime_vm_code (M14_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 13 15 getPendingHookUpdateTime_vm_code (M15_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingHookUpdateTime_vm_miss.

Lemma t15_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 15 getPendingHookUpdateTime_vm_code (M15_getPendingHookUpdateTime_vm_miss tok sto account) =
 run 12 25 getPendingHookUpdateTime_vm_code (M16_getPendingHookUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingHookUpdateTime_vm_miss.

Lemma t16_getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 25 getPendingHookUpdateTime_vm_code (M16_getPendingHookUpdateTime_vm_miss tok sto account) = Done (GInt 0%Z).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_getPendingHookUpdateTime_vm_miss getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingHookUpdateTime_vm_miss.
Definition M0_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 getPendingHookUpdateTime_vm_init tok sto account.

Definition M1_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingHookUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingHookUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M5_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes (getPendingHookUpdateTime_prefix ++ account)]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M6_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M7_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes (getPendingHookUpdateTime_prefix ++ account)]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M8_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingHookUpdateTime_prefix ++ account)]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M9_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M10_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M11_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M12_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M13_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M14_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M15_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M16_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M17_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M18_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M19_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt 3%Z; GArray xs]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M20_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt z]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M21_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt 86400000%Z; GInt z]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z)]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z)]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getPendingHookUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z)]; mlocals := [GBytes (getPendingHookUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingHookUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 28 0 getPendingHookUpdateTime_vm_code (M0_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 27 1 getPendingHookUpdateTime_vm_code (M1_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M0_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingHookUpdateTime_vm_hit.

Lemma t1_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 27 1 getPendingHookUpdateTime_vm_code (M1_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 26 2 getPendingHookUpdateTime_vm_code (M2_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M1_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingHookUpdateTime_vm_hit.

Lemma t2_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 26 2 getPendingHookUpdateTime_vm_code (M2_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 25 3 getPendingHookUpdateTime_vm_code (M3_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M2_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingHookUpdateTime_vm_hit.

Lemma t3_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 25 3 getPendingHookUpdateTime_vm_code (M3_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 24 4 getPendingHookUpdateTime_vm_code (M4_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M3_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingHookUpdateTime_vm_hit.

Lemma t4_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 24 4 getPendingHookUpdateTime_vm_code (M4_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 23 5 getPendingHookUpdateTime_vm_code (M5_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M4_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingHookUpdateTime_vm_hit.

Lemma t5_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 23 5 getPendingHookUpdateTime_vm_code (M5_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 22 6 getPendingHookUpdateTime_vm_code (M6_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M5_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingHookUpdateTime_vm_hit.

Lemma t6_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 22 6 getPendingHookUpdateTime_vm_code (M6_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 21 7 getPendingHookUpdateTime_vm_code (M7_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M6_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingHookUpdateTime_vm_hit.

Lemma t7_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 21 7 getPendingHookUpdateTime_vm_code (M7_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 20 8 getPendingHookUpdateTime_vm_code (M8_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M7_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingHookUpdateTime_vm_hit.

Lemma t8_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hstore : sto (getPendingHookUpdateTime_prefix ++ account) = Some payload),
 run 20 8 getPendingHookUpdateTime_vm_code (M8_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 19 9 getPendingHookUpdateTime_vm_code (M9_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hstore.
 rewrite run_S.
 cbn [M8_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getPendingHookUpdateTime_vm_hit.

Lemma t9_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 19 9 getPendingHookUpdateTime_vm_code (M9_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 18 10 getPendingHookUpdateTime_vm_code (M10_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M9_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingHookUpdateTime_vm_hit.

Lemma t10_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 18 10 getPendingHookUpdateTime_vm_code (M10_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 17 11 getPendingHookUpdateTime_vm_code (M11_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M10_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingHookUpdateTime_vm_hit.

Lemma t11_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 17 11 getPendingHookUpdateTime_vm_code (M11_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 16 12 getPendingHookUpdateTime_vm_code (M12_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M11_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingHookUpdateTime_vm_hit.

Lemma t12_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 16 12 getPendingHookUpdateTime_vm_code (M12_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 15 13 getPendingHookUpdateTime_vm_code (M13_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M12_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPendingHookUpdateTime_vm_hit.

Lemma t13_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 15 13 getPendingHookUpdateTime_vm_code (M13_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 14 16 getPendingHookUpdateTime_vm_code (M14_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M13_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingHookUpdateTime_vm_hit.

Lemma t14_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 14 16 getPendingHookUpdateTime_vm_code (M14_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 13 17 getPendingHookUpdateTime_vm_code (M15_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M14_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingHookUpdateTime_vm_hit.

Lemma t15_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 13 17 getPendingHookUpdateTime_vm_code (M15_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 12 18 getPendingHookUpdateTime_vm_code (M16_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Htok.
 rewrite run_S.
 cbn [M15_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t15_getPendingHookUpdateTime_vm_hit.

Lemma t16_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 12 18 getPendingHookUpdateTime_vm_code (M16_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 11 19 getPendingHookUpdateTime_vm_code (M17_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M16_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingHookUpdateTime_vm_hit.

Lemma t17_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 11 19 getPendingHookUpdateTime_vm_code (M17_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 10 20 getPendingHookUpdateTime_vm_code (M18_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M17_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingHookUpdateTime_vm_hit.

Lemma t18_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 10 20 getPendingHookUpdateTime_vm_code (M18_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 9 21 getPendingHookUpdateTime_vm_code (M19_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M18_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingHookUpdateTime_vm_hit.

Lemma t19_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hnth : nth_error xs (Z.to_nat 3%Z) = Some (GInt z)),
 run 9 21 getPendingHookUpdateTime_vm_code (M19_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 8 22 getPendingHookUpdateTime_vm_code (M20_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hnth.
 rewrite run_S.
 cbn [M19_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t19_getPendingHookUpdateTime_vm_hit.

Lemma t20_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 8 22 getPendingHookUpdateTime_vm_code (M20_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 7 23 getPendingHookUpdateTime_vm_code (M21_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M20_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getPendingHookUpdateTime_vm_hit.

Lemma t21_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hsum : integer_fitsb (z + 86400000) = true),
 run 7 23 getPendingHookUpdateTime_vm_code (M21_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 6 24 getPendingHookUpdateTime_vm_code (M22_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hsum.
 rewrite run_S.
 cbn [M21_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hsum.
 reflexivity.
Qed.
Print Assumptions t21_getPendingHookUpdateTime_vm_hit.

Lemma t22_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 6 24 getPendingHookUpdateTime_vm_code (M22_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) =
 run 5 25 getPendingHookUpdateTime_vm_code (M23_getPendingHookUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M22_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getPendingHookUpdateTime_vm_hit.

Lemma t23_getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 5 25 getPendingHookUpdateTime_vm_code (M23_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) = Done (GInt (z + 86400000%Z)).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M23_getPendingHookUpdateTime_vm_hit getPendingHookUpdateTime_vm_init getPendingHookUpdateTime_vm_code getPendingHookUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getPendingHookUpdateTime_vm_hit.

Theorem getPendingHookUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (getPendingHookUpdateTime_prefix ++ account) = None ->
 run 28 0 getPendingHookUpdateTime_vm_code (getPendingHookUpdateTime_vm_init tok sto account) = Done (GInt 0%Z) /\
 getPendingHookUpdateTime_binding tok sto account = OK (GInt 0%Z).
Proof.
 intros tok sto account Hstore. split.
 - exact (eq_trans (t0_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t1_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t2_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t3_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t4_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t5_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t6_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t7_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t8_getPendingHookUpdateTime_vm_miss tok sto account Hstore) (eq_trans (t9_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t10_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t11_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t12_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t13_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t14_getPendingHookUpdateTime_vm_miss tok sto account) (eq_trans (t15_getPendingHookUpdateTime_vm_miss tok sto account) (t16_getPendingHookUpdateTime_vm_miss tok sto account))))))))))))))))).
 - apply getPendingHookUpdateTime_source_miss. exact Hstore.
Qed.
Print Assumptions getPendingHookUpdateTime_vm_miss.
Theorem getPendingHookUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) sto account (payload : bytes) (xs : list GVal) (z : Z),
 sto (getPendingHookUpdateTime_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs (Z.to_nat 3%Z) = Some (GInt z) ->
 integer_fitsb (z + 86400000%Z) = true ->
 run 28 0 getPendingHookUpdateTime_vm_code (getPendingHookUpdateTime_vm_init tok sto account) = Done (GInt (z + 86400000%Z)) /\
 getPendingHookUpdateTime_binding tok sto account = OK (GInt (z + 86400000%Z)).
Proof.
 intros tok sto account payload xs z Hstore Htok Hnth Hsum. split.
 - exact (eq_trans (t0_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t1_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t2_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t3_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t4_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t5_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t6_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t7_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t8_getPendingHookUpdateTime_vm_hit tok sto account payload xs z Hstore) (eq_trans (t9_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t10_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t11_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t12_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t13_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t14_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t15_getPendingHookUpdateTime_vm_hit tok sto account payload xs z Htok) (eq_trans (t16_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t17_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t18_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t19_getPendingHookUpdateTime_vm_hit tok sto account payload xs z Hnth) (eq_trans (t20_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t21_getPendingHookUpdateTime_vm_hit tok sto account payload xs z Hsum) (eq_trans (t22_getPendingHookUpdateTime_vm_hit tok sto account payload xs z) (t23_getPendingHookUpdateTime_vm_hit tok sto account payload xs z)))))))))))))))))))))))).
 - apply getPendingHookUpdateTime_source_hit with (payload := payload) (xs := xs) (z := z); assumption.
Qed.
Print Assumptions getPendingHookUpdateTime_vm_hit.
