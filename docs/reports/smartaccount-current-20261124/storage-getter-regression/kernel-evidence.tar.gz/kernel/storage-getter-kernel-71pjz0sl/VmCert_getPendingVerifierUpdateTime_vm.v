From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getPendingVerifierUpdateTime_vm_program : list Ins :=
 [InitSlot 3 1; LdStatic 15; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 16; Push (GInt 0); Jump 25; LdLoc 1; CallToken 4; StLoc 2; LdLoc 2; Push (GInt 3); PickItem; LdStatic 14; AddIns; Jump 25; Ret].
Definition getPendingVerifierUpdateTime_vm_code (pc : nat) : Ins := nth pc getPendingVerifierUpdateTime_vm_program Unsupported.
Definition getPendingVerifierUpdateTime_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 15 then Some (GBytes getPendingVerifierUpdateTime_prefix)
          else if Nat.eqb i 14 then Some (GInt 86400000%Z) else None.
Definition getPendingVerifierUpdateTime_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 3) [GBytes account] getPendingVerifierUpdateTime_vm_statics sto [] tok.

Definition M0_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 getPendingVerifierUpdateTime_vm_init tok sto account.

Definition M1_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingVerifierUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingVerifierUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M5_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingVerifierUpdateTime_prefix ++ account)]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M6_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M7_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingVerifierUpdateTime_prefix ++ account)]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M8_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingVerifierUpdateTime_prefix ++ account)]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M9_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M10_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M11_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M12_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M13_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M14_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M15_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M16_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M17_getPendingVerifierUpdateTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 28 0 getPendingVerifierUpdateTime_vm_code (M0_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 27 1 getPendingVerifierUpdateTime_vm_code (M1_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingVerifierUpdateTime_vm_miss.

Lemma t1_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 1 getPendingVerifierUpdateTime_vm_code (M1_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 26 2 getPendingVerifierUpdateTime_vm_code (M2_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingVerifierUpdateTime_vm_miss.

Lemma t2_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 2 getPendingVerifierUpdateTime_vm_code (M2_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 25 3 getPendingVerifierUpdateTime_vm_code (M3_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingVerifierUpdateTime_vm_miss.

Lemma t3_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 3 getPendingVerifierUpdateTime_vm_code (M3_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 24 4 getPendingVerifierUpdateTime_vm_code (M4_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingVerifierUpdateTime_vm_miss.

Lemma t4_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 4 getPendingVerifierUpdateTime_vm_code (M4_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 23 5 getPendingVerifierUpdateTime_vm_code (M5_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingVerifierUpdateTime_vm_miss.

Lemma t5_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 5 getPendingVerifierUpdateTime_vm_code (M5_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 22 6 getPendingVerifierUpdateTime_vm_code (M6_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingVerifierUpdateTime_vm_miss.

Lemma t6_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 6 getPendingVerifierUpdateTime_vm_code (M6_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 21 7 getPendingVerifierUpdateTime_vm_code (M7_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingVerifierUpdateTime_vm_miss.

Lemma t7_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 7 getPendingVerifierUpdateTime_vm_code (M7_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 20 8 getPendingVerifierUpdateTime_vm_code (M8_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingVerifierUpdateTime_vm_miss.

Lemma t8_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (Hstore : sto (getPendingVerifierUpdateTime_prefix ++ account) = None),
 run 20 8 getPendingVerifierUpdateTime_vm_code (M8_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 19 9 getPendingVerifierUpdateTime_vm_code (M9_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account Hstore.
 rewrite run_S.
 cbn [M8_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getPendingVerifierUpdateTime_vm_miss.

Lemma t9_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 9 getPendingVerifierUpdateTime_vm_code (M9_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 18 10 getPendingVerifierUpdateTime_vm_code (M10_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingVerifierUpdateTime_vm_miss.

Lemma t10_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 18 10 getPendingVerifierUpdateTime_vm_code (M10_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 17 11 getPendingVerifierUpdateTime_vm_code (M11_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingVerifierUpdateTime_vm_miss.

Lemma t11_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 11 getPendingVerifierUpdateTime_vm_code (M11_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 16 12 getPendingVerifierUpdateTime_vm_code (M12_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M11_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingVerifierUpdateTime_vm_miss.

Lemma t12_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 12 getPendingVerifierUpdateTime_vm_code (M12_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 15 13 getPendingVerifierUpdateTime_vm_code (M13_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M12_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPendingVerifierUpdateTime_vm_miss.

Lemma t13_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 13 getPendingVerifierUpdateTime_vm_code (M13_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 14 14 getPendingVerifierUpdateTime_vm_code (M14_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingVerifierUpdateTime_vm_miss.

Lemma t14_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 14 getPendingVerifierUpdateTime_vm_code (M14_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 13 15 getPendingVerifierUpdateTime_vm_code (M15_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingVerifierUpdateTime_vm_miss.

Lemma t15_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 15 getPendingVerifierUpdateTime_vm_code (M15_getPendingVerifierUpdateTime_vm_miss tok sto account) =
 run 12 25 getPendingVerifierUpdateTime_vm_code (M16_getPendingVerifierUpdateTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingVerifierUpdateTime_vm_miss.

Lemma t16_getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 25 getPendingVerifierUpdateTime_vm_code (M16_getPendingVerifierUpdateTime_vm_miss tok sto account) = Done (GInt 0%Z).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_getPendingVerifierUpdateTime_vm_miss getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingVerifierUpdateTime_vm_miss.
Definition M0_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 getPendingVerifierUpdateTime_vm_init tok sto account.

Definition M1_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingVerifierUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingVerifierUpdateTime_prefix]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M5_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes (getPendingVerifierUpdateTime_prefix ++ account)]; mlocals := [GNull; GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M6_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M7_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes (getPendingVerifierUpdateTime_prefix ++ account)]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M8_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingVerifierUpdateTime_prefix ++ account)]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M9_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GNull; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M10_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M11_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M12_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M13_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M14_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M15_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M16_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GNull]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M17_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M18_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M19_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt 3%Z; GArray xs]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M20_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt z]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M21_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt 86400000%Z; GInt z]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z)]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z)]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getPendingVerifierUpdateTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z)]; mlocals := [GBytes (getPendingVerifierUpdateTime_prefix ++ account); GBytes payload; GArray xs]; margs := [GBytes account];
    mstatics := getPendingVerifierUpdateTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 28 0 getPendingVerifierUpdateTime_vm_code (M0_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 27 1 getPendingVerifierUpdateTime_vm_code (M1_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M0_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingVerifierUpdateTime_vm_hit.

Lemma t1_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 27 1 getPendingVerifierUpdateTime_vm_code (M1_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 26 2 getPendingVerifierUpdateTime_vm_code (M2_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M1_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingVerifierUpdateTime_vm_hit.

Lemma t2_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 26 2 getPendingVerifierUpdateTime_vm_code (M2_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 25 3 getPendingVerifierUpdateTime_vm_code (M3_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M2_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingVerifierUpdateTime_vm_hit.

Lemma t3_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 25 3 getPendingVerifierUpdateTime_vm_code (M3_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 24 4 getPendingVerifierUpdateTime_vm_code (M4_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M3_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingVerifierUpdateTime_vm_hit.

Lemma t4_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 24 4 getPendingVerifierUpdateTime_vm_code (M4_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 23 5 getPendingVerifierUpdateTime_vm_code (M5_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M4_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingVerifierUpdateTime_vm_hit.

Lemma t5_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 23 5 getPendingVerifierUpdateTime_vm_code (M5_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 22 6 getPendingVerifierUpdateTime_vm_code (M6_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M5_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingVerifierUpdateTime_vm_hit.

Lemma t6_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 22 6 getPendingVerifierUpdateTime_vm_code (M6_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 21 7 getPendingVerifierUpdateTime_vm_code (M7_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M6_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingVerifierUpdateTime_vm_hit.

Lemma t7_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 21 7 getPendingVerifierUpdateTime_vm_code (M7_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 20 8 getPendingVerifierUpdateTime_vm_code (M8_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M7_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingVerifierUpdateTime_vm_hit.

Lemma t8_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hstore : sto (getPendingVerifierUpdateTime_prefix ++ account) = Some payload),
 run 20 8 getPendingVerifierUpdateTime_vm_code (M8_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 19 9 getPendingVerifierUpdateTime_vm_code (M9_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hstore.
 rewrite run_S.
 cbn [M8_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getPendingVerifierUpdateTime_vm_hit.

Lemma t9_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 19 9 getPendingVerifierUpdateTime_vm_code (M9_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 18 10 getPendingVerifierUpdateTime_vm_code (M10_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M9_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingVerifierUpdateTime_vm_hit.

Lemma t10_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 18 10 getPendingVerifierUpdateTime_vm_code (M10_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 17 11 getPendingVerifierUpdateTime_vm_code (M11_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M10_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingVerifierUpdateTime_vm_hit.

Lemma t11_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 17 11 getPendingVerifierUpdateTime_vm_code (M11_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 16 12 getPendingVerifierUpdateTime_vm_code (M12_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M11_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingVerifierUpdateTime_vm_hit.

Lemma t12_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 16 12 getPendingVerifierUpdateTime_vm_code (M12_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 15 13 getPendingVerifierUpdateTime_vm_code (M13_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M12_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getPendingVerifierUpdateTime_vm_hit.

Lemma t13_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 15 13 getPendingVerifierUpdateTime_vm_code (M13_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 14 16 getPendingVerifierUpdateTime_vm_code (M14_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M13_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingVerifierUpdateTime_vm_hit.

Lemma t14_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 14 16 getPendingVerifierUpdateTime_vm_code (M14_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 13 17 getPendingVerifierUpdateTime_vm_code (M15_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M14_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingVerifierUpdateTime_vm_hit.

Lemma t15_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 13 17 getPendingVerifierUpdateTime_vm_code (M15_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 12 18 getPendingVerifierUpdateTime_vm_code (M16_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Htok.
 rewrite run_S.
 cbn [M15_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t15_getPendingVerifierUpdateTime_vm_hit.

Lemma t16_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 12 18 getPendingVerifierUpdateTime_vm_code (M16_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 11 19 getPendingVerifierUpdateTime_vm_code (M17_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M16_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingVerifierUpdateTime_vm_hit.

Lemma t17_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 11 19 getPendingVerifierUpdateTime_vm_code (M17_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 10 20 getPendingVerifierUpdateTime_vm_code (M18_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M17_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingVerifierUpdateTime_vm_hit.

Lemma t18_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 10 20 getPendingVerifierUpdateTime_vm_code (M18_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 9 21 getPendingVerifierUpdateTime_vm_code (M19_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M18_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingVerifierUpdateTime_vm_hit.

Lemma t19_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hnth : nth_error xs (Z.to_nat 3%Z) = Some (GInt z)),
 run 9 21 getPendingVerifierUpdateTime_vm_code (M19_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 8 22 getPendingVerifierUpdateTime_vm_code (M20_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hnth.
 rewrite run_S.
 cbn [M19_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t19_getPendingVerifierUpdateTime_vm_hit.

Lemma t20_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 8 22 getPendingVerifierUpdateTime_vm_code (M20_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 7 23 getPendingVerifierUpdateTime_vm_code (M21_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M20_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getPendingVerifierUpdateTime_vm_hit.

Lemma t21_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hsum : integer_fitsb (z + 86400000) = true),
 run 7 23 getPendingVerifierUpdateTime_vm_code (M21_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 6 24 getPendingVerifierUpdateTime_vm_code (M22_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hsum.
 rewrite run_S.
 cbn [M21_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hsum.
 reflexivity.
Qed.
Print Assumptions t21_getPendingVerifierUpdateTime_vm_hit.

Lemma t22_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 6 24 getPendingVerifierUpdateTime_vm_code (M22_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) =
 run 5 25 getPendingVerifierUpdateTime_vm_code (M23_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M22_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getPendingVerifierUpdateTime_vm_hit.

Lemma t23_getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 5 25 getPendingVerifierUpdateTime_vm_code (M23_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) = Done (GInt (z + 86400000%Z)).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M23_getPendingVerifierUpdateTime_vm_hit getPendingVerifierUpdateTime_vm_init getPendingVerifierUpdateTime_vm_code getPendingVerifierUpdateTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getPendingVerifierUpdateTime_vm_hit.

Theorem getPendingVerifierUpdateTime_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (getPendingVerifierUpdateTime_prefix ++ account) = None ->
 run 28 0 getPendingVerifierUpdateTime_vm_code (getPendingVerifierUpdateTime_vm_init tok sto account) = Done (GInt 0%Z) /\
 getPendingVerifierUpdateTime_binding tok sto account = OK (GInt 0%Z).
Proof.
 intros tok sto account Hstore. split.
 - exact (eq_trans (t0_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t1_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t2_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t3_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t4_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t5_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t6_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t7_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t8_getPendingVerifierUpdateTime_vm_miss tok sto account Hstore) (eq_trans (t9_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t10_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t11_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t12_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t13_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t14_getPendingVerifierUpdateTime_vm_miss tok sto account) (eq_trans (t15_getPendingVerifierUpdateTime_vm_miss tok sto account) (t16_getPendingVerifierUpdateTime_vm_miss tok sto account))))))))))))))))).
 - apply getPendingVerifierUpdateTime_source_miss. exact Hstore.
Qed.
Print Assumptions getPendingVerifierUpdateTime_vm_miss.
Theorem getPendingVerifierUpdateTime_vm_hit : forall (tok : nat -> GVal -> GVal) sto account (payload : bytes) (xs : list GVal) (z : Z),
 sto (getPendingVerifierUpdateTime_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs (Z.to_nat 3%Z) = Some (GInt z) ->
 integer_fitsb (z + 86400000%Z) = true ->
 run 28 0 getPendingVerifierUpdateTime_vm_code (getPendingVerifierUpdateTime_vm_init tok sto account) = Done (GInt (z + 86400000%Z)) /\
 getPendingVerifierUpdateTime_binding tok sto account = OK (GInt (z + 86400000%Z)).
Proof.
 intros tok sto account payload xs z Hstore Htok Hnth Hsum. split.
 - exact (eq_trans (t0_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t1_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t2_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t3_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t4_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t5_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t6_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t7_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t8_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z Hstore) (eq_trans (t9_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t10_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t11_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t12_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t13_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t14_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t15_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z Htok) (eq_trans (t16_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t17_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t18_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t19_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z Hnth) (eq_trans (t20_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (eq_trans (t21_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z Hsum) (eq_trans (t22_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z) (t23_getPendingVerifierUpdateTime_vm_hit tok sto account payload xs z)))))))))))))))))))))))).
 - apply getPendingVerifierUpdateTime_source_hit with (payload := payload) (xs := xs) (z := z); assumption.
Qed.
Print Assumptions getPendingVerifierUpdateTime_vm_hit.
