From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getHook_vm_program : list Ins :=
 [InitSlot 0 1; LdArg; Call 7; Push (GInt 1); PickItem; Jump 6; Ret; InitSlot 2 1; LdStatic 8; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; NotEqualIns; JumpIf 23; Push (GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]); AbortMsg; LdLoc 1; CallToken 4; Jump 26; Ret].
Definition getHook_vm_code (pc : nat) : Ins := nth pc getHook_vm_program Unsupported.
Definition getHook_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 8 then Some (GBytes account_state_prefix) else None.
Definition getHook_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account] getHook_vm_statics sto [] tok.

Definition M0_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 getHook_vm_init tok sto account.

Definition M1_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M4_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M5_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M6_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M7_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M8_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M9_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M10_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M11_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M12_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M13_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M14_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M15_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M16_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M17_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M18_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M19_getHook_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Lemma t0_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 29 0 getHook_vm_code (M0_getHook_vm_miss tok sto account) =
 run 28 1 getHook_vm_code (M1_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getHook_vm_miss.

Lemma t1_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 28 1 getHook_vm_code (M1_getHook_vm_miss tok sto account) =
 run 27 2 getHook_vm_code (M2_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getHook_vm_miss.

Lemma t2_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 2 getHook_vm_code (M2_getHook_vm_miss tok sto account) =
 run 26 7 getHook_vm_code (M3_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getHook_vm_miss.

Lemma t3_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 7 getHook_vm_code (M3_getHook_vm_miss tok sto account) =
 run 25 8 getHook_vm_code (M4_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getHook_vm_miss.

Lemma t4_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 8 getHook_vm_code (M4_getHook_vm_miss tok sto account) =
 run 24 9 getHook_vm_code (M5_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getHook_vm_miss.

Lemma t5_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 9 getHook_vm_code (M5_getHook_vm_miss tok sto account) =
 run 23 10 getHook_vm_code (M6_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getHook_vm_miss.

Lemma t6_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 10 getHook_vm_code (M6_getHook_vm_miss tok sto account) =
 run 22 11 getHook_vm_code (M7_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getHook_vm_miss.

Lemma t7_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 11 getHook_vm_code (M7_getHook_vm_miss tok sto account) =
 run 21 12 getHook_vm_code (M8_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getHook_vm_miss.

Lemma t8_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 12 getHook_vm_code (M8_getHook_vm_miss tok sto account) =
 run 20 13 getHook_vm_code (M9_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M8_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getHook_vm_miss.

Lemma t9_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 20 13 getHook_vm_code (M9_getHook_vm_miss tok sto account) =
 run 19 14 getHook_vm_code (M10_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getHook_vm_miss.

Lemma t10_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 14 getHook_vm_code (M10_getHook_vm_miss tok sto account) =
 run 18 15 getHook_vm_code (M11_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getHook_vm_miss.

Lemma t11_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (H : sto (account_state_prefix ++ account) = None),
 run 18 15 getHook_vm_code (M11_getHook_vm_miss tok sto account) =
 run 17 16 getHook_vm_code (M12_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account H.
 rewrite run_S.
 cbn [M11_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite H.
 reflexivity.
Qed.
Print Assumptions t11_getHook_vm_miss.

Lemma t12_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 16 getHook_vm_code (M12_getHook_vm_miss tok sto account) =
 run 16 17 getHook_vm_code (M13_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M12_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getHook_vm_miss.

Lemma t13_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 17 getHook_vm_code (M13_getHook_vm_miss tok sto account) =
 run 15 18 getHook_vm_code (M14_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getHook_vm_miss.

Lemma t14_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 18 getHook_vm_code (M14_getHook_vm_miss tok sto account) =
 run 14 19 getHook_vm_code (M15_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getHook_vm_miss.

Lemma t15_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 19 getHook_vm_code (M15_getHook_vm_miss tok sto account) =
 run 13 20 getHook_vm_code (M16_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getHook_vm_miss.

Lemma t16_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 20 getHook_vm_code (M16_getHook_vm_miss tok sto account) =
 run 12 21 getHook_vm_code (M17_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getHook_vm_miss.

Lemma t17_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 21 getHook_vm_code (M17_getHook_vm_miss tok sto account) =
 run 11 22 getHook_vm_code (M18_getHook_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M17_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getHook_vm_miss.

Lemma t18_getHook_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 11 22 getHook_vm_code (M18_getHook_vm_miss tok sto account) = Thrown.
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M18_getHook_vm_miss getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getHook_vm_miss.
Definition M0_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 getHook_vm_init tok sto account.

Definition M1_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M4_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M5_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M6_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M7_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M8_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M9_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M10_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M11_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M12_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M13_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M14_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M15_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M16_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBool true; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M17_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M18_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M19_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M20_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M21_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GInt 1%Z; GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getHook_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getHook_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 29 0 getHook_vm_code (M0_getHook_vm_hit tok sto account payload xs v) =
 run 28 1 getHook_vm_code (M1_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M0_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getHook_vm_hit.

Lemma t1_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 28 1 getHook_vm_code (M1_getHook_vm_hit tok sto account payload xs v) =
 run 27 2 getHook_vm_code (M2_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M1_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getHook_vm_hit.

Lemma t2_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 27 2 getHook_vm_code (M2_getHook_vm_hit tok sto account payload xs v) =
 run 26 7 getHook_vm_code (M3_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M2_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getHook_vm_hit.

Lemma t3_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 26 7 getHook_vm_code (M3_getHook_vm_hit tok sto account payload xs v) =
 run 25 8 getHook_vm_code (M4_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M3_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getHook_vm_hit.

Lemma t4_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 25 8 getHook_vm_code (M4_getHook_vm_hit tok sto account payload xs v) =
 run 24 9 getHook_vm_code (M5_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M4_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getHook_vm_hit.

Lemma t5_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 24 9 getHook_vm_code (M5_getHook_vm_hit tok sto account payload xs v) =
 run 23 10 getHook_vm_code (M6_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M5_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getHook_vm_hit.

Lemma t6_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 23 10 getHook_vm_code (M6_getHook_vm_hit tok sto account payload xs v) =
 run 22 11 getHook_vm_code (M7_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M6_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getHook_vm_hit.

Lemma t7_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 22 11 getHook_vm_code (M7_getHook_vm_hit tok sto account payload xs v) =
 run 21 12 getHook_vm_code (M8_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M7_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getHook_vm_hit.

Lemma t8_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 21 12 getHook_vm_code (M8_getHook_vm_hit tok sto account payload xs v) =
 run 20 13 getHook_vm_code (M9_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M8_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getHook_vm_hit.

Lemma t9_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 20 13 getHook_vm_code (M9_getHook_vm_hit tok sto account payload xs v) =
 run 19 14 getHook_vm_code (M10_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M9_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getHook_vm_hit.

Lemma t10_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 19 14 getHook_vm_code (M10_getHook_vm_hit tok sto account payload xs v) =
 run 18 15 getHook_vm_code (M11_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M10_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getHook_vm_hit.

Lemma t11_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (H : sto (account_state_prefix ++ account) = Some payload),
 run 18 15 getHook_vm_code (M11_getHook_vm_hit tok sto account payload xs v) =
 run 17 16 getHook_vm_code (M12_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v H.
 rewrite run_S.
 cbn [M11_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite H.
 reflexivity.
Qed.
Print Assumptions t11_getHook_vm_hit.

Lemma t12_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 17 16 getHook_vm_code (M12_getHook_vm_hit tok sto account payload xs v) =
 run 16 17 getHook_vm_code (M13_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M12_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getHook_vm_hit.

Lemma t13_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 16 17 getHook_vm_code (M13_getHook_vm_hit tok sto account payload xs v) =
 run 15 18 getHook_vm_code (M14_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M13_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getHook_vm_hit.

Lemma t14_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 15 18 getHook_vm_code (M14_getHook_vm_hit tok sto account payload xs v) =
 run 14 19 getHook_vm_code (M15_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M14_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getHook_vm_hit.

Lemma t15_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 14 19 getHook_vm_code (M15_getHook_vm_hit tok sto account payload xs v) =
 run 13 20 getHook_vm_code (M16_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M15_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getHook_vm_hit.

Lemma t16_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 13 20 getHook_vm_code (M16_getHook_vm_hit tok sto account payload xs v) =
 run 12 23 getHook_vm_code (M17_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M16_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getHook_vm_hit.

Lemma t17_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 12 23 getHook_vm_code (M17_getHook_vm_hit tok sto account payload xs v) =
 run 11 24 getHook_vm_code (M18_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M17_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getHook_vm_hit.

Lemma t18_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 11 24 getHook_vm_code (M18_getHook_vm_hit tok sto account payload xs v) =
 run 10 25 getHook_vm_code (M19_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Htok.
 rewrite run_S.
 cbn [M18_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t18_getHook_vm_hit.

Lemma t19_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 10 25 getHook_vm_code (M19_getHook_vm_hit tok sto account payload xs v) =
 run 9 26 getHook_vm_code (M20_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M19_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getHook_vm_hit.

Lemma t20_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 9 26 getHook_vm_code (M20_getHook_vm_hit tok sto account payload xs v) =
 run 8 3 getHook_vm_code (M21_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M20_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getHook_vm_hit.

Lemma t21_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 8 3 getHook_vm_code (M21_getHook_vm_hit tok sto account payload xs v) =
 run 7 4 getHook_vm_code (M22_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M21_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getHook_vm_hit.

Lemma t22_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Hnth : nth_error xs (Z.to_nat 1%Z) = Some v),
 run 7 4 getHook_vm_code (M22_getHook_vm_hit tok sto account payload xs v) =
 run 6 5 getHook_vm_code (M23_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Hnth.
 rewrite run_S.
 cbn [M22_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t22_getHook_vm_hit.

Lemma t23_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 6 5 getHook_vm_code (M23_getHook_vm_hit tok sto account payload xs v) =
 run 5 6 getHook_vm_code (M24_getHook_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M23_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getHook_vm_hit.

Lemma t24_getHook_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 5 6 getHook_vm_code (M24_getHook_vm_hit tok sto account payload xs v) = Done v.
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M24_getHook_vm_hit getHook_vm_init getHook_vm_code getHook_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getHook_vm_hit.

Theorem getHook_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (account_state_prefix ++ account) = None ->
 run 29 0 getHook_vm_code (getHook_vm_init tok sto account) = Thrown /\
 account_state_outcome tok 1 sto account = Fault.
Proof.
 intros tok sto account H. split.
 - exact (eq_trans (t0_getHook_vm_miss tok sto account) (eq_trans (t1_getHook_vm_miss tok sto account) (eq_trans (t2_getHook_vm_miss tok sto account) (eq_trans (t3_getHook_vm_miss tok sto account) (eq_trans (t4_getHook_vm_miss tok sto account) (eq_trans (t5_getHook_vm_miss tok sto account) (eq_trans (t6_getHook_vm_miss tok sto account) (eq_trans (t7_getHook_vm_miss tok sto account) (eq_trans (t8_getHook_vm_miss tok sto account) (eq_trans (t9_getHook_vm_miss tok sto account) (eq_trans (t10_getHook_vm_miss tok sto account) (eq_trans (t11_getHook_vm_miss tok sto account H) (eq_trans (t12_getHook_vm_miss tok sto account) (eq_trans (t13_getHook_vm_miss tok sto account) (eq_trans (t14_getHook_vm_miss tok sto account) (eq_trans (t15_getHook_vm_miss tok sto account) (eq_trans (t16_getHook_vm_miss tok sto account) (eq_trans (t17_getHook_vm_miss tok sto account) (t18_getHook_vm_miss tok sto account))))))))))))))))))).
 - apply getHook_source_miss with (sto := sto) (account := account)
     (tok := tok). exact H.
Qed.
Print Assumptions getHook_vm_miss.
Theorem getHook_vm_hit : forall (tok : nat -> GVal -> GVal) sto account payload xs v,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 1%nat = Some v ->
 run 29 0 getHook_vm_code (getHook_vm_init tok sto account) = Done v /\
 account_state_outcome tok 1 sto account = OK v.
Proof.
 intros tok sto account payload xs v H Htok Hnth. split.
 - exact (eq_trans (t0_getHook_vm_hit tok sto account payload xs v) (eq_trans (t1_getHook_vm_hit tok sto account payload xs v) (eq_trans (t2_getHook_vm_hit tok sto account payload xs v) (eq_trans (t3_getHook_vm_hit tok sto account payload xs v) (eq_trans (t4_getHook_vm_hit tok sto account payload xs v) (eq_trans (t5_getHook_vm_hit tok sto account payload xs v) (eq_trans (t6_getHook_vm_hit tok sto account payload xs v) (eq_trans (t7_getHook_vm_hit tok sto account payload xs v) (eq_trans (t8_getHook_vm_hit tok sto account payload xs v) (eq_trans (t9_getHook_vm_hit tok sto account payload xs v) (eq_trans (t10_getHook_vm_hit tok sto account payload xs v) (eq_trans (t11_getHook_vm_hit tok sto account payload xs v H) (eq_trans (t12_getHook_vm_hit tok sto account payload xs v) (eq_trans (t13_getHook_vm_hit tok sto account payload xs v) (eq_trans (t14_getHook_vm_hit tok sto account payload xs v) (eq_trans (t15_getHook_vm_hit tok sto account payload xs v) (eq_trans (t16_getHook_vm_hit tok sto account payload xs v) (eq_trans (t17_getHook_vm_hit tok sto account payload xs v) (eq_trans (t18_getHook_vm_hit tok sto account payload xs v Htok) (eq_trans (t19_getHook_vm_hit tok sto account payload xs v) (eq_trans (t20_getHook_vm_hit tok sto account payload xs v) (eq_trans (t21_getHook_vm_hit tok sto account payload xs v) (eq_trans (t22_getHook_vm_hit tok sto account payload xs v Hnth) (eq_trans (t23_getHook_vm_hit tok sto account payload xs v) (t24_getHook_vm_hit tok sto account payload xs v))))))))))))))))))))))))).
 - apply getHook_source_hit with (payload := payload) (xs := xs) (v := v); assumption.
Qed.
Print Assumptions getHook_vm_hit.
