From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition hasPendingHookUpdate_vm_program : list Ins :=
 [InitSlot 1 1; LdStatic 13; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; Push GNull; NotEqualIns; Jump 12; Ret].
Definition hasPendingHookUpdate_vm_code (pc : nat) : Ins := nth pc hasPendingHookUpdate_vm_program Unsupported.
Definition hasPendingHookUpdate_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 13 then Some (GBytes hasPendingHookUpdate_prefix) else None.
Definition hasPendingHookUpdate_vm_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 1) [GBytes account] hasPendingHookUpdate_vm_statics sto [] (fun _ _ => GNull).

Definition M0_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 hasPendingHookUpdate_vm_init sto account.

Definition M1_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingHookUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingHookUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingHookUpdate_prefix ++ account)]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingHookUpdate_prefix ++ account)]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (hasPendingHookUpdate_prefix ++ account)]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_hasPendingHookUpdate_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 15 0 hasPendingHookUpdate_vm_code (M0_hasPendingHookUpdate_vm_miss sto account) =
 run 14 1 hasPendingHookUpdate_vm_code (M1_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M0_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_hasPendingHookUpdate_vm_miss.

Lemma t1_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 14 1 hasPendingHookUpdate_vm_code (M1_hasPendingHookUpdate_vm_miss sto account) =
 run 13 2 hasPendingHookUpdate_vm_code (M2_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M1_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_hasPendingHookUpdate_vm_miss.

Lemma t2_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 13 2 hasPendingHookUpdate_vm_code (M2_hasPendingHookUpdate_vm_miss sto account) =
 run 12 3 hasPendingHookUpdate_vm_code (M3_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M2_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_hasPendingHookUpdate_vm_miss.

Lemma t3_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 12 3 hasPendingHookUpdate_vm_code (M3_hasPendingHookUpdate_vm_miss sto account) =
 run 11 4 hasPendingHookUpdate_vm_code (M4_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M3_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_hasPendingHookUpdate_vm_miss.

Lemma t4_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 11 4 hasPendingHookUpdate_vm_code (M4_hasPendingHookUpdate_vm_miss sto account) =
 run 10 5 hasPendingHookUpdate_vm_code (M5_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M4_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_hasPendingHookUpdate_vm_miss.

Lemma t5_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 10 5 hasPendingHookUpdate_vm_code (M5_hasPendingHookUpdate_vm_miss sto account) =
 run 9 6 hasPendingHookUpdate_vm_code (M6_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M5_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_hasPendingHookUpdate_vm_miss.

Lemma t6_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 9 6 hasPendingHookUpdate_vm_code (M6_hasPendingHookUpdate_vm_miss sto account) =
 run 8 7 hasPendingHookUpdate_vm_code (M7_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M6_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_hasPendingHookUpdate_vm_miss.

Lemma t7_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 8 7 hasPendingHookUpdate_vm_code (M7_hasPendingHookUpdate_vm_miss sto account) =
 run 7 8 hasPendingHookUpdate_vm_code (M8_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M7_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_hasPendingHookUpdate_vm_miss.

Lemma t8_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes) (Hstore : sto (hasPendingHookUpdate_prefix ++ account) = None),
 run 7 8 hasPendingHookUpdate_vm_code (M8_hasPendingHookUpdate_vm_miss sto account) =
 run 6 9 hasPendingHookUpdate_vm_code (M9_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account Hstore.
 rewrite run_S.
 cbn [M8_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_hasPendingHookUpdate_vm_miss.

Lemma t9_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 6 9 hasPendingHookUpdate_vm_code (M9_hasPendingHookUpdate_vm_miss sto account) =
 run 5 10 hasPendingHookUpdate_vm_code (M10_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M9_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_hasPendingHookUpdate_vm_miss.

Lemma t10_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 5 10 hasPendingHookUpdate_vm_code (M10_hasPendingHookUpdate_vm_miss sto account) =
 run 4 11 hasPendingHookUpdate_vm_code (M11_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M10_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_hasPendingHookUpdate_vm_miss.

Lemma t11_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 4 11 hasPendingHookUpdate_vm_code (M11_hasPendingHookUpdate_vm_miss sto account) =
 run 3 12 hasPendingHookUpdate_vm_code (M12_hasPendingHookUpdate_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M11_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_hasPendingHookUpdate_vm_miss.

Lemma t12_hasPendingHookUpdate_vm_miss : forall (sto : storage) (account : bytes),
 run 3 12 hasPendingHookUpdate_vm_code (M12_hasPendingHookUpdate_vm_miss sto account) = Done (GBool false).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M12_hasPendingHookUpdate_vm_miss hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_hasPendingHookUpdate_vm_miss.
Definition M0_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 hasPendingHookUpdate_vm_init sto account.

Definition M1_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasPendingHookUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingHookUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasPendingHookUpdate_prefix]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingHookUpdate_prefix ++ account)]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (hasPendingHookUpdate_prefix ++ account)]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (hasPendingHookUpdate_prefix ++ account)]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_hasPendingHookUpdate_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (hasPendingHookUpdate_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasPendingHookUpdate_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 15 0 hasPendingHookUpdate_vm_code (M0_hasPendingHookUpdate_vm_hit sto account payload) =
 run 14 1 hasPendingHookUpdate_vm_code (M1_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M0_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_hasPendingHookUpdate_vm_hit.

Lemma t1_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 14 1 hasPendingHookUpdate_vm_code (M1_hasPendingHookUpdate_vm_hit sto account payload) =
 run 13 2 hasPendingHookUpdate_vm_code (M2_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M1_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_hasPendingHookUpdate_vm_hit.

Lemma t2_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 13 2 hasPendingHookUpdate_vm_code (M2_hasPendingHookUpdate_vm_hit sto account payload) =
 run 12 3 hasPendingHookUpdate_vm_code (M3_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M2_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_hasPendingHookUpdate_vm_hit.

Lemma t3_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 12 3 hasPendingHookUpdate_vm_code (M3_hasPendingHookUpdate_vm_hit sto account payload) =
 run 11 4 hasPendingHookUpdate_vm_code (M4_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M3_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_hasPendingHookUpdate_vm_hit.

Lemma t4_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 11 4 hasPendingHookUpdate_vm_code (M4_hasPendingHookUpdate_vm_hit sto account payload) =
 run 10 5 hasPendingHookUpdate_vm_code (M5_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M4_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_hasPendingHookUpdate_vm_hit.

Lemma t5_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 10 5 hasPendingHookUpdate_vm_code (M5_hasPendingHookUpdate_vm_hit sto account payload) =
 run 9 6 hasPendingHookUpdate_vm_code (M6_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M5_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_hasPendingHookUpdate_vm_hit.

Lemma t6_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 9 6 hasPendingHookUpdate_vm_code (M6_hasPendingHookUpdate_vm_hit sto account payload) =
 run 8 7 hasPendingHookUpdate_vm_code (M7_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M6_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_hasPendingHookUpdate_vm_hit.

Lemma t7_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 8 7 hasPendingHookUpdate_vm_code (M7_hasPendingHookUpdate_vm_hit sto account payload) =
 run 7 8 hasPendingHookUpdate_vm_code (M8_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M7_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_hasPendingHookUpdate_vm_hit.

Lemma t8_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (Hstore : sto (hasPendingHookUpdate_prefix ++ account) = Some payload),
 run 7 8 hasPendingHookUpdate_vm_code (M8_hasPendingHookUpdate_vm_hit sto account payload) =
 run 6 9 hasPendingHookUpdate_vm_code (M9_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload Hstore.
 rewrite run_S.
 cbn [M8_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_hasPendingHookUpdate_vm_hit.

Lemma t9_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 6 9 hasPendingHookUpdate_vm_code (M9_hasPendingHookUpdate_vm_hit sto account payload) =
 run 5 10 hasPendingHookUpdate_vm_code (M10_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M9_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_hasPendingHookUpdate_vm_hit.

Lemma t10_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 5 10 hasPendingHookUpdate_vm_code (M10_hasPendingHookUpdate_vm_hit sto account payload) =
 run 4 11 hasPendingHookUpdate_vm_code (M11_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M10_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_hasPendingHookUpdate_vm_hit.

Lemma t11_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 4 11 hasPendingHookUpdate_vm_code (M11_hasPendingHookUpdate_vm_hit sto account payload) =
 run 3 12 hasPendingHookUpdate_vm_code (M12_hasPendingHookUpdate_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M11_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_hasPendingHookUpdate_vm_hit.

Lemma t12_hasPendingHookUpdate_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 3 12 hasPendingHookUpdate_vm_code (M12_hasPendingHookUpdate_vm_hit sto account payload) = Done (GBool true).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M12_hasPendingHookUpdate_vm_hit hasPendingHookUpdate_vm_init hasPendingHookUpdate_vm_code hasPendingHookUpdate_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_hasPendingHookUpdate_vm_hit.

Theorem hasPendingHookUpdate_vm_miss : forall sto account,
 sto (hasPendingHookUpdate_prefix ++ account) = None ->
 run 15 0 hasPendingHookUpdate_vm_code (hasPendingHookUpdate_vm_init sto account) = Done (GBool false) /\
 hasPendingHookUpdate_binding sto account = OK (GBool false).
Proof.
 intros sto account Hstore. split.
 - exact (eq_trans (t0_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t1_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t2_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t3_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t4_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t5_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t6_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t7_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t8_hasPendingHookUpdate_vm_miss sto account Hstore) (eq_trans (t9_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t10_hasPendingHookUpdate_vm_miss sto account) (eq_trans (t11_hasPendingHookUpdate_vm_miss sto account) (t12_hasPendingHookUpdate_vm_miss sto account))))))))))))).
 - apply hasPendingHookUpdate_source_miss. exact Hstore.
Qed.
Print Assumptions hasPendingHookUpdate_vm_miss.
Theorem hasPendingHookUpdate_vm_hit : forall sto account payload,
 sto (hasPendingHookUpdate_prefix ++ account) = Some payload ->
 run 15 0 hasPendingHookUpdate_vm_code (hasPendingHookUpdate_vm_init sto account) = Done (GBool true) /\
 hasPendingHookUpdate_binding sto account = OK (GBool true).
Proof.
 intros sto account payload Hstore. split.
 - exact (eq_trans (t0_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t1_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t2_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t3_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t4_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t5_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t6_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t7_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t8_hasPendingHookUpdate_vm_hit sto account payload Hstore) (eq_trans (t9_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t10_hasPendingHookUpdate_vm_hit sto account payload) (eq_trans (t11_hasPendingHookUpdate_vm_hit sto account payload) (t12_hasPendingHookUpdate_vm_hit sto account payload))))))))))))).
 - apply hasPendingHookUpdate_source_hit with (payload := payload). exact Hstore.
Qed.
Print Assumptions hasPendingHookUpdate_vm_hit.
