From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getMarketEscrowOwnerCancelTime_vm_program : list Ins :=
 [InitSlot 1 1; LdArg; Call 22; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 10; Push (GInt 0); Jump 20; LdLoc 0; Dup; IsNull; JumpIfNot 17; Drop; Push (GInt 0); Jump 18; Convert 33; LdStatic 37; AddIns; Jump 21; Ret; InitSlot 1 1; LdStatic 32; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; Jump 32; Ret].
Definition getMarketEscrowOwnerCancelTime_vm_code (pc : nat) : Ins := nth pc getMarketEscrowOwnerCancelTime_vm_program Unsupported.
Definition getMarketEscrowOwnerCancelTime_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 32 then Some (GBytes getMarketEscrowOwnerCancelTime_prefix)
          else if Nat.eqb i 37 then Some (GInt 604800000%Z) else None.
Definition getMarketEscrowOwnerCancelTime_vm_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 1) [GBytes account] getMarketEscrowOwnerCancelTime_vm_statics sto [] (fun _ _ => GNull).

Definition M0_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 getMarketEscrowOwnerCancelTime_vm_init sto account.

Definition M1_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getMarketEscrowOwnerCancelTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getMarketEscrowOwnerCancelTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getMarketEscrowOwnerCancelTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account); GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account); GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account); GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M19_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M20_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M21_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M22_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M23_getMarketEscrowOwnerCancelTime_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 35 0 getMarketEscrowOwnerCancelTime_vm_code (M0_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 34 1 getMarketEscrowOwnerCancelTime_vm_code (M1_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M0_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t1_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 34 1 getMarketEscrowOwnerCancelTime_vm_code (M1_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 33 2 getMarketEscrowOwnerCancelTime_vm_code (M2_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M1_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t2_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 33 2 getMarketEscrowOwnerCancelTime_vm_code (M2_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 32 22 getMarketEscrowOwnerCancelTime_vm_code (M3_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M2_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t3_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 32 22 getMarketEscrowOwnerCancelTime_vm_code (M3_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 31 23 getMarketEscrowOwnerCancelTime_vm_code (M4_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M3_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t4_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 31 23 getMarketEscrowOwnerCancelTime_vm_code (M4_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 30 24 getMarketEscrowOwnerCancelTime_vm_code (M5_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M4_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t5_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 30 24 getMarketEscrowOwnerCancelTime_vm_code (M5_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 29 25 getMarketEscrowOwnerCancelTime_vm_code (M6_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M5_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t6_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 29 25 getMarketEscrowOwnerCancelTime_vm_code (M6_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 28 26 getMarketEscrowOwnerCancelTime_vm_code (M7_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M6_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t7_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 28 26 getMarketEscrowOwnerCancelTime_vm_code (M7_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 27 27 getMarketEscrowOwnerCancelTime_vm_code (M8_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M7_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t8_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 27 27 getMarketEscrowOwnerCancelTime_vm_code (M8_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 26 28 getMarketEscrowOwnerCancelTime_vm_code (M9_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M8_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t9_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 26 28 getMarketEscrowOwnerCancelTime_vm_code (M9_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 25 29 getMarketEscrowOwnerCancelTime_vm_code (M10_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M9_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t10_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 25 29 getMarketEscrowOwnerCancelTime_vm_code (M10_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 24 30 getMarketEscrowOwnerCancelTime_vm_code (M11_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M10_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t11_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes) (Hstore : sto (getMarketEscrowOwnerCancelTime_prefix ++ account) = None),
 run 24 30 getMarketEscrowOwnerCancelTime_vm_code (M11_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 23 31 getMarketEscrowOwnerCancelTime_vm_code (M12_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account Hstore.
 rewrite run_S.
 cbn [M11_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t11_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t12_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 23 31 getMarketEscrowOwnerCancelTime_vm_code (M12_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 22 32 getMarketEscrowOwnerCancelTime_vm_code (M13_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M12_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t13_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 22 32 getMarketEscrowOwnerCancelTime_vm_code (M13_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 21 3 getMarketEscrowOwnerCancelTime_vm_code (M14_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M13_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t14_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 21 3 getMarketEscrowOwnerCancelTime_vm_code (M14_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 20 4 getMarketEscrowOwnerCancelTime_vm_code (M15_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M14_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t15_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 20 4 getMarketEscrowOwnerCancelTime_vm_code (M15_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 19 5 getMarketEscrowOwnerCancelTime_vm_code (M16_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M15_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t16_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 19 5 getMarketEscrowOwnerCancelTime_vm_code (M16_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 18 6 getMarketEscrowOwnerCancelTime_vm_code (M17_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M16_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t17_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 18 6 getMarketEscrowOwnerCancelTime_vm_code (M17_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 17 7 getMarketEscrowOwnerCancelTime_vm_code (M18_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M17_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t18_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 17 7 getMarketEscrowOwnerCancelTime_vm_code (M18_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 16 8 getMarketEscrowOwnerCancelTime_vm_code (M19_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M18_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t19_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 16 8 getMarketEscrowOwnerCancelTime_vm_code (M19_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 15 9 getMarketEscrowOwnerCancelTime_vm_code (M20_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M19_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t20_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 15 9 getMarketEscrowOwnerCancelTime_vm_code (M20_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 14 20 getMarketEscrowOwnerCancelTime_vm_code (M21_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M20_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t21_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 14 20 getMarketEscrowOwnerCancelTime_vm_code (M21_getMarketEscrowOwnerCancelTime_vm_miss sto account) =
 run 13 21 getMarketEscrowOwnerCancelTime_vm_code (M22_getMarketEscrowOwnerCancelTime_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M21_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getMarketEscrowOwnerCancelTime_vm_miss.

Lemma t22_getMarketEscrowOwnerCancelTime_vm_miss : forall (sto : storage) (account : bytes),
 run 13 21 getMarketEscrowOwnerCancelTime_vm_code (M22_getMarketEscrowOwnerCancelTime_vm_miss sto account) = Done (GInt 0%Z).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M22_getMarketEscrowOwnerCancelTime_vm_miss getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getMarketEscrowOwnerCancelTime_vm_miss.
Definition M0_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 getMarketEscrowOwnerCancelTime_vm_init sto account.

Definition M1_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes getMarketEscrowOwnerCancelTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getMarketEscrowOwnerCancelTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getMarketEscrowOwnerCancelTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account); GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account); GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account); GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (getMarketEscrowOwnerCancelTime_prefix ++ account)]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBool false; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M19_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M20_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M21_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes payload; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M22_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBool false; GBytes payload; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M23_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M24_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt value; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M25_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt 604800000%Z; GInt value; GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M26_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z); GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M27_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z); GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M28_getMarketEscrowOwnerCancelTime_vm_hit (sto : storage) (account : bytes) (payload : bytes) (value : Z) : Machine :=
 {| mstack := [GInt (value + 604800000%Z); GBytes account]; mlocals := [GBytes payload]; margs := [GBytes account];
    mstatics := getMarketEscrowOwnerCancelTime_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 35 0 getMarketEscrowOwnerCancelTime_vm_code (M0_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 34 1 getMarketEscrowOwnerCancelTime_vm_code (M1_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M0_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t1_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 34 1 getMarketEscrowOwnerCancelTime_vm_code (M1_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 33 2 getMarketEscrowOwnerCancelTime_vm_code (M2_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M1_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t2_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 33 2 getMarketEscrowOwnerCancelTime_vm_code (M2_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 32 22 getMarketEscrowOwnerCancelTime_vm_code (M3_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M2_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t3_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 32 22 getMarketEscrowOwnerCancelTime_vm_code (M3_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 31 23 getMarketEscrowOwnerCancelTime_vm_code (M4_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M3_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t4_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 31 23 getMarketEscrowOwnerCancelTime_vm_code (M4_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 30 24 getMarketEscrowOwnerCancelTime_vm_code (M5_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M4_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t5_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 30 24 getMarketEscrowOwnerCancelTime_vm_code (M5_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 29 25 getMarketEscrowOwnerCancelTime_vm_code (M6_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M5_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t6_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 29 25 getMarketEscrowOwnerCancelTime_vm_code (M6_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 28 26 getMarketEscrowOwnerCancelTime_vm_code (M7_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M6_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t7_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 28 26 getMarketEscrowOwnerCancelTime_vm_code (M7_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 27 27 getMarketEscrowOwnerCancelTime_vm_code (M8_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M7_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t8_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 27 27 getMarketEscrowOwnerCancelTime_vm_code (M8_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 26 28 getMarketEscrowOwnerCancelTime_vm_code (M9_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M8_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t9_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 26 28 getMarketEscrowOwnerCancelTime_vm_code (M9_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 25 29 getMarketEscrowOwnerCancelTime_vm_code (M10_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M9_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t10_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 25 29 getMarketEscrowOwnerCancelTime_vm_code (M10_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 24 30 getMarketEscrowOwnerCancelTime_vm_code (M11_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M10_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t11_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z) (Hstore : sto (getMarketEscrowOwnerCancelTime_prefix ++ account) = Some payload),
 run 24 30 getMarketEscrowOwnerCancelTime_vm_code (M11_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 23 31 getMarketEscrowOwnerCancelTime_vm_code (M12_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value Hstore.
 rewrite run_S.
 cbn [M11_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t11_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t12_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 23 31 getMarketEscrowOwnerCancelTime_vm_code (M12_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 22 32 getMarketEscrowOwnerCancelTime_vm_code (M13_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M12_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t13_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 22 32 getMarketEscrowOwnerCancelTime_vm_code (M13_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 21 3 getMarketEscrowOwnerCancelTime_vm_code (M14_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M13_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t14_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 21 3 getMarketEscrowOwnerCancelTime_vm_code (M14_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 20 4 getMarketEscrowOwnerCancelTime_vm_code (M15_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M14_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t15_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 20 4 getMarketEscrowOwnerCancelTime_vm_code (M15_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 19 5 getMarketEscrowOwnerCancelTime_vm_code (M16_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M15_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t16_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 19 5 getMarketEscrowOwnerCancelTime_vm_code (M16_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 18 6 getMarketEscrowOwnerCancelTime_vm_code (M17_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M16_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t17_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 18 6 getMarketEscrowOwnerCancelTime_vm_code (M17_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 17 7 getMarketEscrowOwnerCancelTime_vm_code (M18_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M17_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t18_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 17 7 getMarketEscrowOwnerCancelTime_vm_code (M18_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 16 10 getMarketEscrowOwnerCancelTime_vm_code (M19_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M18_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t19_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 16 10 getMarketEscrowOwnerCancelTime_vm_code (M19_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 15 11 getMarketEscrowOwnerCancelTime_vm_code (M20_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M19_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t20_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 15 11 getMarketEscrowOwnerCancelTime_vm_code (M20_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 14 12 getMarketEscrowOwnerCancelTime_vm_code (M21_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M20_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t21_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 14 12 getMarketEscrowOwnerCancelTime_vm_code (M21_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 13 13 getMarketEscrowOwnerCancelTime_vm_code (M22_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M21_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t22_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 13 13 getMarketEscrowOwnerCancelTime_vm_code (M22_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 12 17 getMarketEscrowOwnerCancelTime_vm_code (M23_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M22_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t23_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z) (Hdecode : decode_integer payload = OK (GInt value)),
 run 12 17 getMarketEscrowOwnerCancelTime_vm_code (M23_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 11 18 getMarketEscrowOwnerCancelTime_vm_code (M24_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value Hdecode.
 rewrite run_S.
 cbn [M23_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hdecode.
 reflexivity.
Qed.
Print Assumptions t23_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t24_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 11 18 getMarketEscrowOwnerCancelTime_vm_code (M24_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 10 19 getMarketEscrowOwnerCancelTime_vm_code (M25_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M24_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t25_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z) (Hsum : integer_fitsb (value + 604800000) = true),
 run 10 19 getMarketEscrowOwnerCancelTime_vm_code (M25_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 9 20 getMarketEscrowOwnerCancelTime_vm_code (M26_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value Hsum.
 rewrite run_S.
 cbn [M25_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hsum.
 reflexivity.
Qed.
Print Assumptions t25_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t26_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 9 20 getMarketEscrowOwnerCancelTime_vm_code (M26_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) =
 run 8 21 getMarketEscrowOwnerCancelTime_vm_code (M27_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M26_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t26_getMarketEscrowOwnerCancelTime_vm_hit.

Lemma t27_getMarketEscrowOwnerCancelTime_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (value : Z),
 run 8 21 getMarketEscrowOwnerCancelTime_vm_code (M27_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) = Done (GInt (value + 604800000%Z)).
Proof.
 intros sto account payload value.
 rewrite run_S.
 cbn [M27_getMarketEscrowOwnerCancelTime_vm_hit getMarketEscrowOwnerCancelTime_vm_init getMarketEscrowOwnerCancelTime_vm_code getMarketEscrowOwnerCancelTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t27_getMarketEscrowOwnerCancelTime_vm_hit.

Theorem getMarketEscrowOwnerCancelTime_vm_miss : forall sto account,
 sto (getMarketEscrowOwnerCancelTime_prefix ++ account) = None ->
 run 35 0 getMarketEscrowOwnerCancelTime_vm_code (getMarketEscrowOwnerCancelTime_vm_init sto account) = Done (GInt 0%Z) /\
 getMarketEscrowOwnerCancelTime_binding sto account = OK (GInt 0%Z).
Proof.
 intros sto account Hstore. split.
 - exact (eq_trans (t0_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t1_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t2_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t3_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t4_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t5_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t6_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t7_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t8_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t9_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t10_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t11_getMarketEscrowOwnerCancelTime_vm_miss sto account Hstore) (eq_trans (t12_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t13_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t14_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t15_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t16_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t17_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t18_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t19_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t20_getMarketEscrowOwnerCancelTime_vm_miss sto account) (eq_trans (t21_getMarketEscrowOwnerCancelTime_vm_miss sto account) (t22_getMarketEscrowOwnerCancelTime_vm_miss sto account))))))))))))))))))))))).
 - exact (getMarketEscrowOwnerCancelTime_source_miss sto account Hstore).
Qed.
Print Assumptions getMarketEscrowOwnerCancelTime_vm_miss.
Theorem getMarketEscrowOwnerCancelTime_vm_hit : forall sto account payload value,
 sto (getMarketEscrowOwnerCancelTime_prefix ++ account) = Some payload ->
 decode_integer payload = OK (GInt value) ->
 integer_fitsb (value + 604800000%Z) = true ->
 run 35 0 getMarketEscrowOwnerCancelTime_vm_code (getMarketEscrowOwnerCancelTime_vm_init sto account) = Done (GInt (value + 604800000%Z)) /\
 getMarketEscrowOwnerCancelTime_binding sto account = OK (GInt (value + 604800000%Z)).
Proof.
 intros sto account payload value Hstore Hdecode Hsum. split.
 - exact (eq_trans (t0_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t1_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t2_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t3_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t4_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t5_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t6_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t7_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t8_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t9_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t10_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t11_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value Hstore) (eq_trans (t12_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t13_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t14_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t15_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t16_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t17_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t18_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t19_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t20_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t21_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t22_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t23_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value Hdecode) (eq_trans (t24_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (eq_trans (t25_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value Hsum) (eq_trans (t26_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value) (t27_getMarketEscrowOwnerCancelTime_vm_hit sto account payload value)))))))))))))))))))))))))))).
 - exact (getMarketEscrowOwnerCancelTime_source_hit sto account payload value Hstore Hdecode Hsum).
Qed.
Print Assumptions getMarketEscrowOwnerCancelTime_vm_hit.
