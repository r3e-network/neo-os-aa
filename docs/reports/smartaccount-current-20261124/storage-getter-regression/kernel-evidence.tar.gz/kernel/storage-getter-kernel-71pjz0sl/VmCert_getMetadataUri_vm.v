From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getMetadataUri_vm_program : list Ins :=
 [InitSlot 2 1; LdStatic 31; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 16; Push (GBytes []); Jump 17; LdLoc 1; Jump 18; Ret].
Definition getMetadataUri_vm_code (pc : nat) : Ins := nth pc getMetadataUri_vm_program Unsupported.
Definition getMetadataUri_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 31 then Some (GBytes getMetadataUri_prefix) else None.
Definition getMetadataUri_vm_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account] getMetadataUri_vm_statics sto [] (fun _ _ => GNull).

Definition M0_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 getMetadataUri_vm_init sto account.

Definition M1_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getMetadataUri_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getMetadataUri_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getMetadataUri_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getMetadataUri_prefix ++ account)]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getMetadataUri_prefix ++ account)]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getMetadataUri_prefix ++ account)]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getMetadataUri_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes []]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 21 0 getMetadataUri_vm_code (M0_getMetadataUri_vm_miss sto account) =
 run 20 1 getMetadataUri_vm_code (M1_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M0_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getMetadataUri_vm_miss.

Lemma t1_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 20 1 getMetadataUri_vm_code (M1_getMetadataUri_vm_miss sto account) =
 run 19 2 getMetadataUri_vm_code (M2_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M1_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getMetadataUri_vm_miss.

Lemma t2_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 19 2 getMetadataUri_vm_code (M2_getMetadataUri_vm_miss sto account) =
 run 18 3 getMetadataUri_vm_code (M3_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M2_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getMetadataUri_vm_miss.

Lemma t3_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 18 3 getMetadataUri_vm_code (M3_getMetadataUri_vm_miss sto account) =
 run 17 4 getMetadataUri_vm_code (M4_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M3_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getMetadataUri_vm_miss.

Lemma t4_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 17 4 getMetadataUri_vm_code (M4_getMetadataUri_vm_miss sto account) =
 run 16 5 getMetadataUri_vm_code (M5_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M4_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getMetadataUri_vm_miss.

Lemma t5_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 16 5 getMetadataUri_vm_code (M5_getMetadataUri_vm_miss sto account) =
 run 15 6 getMetadataUri_vm_code (M6_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M5_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getMetadataUri_vm_miss.

Lemma t6_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 15 6 getMetadataUri_vm_code (M6_getMetadataUri_vm_miss sto account) =
 run 14 7 getMetadataUri_vm_code (M7_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M6_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getMetadataUri_vm_miss.

Lemma t7_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 14 7 getMetadataUri_vm_code (M7_getMetadataUri_vm_miss sto account) =
 run 13 8 getMetadataUri_vm_code (M8_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M7_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getMetadataUri_vm_miss.

Lemma t8_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes) (Hstore : sto (getMetadataUri_prefix ++ account) = None),
 run 13 8 getMetadataUri_vm_code (M8_getMetadataUri_vm_miss sto account) =
 run 12 9 getMetadataUri_vm_code (M9_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account Hstore.
 rewrite run_S.
 cbn [M8_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getMetadataUri_vm_miss.

Lemma t9_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 12 9 getMetadataUri_vm_code (M9_getMetadataUri_vm_miss sto account) =
 run 11 10 getMetadataUri_vm_code (M10_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M9_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getMetadataUri_vm_miss.

Lemma t10_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 11 10 getMetadataUri_vm_code (M10_getMetadataUri_vm_miss sto account) =
 run 10 11 getMetadataUri_vm_code (M11_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M10_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getMetadataUri_vm_miss.

Lemma t11_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 10 11 getMetadataUri_vm_code (M11_getMetadataUri_vm_miss sto account) =
 run 9 12 getMetadataUri_vm_code (M12_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M11_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getMetadataUri_vm_miss.

Lemma t12_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 9 12 getMetadataUri_vm_code (M12_getMetadataUri_vm_miss sto account) =
 run 8 13 getMetadataUri_vm_code (M13_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M12_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getMetadataUri_vm_miss.

Lemma t13_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 8 13 getMetadataUri_vm_code (M13_getMetadataUri_vm_miss sto account) =
 run 7 14 getMetadataUri_vm_code (M14_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M13_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getMetadataUri_vm_miss.

Lemma t14_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 7 14 getMetadataUri_vm_code (M14_getMetadataUri_vm_miss sto account) =
 run 6 15 getMetadataUri_vm_code (M15_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M14_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getMetadataUri_vm_miss.

Lemma t15_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 6 15 getMetadataUri_vm_code (M15_getMetadataUri_vm_miss sto account) =
 run 5 17 getMetadataUri_vm_code (M16_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M15_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getMetadataUri_vm_miss.

Lemma t16_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 5 17 getMetadataUri_vm_code (M16_getMetadataUri_vm_miss sto account) =
 run 4 18 getMetadataUri_vm_code (M17_getMetadataUri_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M16_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getMetadataUri_vm_miss.

Lemma t17_getMetadataUri_vm_miss : forall (sto : storage) (account : bytes),
 run 4 18 getMetadataUri_vm_code (M17_getMetadataUri_vm_miss sto account) = Done (GBytes []).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M17_getMetadataUri_vm_miss getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getMetadataUri_vm_miss.
Definition M0_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 getMetadataUri_vm_init sto account.

Definition M1_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes getMetadataUri_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getMetadataUri_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getMetadataUri_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (getMetadataUri_prefix ++ account)]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (getMetadataUri_prefix ++ account)]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getMetadataUri_prefix ++ account)]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMetadataUri_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getMetadataUri_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getMetadataUri_vm_hitraw (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getMetadataUri_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getMetadataUri_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 21 0 getMetadataUri_vm_code (M0_getMetadataUri_vm_hitraw sto account payload) =
 run 20 1 getMetadataUri_vm_code (M1_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M0_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getMetadataUri_vm_hitraw.

Lemma t1_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 20 1 getMetadataUri_vm_code (M1_getMetadataUri_vm_hitraw sto account payload) =
 run 19 2 getMetadataUri_vm_code (M2_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M1_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getMetadataUri_vm_hitraw.

Lemma t2_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 19 2 getMetadataUri_vm_code (M2_getMetadataUri_vm_hitraw sto account payload) =
 run 18 3 getMetadataUri_vm_code (M3_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M2_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getMetadataUri_vm_hitraw.

Lemma t3_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 18 3 getMetadataUri_vm_code (M3_getMetadataUri_vm_hitraw sto account payload) =
 run 17 4 getMetadataUri_vm_code (M4_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M3_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getMetadataUri_vm_hitraw.

Lemma t4_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 17 4 getMetadataUri_vm_code (M4_getMetadataUri_vm_hitraw sto account payload) =
 run 16 5 getMetadataUri_vm_code (M5_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M4_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getMetadataUri_vm_hitraw.

Lemma t5_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 16 5 getMetadataUri_vm_code (M5_getMetadataUri_vm_hitraw sto account payload) =
 run 15 6 getMetadataUri_vm_code (M6_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M5_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getMetadataUri_vm_hitraw.

Lemma t6_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 15 6 getMetadataUri_vm_code (M6_getMetadataUri_vm_hitraw sto account payload) =
 run 14 7 getMetadataUri_vm_code (M7_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M6_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getMetadataUri_vm_hitraw.

Lemma t7_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 14 7 getMetadataUri_vm_code (M7_getMetadataUri_vm_hitraw sto account payload) =
 run 13 8 getMetadataUri_vm_code (M8_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M7_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getMetadataUri_vm_hitraw.

Lemma t8_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes) (Hstore : sto (getMetadataUri_prefix ++ account) = Some payload),
 run 13 8 getMetadataUri_vm_code (M8_getMetadataUri_vm_hitraw sto account payload) =
 run 12 9 getMetadataUri_vm_code (M9_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload Hstore.
 rewrite run_S.
 cbn [M8_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getMetadataUri_vm_hitraw.

Lemma t9_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 12 9 getMetadataUri_vm_code (M9_getMetadataUri_vm_hitraw sto account payload) =
 run 11 10 getMetadataUri_vm_code (M10_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M9_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getMetadataUri_vm_hitraw.

Lemma t10_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 11 10 getMetadataUri_vm_code (M10_getMetadataUri_vm_hitraw sto account payload) =
 run 10 11 getMetadataUri_vm_code (M11_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M10_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getMetadataUri_vm_hitraw.

Lemma t11_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 10 11 getMetadataUri_vm_code (M11_getMetadataUri_vm_hitraw sto account payload) =
 run 9 12 getMetadataUri_vm_code (M12_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M11_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getMetadataUri_vm_hitraw.

Lemma t12_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 9 12 getMetadataUri_vm_code (M12_getMetadataUri_vm_hitraw sto account payload) =
 run 8 13 getMetadataUri_vm_code (M13_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M12_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getMetadataUri_vm_hitraw.

Lemma t13_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 8 13 getMetadataUri_vm_code (M13_getMetadataUri_vm_hitraw sto account payload) =
 run 7 16 getMetadataUri_vm_code (M14_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M13_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getMetadataUri_vm_hitraw.

Lemma t14_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 7 16 getMetadataUri_vm_code (M14_getMetadataUri_vm_hitraw sto account payload) =
 run 6 17 getMetadataUri_vm_code (M15_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M14_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getMetadataUri_vm_hitraw.

Lemma t15_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 6 17 getMetadataUri_vm_code (M15_getMetadataUri_vm_hitraw sto account payload) =
 run 5 18 getMetadataUri_vm_code (M16_getMetadataUri_vm_hitraw sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M15_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getMetadataUri_vm_hitraw.

Lemma t16_getMetadataUri_vm_hitraw : forall (sto : storage) (account : bytes) (payload : bytes),
 run 5 18 getMetadataUri_vm_code (M16_getMetadataUri_vm_hitraw sto account payload) = Done (GBytes payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M16_getMetadataUri_vm_hitraw getMetadataUri_vm_init getMetadataUri_vm_code getMetadataUri_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getMetadataUri_vm_hitraw.

Theorem getMetadataUri_vm_miss : forall sto account,
 sto (getMetadataUri_prefix ++ account) = None ->
 run 21 0 getMetadataUri_vm_code (getMetadataUri_vm_init sto account) = Done (GBytes []) /\
 getter_outcome getMetadataUri_prefix (GBytes []) getMetadataUri_decode sto account = OK (GBytes []).
Proof.
 intros sto account Hstore. split.
 - exact (eq_trans (t0_getMetadataUri_vm_miss sto account) (eq_trans (t1_getMetadataUri_vm_miss sto account) (eq_trans (t2_getMetadataUri_vm_miss sto account) (eq_trans (t3_getMetadataUri_vm_miss sto account) (eq_trans (t4_getMetadataUri_vm_miss sto account) (eq_trans (t5_getMetadataUri_vm_miss sto account) (eq_trans (t6_getMetadataUri_vm_miss sto account) (eq_trans (t7_getMetadataUri_vm_miss sto account) (eq_trans (t8_getMetadataUri_vm_miss sto account Hstore) (eq_trans (t9_getMetadataUri_vm_miss sto account) (eq_trans (t10_getMetadataUri_vm_miss sto account) (eq_trans (t11_getMetadataUri_vm_miss sto account) (eq_trans (t12_getMetadataUri_vm_miss sto account) (eq_trans (t13_getMetadataUri_vm_miss sto account) (eq_trans (t14_getMetadataUri_vm_miss sto account) (eq_trans (t15_getMetadataUri_vm_miss sto account) (eq_trans (t16_getMetadataUri_vm_miss sto account) (t17_getMetadataUri_vm_miss sto account)))))))))))))))))).
 - unfold getter_outcome. rewrite Hstore. reflexivity.
Qed.
Print Assumptions getMetadataUri_vm_miss.
Theorem getMetadataUri_vm_hit : forall sto account payload,
 sto (getMetadataUri_prefix ++ account) = Some payload ->
 run 21 0 getMetadataUri_vm_code (getMetadataUri_vm_init sto account) = Done (GBytes payload) /\
 getter_outcome getMetadataUri_prefix (GBytes []) getMetadataUri_decode sto account = OK (GBytes payload).
Proof.
 intros sto account payload Hstore. split.
 - exact (eq_trans (t0_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t1_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t2_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t3_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t4_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t5_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t6_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t7_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t8_getMetadataUri_vm_hitraw sto account payload Hstore) (eq_trans (t9_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t10_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t11_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t12_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t13_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t14_getMetadataUri_vm_hitraw sto account payload) (eq_trans (t15_getMetadataUri_vm_hitraw sto account payload) (t16_getMetadataUri_vm_hitraw sto account payload))))))))))))))))).
 - unfold getter_outcome, getMetadataUri_decode.
   rewrite Hstore. reflexivity.
Qed.
Print Assumptions getMetadataUri_vm_hit.
