From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getBackupOwner_vm_program : list Ins :=
 [InitSlot 0 1; LdArg; Call 7; Push (GInt 2); PickItem; Jump 6; Ret; InitSlot 2 1; LdStatic 8; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; NotEqualIns; JumpIf 23; Push (GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]); AbortMsg; LdLoc 1; CallToken 4; Jump 26; Ret].
Definition getBackupOwner_vm_code (pc : nat) : Ins := nth pc getBackupOwner_vm_program Unsupported.
Definition getBackupOwner_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 8 then Some (GBytes account_state_prefix) else None.
Definition getBackupOwner_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account] getBackupOwner_vm_statics sto [] tok.

Definition M0_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 getBackupOwner_vm_init tok sto account.

Definition M1_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M4_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M5_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M6_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M7_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M8_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M9_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M10_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M11_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M12_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M13_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M14_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M15_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M16_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M17_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M18_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M19_getBackupOwner_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [65%nat;99%nat;99%nat;111%nat;117%nat;110%nat;116%nat;32%nat;110%nat;111%nat;116%nat;32%nat;102%nat;111%nat;117%nat;110%nat;100%nat]; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Lemma t0_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 29 0 getBackupOwner_vm_code (M0_getBackupOwner_vm_miss tok sto account) =
 run 28 1 getBackupOwner_vm_code (M1_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getBackupOwner_vm_miss.

Lemma t1_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 28 1 getBackupOwner_vm_code (M1_getBackupOwner_vm_miss tok sto account) =
 run 27 2 getBackupOwner_vm_code (M2_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getBackupOwner_vm_miss.

Lemma t2_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 2 getBackupOwner_vm_code (M2_getBackupOwner_vm_miss tok sto account) =
 run 26 7 getBackupOwner_vm_code (M3_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getBackupOwner_vm_miss.

Lemma t3_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 7 getBackupOwner_vm_code (M3_getBackupOwner_vm_miss tok sto account) =
 run 25 8 getBackupOwner_vm_code (M4_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getBackupOwner_vm_miss.

Lemma t4_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 8 getBackupOwner_vm_code (M4_getBackupOwner_vm_miss tok sto account) =
 run 24 9 getBackupOwner_vm_code (M5_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getBackupOwner_vm_miss.

Lemma t5_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 9 getBackupOwner_vm_code (M5_getBackupOwner_vm_miss tok sto account) =
 run 23 10 getBackupOwner_vm_code (M6_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getBackupOwner_vm_miss.

Lemma t6_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 10 getBackupOwner_vm_code (M6_getBackupOwner_vm_miss tok sto account) =
 run 22 11 getBackupOwner_vm_code (M7_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getBackupOwner_vm_miss.

Lemma t7_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 11 getBackupOwner_vm_code (M7_getBackupOwner_vm_miss tok sto account) =
 run 21 12 getBackupOwner_vm_code (M8_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getBackupOwner_vm_miss.

Lemma t8_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 12 getBackupOwner_vm_code (M8_getBackupOwner_vm_miss tok sto account) =
 run 20 13 getBackupOwner_vm_code (M9_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M8_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getBackupOwner_vm_miss.

Lemma t9_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 20 13 getBackupOwner_vm_code (M9_getBackupOwner_vm_miss tok sto account) =
 run 19 14 getBackupOwner_vm_code (M10_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getBackupOwner_vm_miss.

Lemma t10_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 14 getBackupOwner_vm_code (M10_getBackupOwner_vm_miss tok sto account) =
 run 18 15 getBackupOwner_vm_code (M11_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getBackupOwner_vm_miss.

Lemma t11_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (H : sto (account_state_prefix ++ account) = None),
 run 18 15 getBackupOwner_vm_code (M11_getBackupOwner_vm_miss tok sto account) =
 run 17 16 getBackupOwner_vm_code (M12_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account H.
 rewrite run_S.
 cbn [M11_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite H.
 reflexivity.
Qed.
Print Assumptions t11_getBackupOwner_vm_miss.

Lemma t12_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 16 getBackupOwner_vm_code (M12_getBackupOwner_vm_miss tok sto account) =
 run 16 17 getBackupOwner_vm_code (M13_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M12_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getBackupOwner_vm_miss.

Lemma t13_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 17 getBackupOwner_vm_code (M13_getBackupOwner_vm_miss tok sto account) =
 run 15 18 getBackupOwner_vm_code (M14_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getBackupOwner_vm_miss.

Lemma t14_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 18 getBackupOwner_vm_code (M14_getBackupOwner_vm_miss tok sto account) =
 run 14 19 getBackupOwner_vm_code (M15_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getBackupOwner_vm_miss.

Lemma t15_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 19 getBackupOwner_vm_code (M15_getBackupOwner_vm_miss tok sto account) =
 run 13 20 getBackupOwner_vm_code (M16_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getBackupOwner_vm_miss.

Lemma t16_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 20 getBackupOwner_vm_code (M16_getBackupOwner_vm_miss tok sto account) =
 run 12 21 getBackupOwner_vm_code (M17_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getBackupOwner_vm_miss.

Lemma t17_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 21 getBackupOwner_vm_code (M17_getBackupOwner_vm_miss tok sto account) =
 run 11 22 getBackupOwner_vm_code (M18_getBackupOwner_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M17_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getBackupOwner_vm_miss.

Lemma t18_getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 11 22 getBackupOwner_vm_code (M18_getBackupOwner_vm_miss tok sto account) = Thrown.
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M18_getBackupOwner_vm_miss getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getBackupOwner_vm_miss.
Definition M0_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 getBackupOwner_vm_init tok sto account.

Definition M1_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M4_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M5_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M6_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M7_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account; GBytes account_state_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M8_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M9_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M10_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M11_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (account_state_prefix ++ account); GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M12_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M13_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M14_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M15_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M16_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBool true; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M17_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M18_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M19_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M20_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := tok |}.

Definition M21_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [GInt 2%Z; GArray xs; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getBackupOwner_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) : Machine :=
 {| mstack := [v; GBytes account]; mlocals := [GBytes (account_state_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getBackupOwner_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 29 0 getBackupOwner_vm_code (M0_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 28 1 getBackupOwner_vm_code (M1_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M0_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getBackupOwner_vm_hit.

Lemma t1_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 28 1 getBackupOwner_vm_code (M1_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 27 2 getBackupOwner_vm_code (M2_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M1_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getBackupOwner_vm_hit.

Lemma t2_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 27 2 getBackupOwner_vm_code (M2_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 26 7 getBackupOwner_vm_code (M3_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M2_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getBackupOwner_vm_hit.

Lemma t3_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 26 7 getBackupOwner_vm_code (M3_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 25 8 getBackupOwner_vm_code (M4_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M3_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getBackupOwner_vm_hit.

Lemma t4_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 25 8 getBackupOwner_vm_code (M4_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 24 9 getBackupOwner_vm_code (M5_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M4_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getBackupOwner_vm_hit.

Lemma t5_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 24 9 getBackupOwner_vm_code (M5_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 23 10 getBackupOwner_vm_code (M6_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M5_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getBackupOwner_vm_hit.

Lemma t6_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 23 10 getBackupOwner_vm_code (M6_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 22 11 getBackupOwner_vm_code (M7_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M6_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getBackupOwner_vm_hit.

Lemma t7_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 22 11 getBackupOwner_vm_code (M7_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 21 12 getBackupOwner_vm_code (M8_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M7_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getBackupOwner_vm_hit.

Lemma t8_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 21 12 getBackupOwner_vm_code (M8_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 20 13 getBackupOwner_vm_code (M9_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M8_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getBackupOwner_vm_hit.

Lemma t9_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 20 13 getBackupOwner_vm_code (M9_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 19 14 getBackupOwner_vm_code (M10_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M9_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getBackupOwner_vm_hit.

Lemma t10_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 19 14 getBackupOwner_vm_code (M10_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 18 15 getBackupOwner_vm_code (M11_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M10_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getBackupOwner_vm_hit.

Lemma t11_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (H : sto (account_state_prefix ++ account) = Some payload),
 run 18 15 getBackupOwner_vm_code (M11_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 17 16 getBackupOwner_vm_code (M12_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v H.
 rewrite run_S.
 cbn [M11_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite H.
 reflexivity.
Qed.
Print Assumptions t11_getBackupOwner_vm_hit.

Lemma t12_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 17 16 getBackupOwner_vm_code (M12_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 16 17 getBackupOwner_vm_code (M13_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M12_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getBackupOwner_vm_hit.

Lemma t13_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 16 17 getBackupOwner_vm_code (M13_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 15 18 getBackupOwner_vm_code (M14_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M13_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getBackupOwner_vm_hit.

Lemma t14_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 15 18 getBackupOwner_vm_code (M14_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 14 19 getBackupOwner_vm_code (M15_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M14_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getBackupOwner_vm_hit.

Lemma t15_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 14 19 getBackupOwner_vm_code (M15_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 13 20 getBackupOwner_vm_code (M16_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M15_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getBackupOwner_vm_hit.

Lemma t16_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 13 20 getBackupOwner_vm_code (M16_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 12 23 getBackupOwner_vm_code (M17_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M16_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getBackupOwner_vm_hit.

Lemma t17_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 12 23 getBackupOwner_vm_code (M17_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 11 24 getBackupOwner_vm_code (M18_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M17_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getBackupOwner_vm_hit.

Lemma t18_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 11 24 getBackupOwner_vm_code (M18_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 10 25 getBackupOwner_vm_code (M19_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Htok.
 rewrite run_S.
 cbn [M18_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t18_getBackupOwner_vm_hit.

Lemma t19_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 10 25 getBackupOwner_vm_code (M19_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 9 26 getBackupOwner_vm_code (M20_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M19_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getBackupOwner_vm_hit.

Lemma t20_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 9 26 getBackupOwner_vm_code (M20_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 8 3 getBackupOwner_vm_code (M21_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M20_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getBackupOwner_vm_hit.

Lemma t21_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 8 3 getBackupOwner_vm_code (M21_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 7 4 getBackupOwner_vm_code (M22_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M21_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getBackupOwner_vm_hit.

Lemma t22_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal) (Hnth : nth_error xs (Z.to_nat 2%Z) = Some v),
 run 7 4 getBackupOwner_vm_code (M22_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 6 5 getBackupOwner_vm_code (M23_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v Hnth.
 rewrite run_S.
 cbn [M22_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t22_getBackupOwner_vm_hit.

Lemma t23_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 6 5 getBackupOwner_vm_code (M23_getBackupOwner_vm_hit tok sto account payload xs v) =
 run 5 6 getBackupOwner_vm_code (M24_getBackupOwner_vm_hit tok sto account payload xs v).
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M23_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getBackupOwner_vm_hit.

Lemma t24_getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (v : GVal),
 run 5 6 getBackupOwner_vm_code (M24_getBackupOwner_vm_hit tok sto account payload xs v) = Done v.
Proof.
 intros tok sto account payload xs v.
 rewrite run_S.
 cbn [M24_getBackupOwner_vm_hit getBackupOwner_vm_init getBackupOwner_vm_code getBackupOwner_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getBackupOwner_vm_hit.

Theorem getBackupOwner_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (account_state_prefix ++ account) = None ->
 run 29 0 getBackupOwner_vm_code (getBackupOwner_vm_init tok sto account) = Thrown /\
 account_state_outcome tok 2 sto account = Fault.
Proof.
 intros tok sto account H. split.
 - exact (eq_trans (t0_getBackupOwner_vm_miss tok sto account) (eq_trans (t1_getBackupOwner_vm_miss tok sto account) (eq_trans (t2_getBackupOwner_vm_miss tok sto account) (eq_trans (t3_getBackupOwner_vm_miss tok sto account) (eq_trans (t4_getBackupOwner_vm_miss tok sto account) (eq_trans (t5_getBackupOwner_vm_miss tok sto account) (eq_trans (t6_getBackupOwner_vm_miss tok sto account) (eq_trans (t7_getBackupOwner_vm_miss tok sto account) (eq_trans (t8_getBackupOwner_vm_miss tok sto account) (eq_trans (t9_getBackupOwner_vm_miss tok sto account) (eq_trans (t10_getBackupOwner_vm_miss tok sto account) (eq_trans (t11_getBackupOwner_vm_miss tok sto account H) (eq_trans (t12_getBackupOwner_vm_miss tok sto account) (eq_trans (t13_getBackupOwner_vm_miss tok sto account) (eq_trans (t14_getBackupOwner_vm_miss tok sto account) (eq_trans (t15_getBackupOwner_vm_miss tok sto account) (eq_trans (t16_getBackupOwner_vm_miss tok sto account) (eq_trans (t17_getBackupOwner_vm_miss tok sto account) (t18_getBackupOwner_vm_miss tok sto account))))))))))))))))))).
 - apply getBackupOwner_source_miss with (sto := sto) (account := account)
     (tok := tok). exact H.
Qed.
Print Assumptions getBackupOwner_vm_miss.
Theorem getBackupOwner_vm_hit : forall (tok : nat -> GVal -> GVal) sto account payload xs v,
 sto (account_state_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs 2%nat = Some v ->
 run 29 0 getBackupOwner_vm_code (getBackupOwner_vm_init tok sto account) = Done v /\
 account_state_outcome tok 2 sto account = OK v.
Proof.
 intros tok sto account payload xs v H Htok Hnth. split.
 - exact (eq_trans (t0_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t1_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t2_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t3_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t4_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t5_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t6_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t7_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t8_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t9_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t10_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t11_getBackupOwner_vm_hit tok sto account payload xs v H) (eq_trans (t12_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t13_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t14_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t15_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t16_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t17_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t18_getBackupOwner_vm_hit tok sto account payload xs v Htok) (eq_trans (t19_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t20_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t21_getBackupOwner_vm_hit tok sto account payload xs v) (eq_trans (t22_getBackupOwner_vm_hit tok sto account payload xs v Hnth) (eq_trans (t23_getBackupOwner_vm_hit tok sto account payload xs v) (t24_getBackupOwner_vm_hit tok sto account payload xs v))))))))))))))))))))))))).
 - apply getBackupOwner_source_hit with (payload := payload) (xs := xs) (v := v); assumption.
Qed.
Print Assumptions getBackupOwner_vm_hit.
