From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition hasMarketEscrowOwnerCancel_vm_program : list Ins :=
 [InitSlot 0 1; LdArg; Call 7; Push GNull; NotEqualIns; Jump 6; Ret; InitSlot 1 1; LdStatic 32; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; Jump 17; Ret].
Definition hasMarketEscrowOwnerCancel_vm_code (pc : nat) : Ins := nth pc hasMarketEscrowOwnerCancel_vm_program Unsupported.
Definition hasMarketEscrowOwnerCancel_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 32 then Some (GBytes hasMarketEscrowOwnerCancel_prefix) else None.
Definition hasMarketEscrowOwnerCancel_vm_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 1) [GBytes account] hasMarketEscrowOwnerCancel_vm_statics sto [] (fun _ _ => GNull).

Definition M0_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 hasMarketEscrowOwnerCancel_vm_init sto account.

Definition M1_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hasMarketEscrowOwnerCancel_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasMarketEscrowOwnerCancel_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasMarketEscrowOwnerCancel_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account); GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account); GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (hasMarketEscrowOwnerCancel_prefix ++ account); GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_hasMarketEscrowOwnerCancel_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool false; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 20 0 hasMarketEscrowOwnerCancel_vm_code (M0_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 19 1 hasMarketEscrowOwnerCancel_vm_code (M1_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M0_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t1_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 19 1 hasMarketEscrowOwnerCancel_vm_code (M1_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 18 2 hasMarketEscrowOwnerCancel_vm_code (M2_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M1_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t2_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 18 2 hasMarketEscrowOwnerCancel_vm_code (M2_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 17 7 hasMarketEscrowOwnerCancel_vm_code (M3_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M2_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t3_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 17 7 hasMarketEscrowOwnerCancel_vm_code (M3_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 16 8 hasMarketEscrowOwnerCancel_vm_code (M4_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M3_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t4_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 16 8 hasMarketEscrowOwnerCancel_vm_code (M4_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 15 9 hasMarketEscrowOwnerCancel_vm_code (M5_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M4_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t5_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 15 9 hasMarketEscrowOwnerCancel_vm_code (M5_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 14 10 hasMarketEscrowOwnerCancel_vm_code (M6_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M5_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t6_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 14 10 hasMarketEscrowOwnerCancel_vm_code (M6_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 13 11 hasMarketEscrowOwnerCancel_vm_code (M7_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M6_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t7_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 13 11 hasMarketEscrowOwnerCancel_vm_code (M7_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 12 12 hasMarketEscrowOwnerCancel_vm_code (M8_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M7_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t8_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 12 12 hasMarketEscrowOwnerCancel_vm_code (M8_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 11 13 hasMarketEscrowOwnerCancel_vm_code (M9_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M8_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t9_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 11 13 hasMarketEscrowOwnerCancel_vm_code (M9_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 10 14 hasMarketEscrowOwnerCancel_vm_code (M10_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M9_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t10_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 10 14 hasMarketEscrowOwnerCancel_vm_code (M10_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 9 15 hasMarketEscrowOwnerCancel_vm_code (M11_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M10_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t11_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes) (Hstore : sto (hasMarketEscrowOwnerCancel_prefix ++ account) = None),
 run 9 15 hasMarketEscrowOwnerCancel_vm_code (M11_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 8 16 hasMarketEscrowOwnerCancel_vm_code (M12_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account Hstore.
 rewrite run_S.
 cbn [M11_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t11_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t12_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 8 16 hasMarketEscrowOwnerCancel_vm_code (M12_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 7 17 hasMarketEscrowOwnerCancel_vm_code (M13_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M12_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t13_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 7 17 hasMarketEscrowOwnerCancel_vm_code (M13_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 6 3 hasMarketEscrowOwnerCancel_vm_code (M14_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M13_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t14_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 6 3 hasMarketEscrowOwnerCancel_vm_code (M14_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 5 4 hasMarketEscrowOwnerCancel_vm_code (M15_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M14_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t15_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 5 4 hasMarketEscrowOwnerCancel_vm_code (M15_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 4 5 hasMarketEscrowOwnerCancel_vm_code (M16_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M15_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t16_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 4 5 hasMarketEscrowOwnerCancel_vm_code (M16_hasMarketEscrowOwnerCancel_vm_miss sto account) =
 run 3 6 hasMarketEscrowOwnerCancel_vm_code (M17_hasMarketEscrowOwnerCancel_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M16_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_hasMarketEscrowOwnerCancel_vm_miss.

Lemma t17_hasMarketEscrowOwnerCancel_vm_miss : forall (sto : storage) (account : bytes),
 run 3 6 hasMarketEscrowOwnerCancel_vm_code (M17_hasMarketEscrowOwnerCancel_vm_miss sto account) = Done (GBool false).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M17_hasMarketEscrowOwnerCancel_vm_miss hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_hasMarketEscrowOwnerCancel_vm_miss.
Definition M0_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 hasMarketEscrowOwnerCancel_vm_init sto account.

Definition M1_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := []; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := []; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes hasMarketEscrowOwnerCancel_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasMarketEscrowOwnerCancel_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes hasMarketEscrowOwnerCancel_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account); GBytes account]; mlocals := [GNull]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account); GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (hasMarketEscrowOwnerCancel_prefix ++ account); GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [3%nat];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_hasMarketEscrowOwnerCancel_vm_hit (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool true; GBytes account]; mlocals := [GBytes (hasMarketEscrowOwnerCancel_prefix ++ account)]; margs := [GBytes account];
    mstatics := hasMarketEscrowOwnerCancel_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 20 0 hasMarketEscrowOwnerCancel_vm_code (M0_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 19 1 hasMarketEscrowOwnerCancel_vm_code (M1_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M0_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t1_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 19 1 hasMarketEscrowOwnerCancel_vm_code (M1_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 18 2 hasMarketEscrowOwnerCancel_vm_code (M2_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M1_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t2_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 18 2 hasMarketEscrowOwnerCancel_vm_code (M2_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 17 7 hasMarketEscrowOwnerCancel_vm_code (M3_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M2_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t3_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 17 7 hasMarketEscrowOwnerCancel_vm_code (M3_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 16 8 hasMarketEscrowOwnerCancel_vm_code (M4_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M3_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t4_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 16 8 hasMarketEscrowOwnerCancel_vm_code (M4_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 15 9 hasMarketEscrowOwnerCancel_vm_code (M5_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M4_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t5_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 15 9 hasMarketEscrowOwnerCancel_vm_code (M5_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 14 10 hasMarketEscrowOwnerCancel_vm_code (M6_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M5_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t6_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 14 10 hasMarketEscrowOwnerCancel_vm_code (M6_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 13 11 hasMarketEscrowOwnerCancel_vm_code (M7_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M6_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t7_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 13 11 hasMarketEscrowOwnerCancel_vm_code (M7_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 12 12 hasMarketEscrowOwnerCancel_vm_code (M8_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M7_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t8_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 12 12 hasMarketEscrowOwnerCancel_vm_code (M8_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 11 13 hasMarketEscrowOwnerCancel_vm_code (M9_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M8_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t9_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 11 13 hasMarketEscrowOwnerCancel_vm_code (M9_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 10 14 hasMarketEscrowOwnerCancel_vm_code (M10_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M9_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t10_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 10 14 hasMarketEscrowOwnerCancel_vm_code (M10_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 9 15 hasMarketEscrowOwnerCancel_vm_code (M11_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M10_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t11_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes) (Hstore : sto (hasMarketEscrowOwnerCancel_prefix ++ account) = Some payload),
 run 9 15 hasMarketEscrowOwnerCancel_vm_code (M11_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 8 16 hasMarketEscrowOwnerCancel_vm_code (M12_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload Hstore.
 rewrite run_S.
 cbn [M11_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t11_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t12_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 8 16 hasMarketEscrowOwnerCancel_vm_code (M12_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 7 17 hasMarketEscrowOwnerCancel_vm_code (M13_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M12_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t13_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 7 17 hasMarketEscrowOwnerCancel_vm_code (M13_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 6 3 hasMarketEscrowOwnerCancel_vm_code (M14_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M13_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t14_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 6 3 hasMarketEscrowOwnerCancel_vm_code (M14_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 5 4 hasMarketEscrowOwnerCancel_vm_code (M15_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M14_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t15_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 5 4 hasMarketEscrowOwnerCancel_vm_code (M15_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 4 5 hasMarketEscrowOwnerCancel_vm_code (M16_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M15_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t16_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 4 5 hasMarketEscrowOwnerCancel_vm_code (M16_hasMarketEscrowOwnerCancel_vm_hit sto account payload) =
 run 3 6 hasMarketEscrowOwnerCancel_vm_code (M17_hasMarketEscrowOwnerCancel_vm_hit sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M16_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_hasMarketEscrowOwnerCancel_vm_hit.

Lemma t17_hasMarketEscrowOwnerCancel_vm_hit : forall (sto : storage) (account : bytes) (payload : bytes),
 run 3 6 hasMarketEscrowOwnerCancel_vm_code (M17_hasMarketEscrowOwnerCancel_vm_hit sto account payload) = Done (GBool true).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M17_hasMarketEscrowOwnerCancel_vm_hit hasMarketEscrowOwnerCancel_vm_init hasMarketEscrowOwnerCancel_vm_code hasMarketEscrowOwnerCancel_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_hasMarketEscrowOwnerCancel_vm_hit.

Theorem hasMarketEscrowOwnerCancel_vm_miss : forall sto account,
 sto (hasMarketEscrowOwnerCancel_prefix ++ account) = None ->
 run 20 0 hasMarketEscrowOwnerCancel_vm_code (hasMarketEscrowOwnerCancel_vm_init sto account) = Done (GBool false) /\
 hasMarketEscrowOwnerCancel_binding sto account = OK (GBool false).
Proof.
 intros sto account Hstore. split.
 - exact (eq_trans (t0_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t1_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t2_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t3_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t4_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t5_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t6_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t7_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t8_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t9_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t10_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t11_hasMarketEscrowOwnerCancel_vm_miss sto account Hstore) (eq_trans (t12_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t13_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t14_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t15_hasMarketEscrowOwnerCancel_vm_miss sto account) (eq_trans (t16_hasMarketEscrowOwnerCancel_vm_miss sto account) (t17_hasMarketEscrowOwnerCancel_vm_miss sto account)))))))))))))))))).
 - exact (hasMarketEscrowOwnerCancel_source_miss sto account Hstore).
Qed.
Print Assumptions hasMarketEscrowOwnerCancel_vm_miss.
Theorem hasMarketEscrowOwnerCancel_vm_hit : forall sto account payload,
 sto (hasMarketEscrowOwnerCancel_prefix ++ account) = Some payload ->
 run 20 0 hasMarketEscrowOwnerCancel_vm_code (hasMarketEscrowOwnerCancel_vm_init sto account) = Done (GBool true) /\
 hasMarketEscrowOwnerCancel_binding sto account = OK (GBool true).
Proof.
 intros sto account payload Hstore. split.
 - exact (eq_trans (t0_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t1_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t2_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t3_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t4_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t5_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t6_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t7_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t8_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t9_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t10_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t11_hasMarketEscrowOwnerCancel_vm_hit sto account payload Hstore) (eq_trans (t12_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t13_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t14_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t15_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (eq_trans (t16_hasMarketEscrowOwnerCancel_vm_hit sto account payload) (t17_hasMarketEscrowOwnerCancel_vm_hit sto account payload)))))))))))))))))).
 - exact (hasMarketEscrowOwnerCancel_source_hit sto account payload Hstore).
Qed.
Print Assumptions hasMarketEscrowOwnerCancel_vm_hit.
