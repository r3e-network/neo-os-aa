From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getVerifyScopeTarget_vm_program : list Ins :=
 [InitSlot 2 1; LdStatic 51; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 16; Push (GBytes [0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat;0%nat]); Jump 25; LdLoc 1; Dup; IsNull; JumpIf 25; Dup; SizeIns; Push (GInt 20%Z); JumpEq 25; Throw; Jump 26; Ret].
Definition getVerifyScopeTarget_vm_code (pc : nat) : Ins := nth pc getVerifyScopeTarget_vm_program Unsupported.
Definition getVerifyScopeTarget_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 51 then Some (GBytes getVerifyScopeTarget_prefix) else None.
Definition getVerifyScopeTarget_vm_init (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account] getVerifyScopeTarget_vm_statics sto [] (fun _ _ => GNull).

Definition M0_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 getVerifyScopeTarget_vm_init sto account.

Definition M1_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getVerifyScopeTarget_vm_miss (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes hash160_default]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 29 0 getVerifyScopeTarget_vm_code (M0_getVerifyScopeTarget_vm_miss sto account) =
 run 28 1 getVerifyScopeTarget_vm_code (M1_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M0_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getVerifyScopeTarget_vm_miss.

Lemma t1_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 28 1 getVerifyScopeTarget_vm_code (M1_getVerifyScopeTarget_vm_miss sto account) =
 run 27 2 getVerifyScopeTarget_vm_code (M2_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M1_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getVerifyScopeTarget_vm_miss.

Lemma t2_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 27 2 getVerifyScopeTarget_vm_code (M2_getVerifyScopeTarget_vm_miss sto account) =
 run 26 3 getVerifyScopeTarget_vm_code (M3_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M2_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getVerifyScopeTarget_vm_miss.

Lemma t3_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 26 3 getVerifyScopeTarget_vm_code (M3_getVerifyScopeTarget_vm_miss sto account) =
 run 25 4 getVerifyScopeTarget_vm_code (M4_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M3_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getVerifyScopeTarget_vm_miss.

Lemma t4_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 25 4 getVerifyScopeTarget_vm_code (M4_getVerifyScopeTarget_vm_miss sto account) =
 run 24 5 getVerifyScopeTarget_vm_code (M5_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M4_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getVerifyScopeTarget_vm_miss.

Lemma t5_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 24 5 getVerifyScopeTarget_vm_code (M5_getVerifyScopeTarget_vm_miss sto account) =
 run 23 6 getVerifyScopeTarget_vm_code (M6_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M5_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getVerifyScopeTarget_vm_miss.

Lemma t6_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 23 6 getVerifyScopeTarget_vm_code (M6_getVerifyScopeTarget_vm_miss sto account) =
 run 22 7 getVerifyScopeTarget_vm_code (M7_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M6_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getVerifyScopeTarget_vm_miss.

Lemma t7_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 22 7 getVerifyScopeTarget_vm_code (M7_getVerifyScopeTarget_vm_miss sto account) =
 run 21 8 getVerifyScopeTarget_vm_code (M8_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M7_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getVerifyScopeTarget_vm_miss.

Lemma t8_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes) (Hstore : sto (getVerifyScopeTarget_prefix ++ account) = None),
 run 21 8 getVerifyScopeTarget_vm_code (M8_getVerifyScopeTarget_vm_miss sto account) =
 run 20 9 getVerifyScopeTarget_vm_code (M9_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account Hstore.
 rewrite run_S.
 cbn [M8_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getVerifyScopeTarget_vm_miss.

Lemma t9_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 20 9 getVerifyScopeTarget_vm_code (M9_getVerifyScopeTarget_vm_miss sto account) =
 run 19 10 getVerifyScopeTarget_vm_code (M10_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M9_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getVerifyScopeTarget_vm_miss.

Lemma t10_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 19 10 getVerifyScopeTarget_vm_code (M10_getVerifyScopeTarget_vm_miss sto account) =
 run 18 11 getVerifyScopeTarget_vm_code (M11_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M10_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getVerifyScopeTarget_vm_miss.

Lemma t11_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 18 11 getVerifyScopeTarget_vm_code (M11_getVerifyScopeTarget_vm_miss sto account) =
 run 17 12 getVerifyScopeTarget_vm_code (M12_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M11_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getVerifyScopeTarget_vm_miss.

Lemma t12_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 17 12 getVerifyScopeTarget_vm_code (M12_getVerifyScopeTarget_vm_miss sto account) =
 run 16 13 getVerifyScopeTarget_vm_code (M13_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M12_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getVerifyScopeTarget_vm_miss.

Lemma t13_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 16 13 getVerifyScopeTarget_vm_code (M13_getVerifyScopeTarget_vm_miss sto account) =
 run 15 14 getVerifyScopeTarget_vm_code (M14_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M13_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getVerifyScopeTarget_vm_miss.

Lemma t14_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 15 14 getVerifyScopeTarget_vm_code (M14_getVerifyScopeTarget_vm_miss sto account) =
 run 14 15 getVerifyScopeTarget_vm_code (M15_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M14_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getVerifyScopeTarget_vm_miss.

Lemma t15_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 14 15 getVerifyScopeTarget_vm_code (M15_getVerifyScopeTarget_vm_miss sto account) =
 run 13 25 getVerifyScopeTarget_vm_code (M16_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M15_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getVerifyScopeTarget_vm_miss.

Lemma t16_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 13 25 getVerifyScopeTarget_vm_code (M16_getVerifyScopeTarget_vm_miss sto account) =
 run 12 26 getVerifyScopeTarget_vm_code (M17_getVerifyScopeTarget_vm_miss sto account).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M16_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getVerifyScopeTarget_vm_miss.

Lemma t17_getVerifyScopeTarget_vm_miss : forall (sto : storage) (account : bytes),
 run 12 26 getVerifyScopeTarget_vm_code (M17_getVerifyScopeTarget_vm_miss sto account) = Done (GBytes hash160_default).
Proof.
 intros sto account.
 rewrite run_S.
 cbn [M17_getVerifyScopeTarget_vm_miss getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getVerifyScopeTarget_vm_miss.
Definition M0_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 getVerifyScopeTarget_vm_init sto account.

Definition M1_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M19_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M20_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M21_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GInt 20%Z; GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M22_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M23_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M24_getVerifyScopeTarget_vm_hitvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 29 0 getVerifyScopeTarget_vm_code (M0_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 28 1 getVerifyScopeTarget_vm_code (M1_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M0_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getVerifyScopeTarget_vm_hitvalid.

Lemma t1_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 28 1 getVerifyScopeTarget_vm_code (M1_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 27 2 getVerifyScopeTarget_vm_code (M2_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M1_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getVerifyScopeTarget_vm_hitvalid.

Lemma t2_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 27 2 getVerifyScopeTarget_vm_code (M2_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 26 3 getVerifyScopeTarget_vm_code (M3_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M2_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getVerifyScopeTarget_vm_hitvalid.

Lemma t3_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 26 3 getVerifyScopeTarget_vm_code (M3_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 25 4 getVerifyScopeTarget_vm_code (M4_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M3_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getVerifyScopeTarget_vm_hitvalid.

Lemma t4_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 25 4 getVerifyScopeTarget_vm_code (M4_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 24 5 getVerifyScopeTarget_vm_code (M5_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M4_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getVerifyScopeTarget_vm_hitvalid.

Lemma t5_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 24 5 getVerifyScopeTarget_vm_code (M5_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 23 6 getVerifyScopeTarget_vm_code (M6_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M5_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getVerifyScopeTarget_vm_hitvalid.

Lemma t6_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 23 6 getVerifyScopeTarget_vm_code (M6_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 22 7 getVerifyScopeTarget_vm_code (M7_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M6_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getVerifyScopeTarget_vm_hitvalid.

Lemma t7_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 22 7 getVerifyScopeTarget_vm_code (M7_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 21 8 getVerifyScopeTarget_vm_code (M8_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M7_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getVerifyScopeTarget_vm_hitvalid.

Lemma t8_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes) (Hstore : sto (getVerifyScopeTarget_prefix ++ account) = Some payload),
 run 21 8 getVerifyScopeTarget_vm_code (M8_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 20 9 getVerifyScopeTarget_vm_code (M9_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload Hstore.
 rewrite run_S.
 cbn [M8_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getVerifyScopeTarget_vm_hitvalid.

Lemma t9_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 20 9 getVerifyScopeTarget_vm_code (M9_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 19 10 getVerifyScopeTarget_vm_code (M10_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M9_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getVerifyScopeTarget_vm_hitvalid.

Lemma t10_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 19 10 getVerifyScopeTarget_vm_code (M10_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 18 11 getVerifyScopeTarget_vm_code (M11_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M10_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getVerifyScopeTarget_vm_hitvalid.

Lemma t11_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 18 11 getVerifyScopeTarget_vm_code (M11_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 17 12 getVerifyScopeTarget_vm_code (M12_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M11_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getVerifyScopeTarget_vm_hitvalid.

Lemma t12_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 17 12 getVerifyScopeTarget_vm_code (M12_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 16 13 getVerifyScopeTarget_vm_code (M13_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M12_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getVerifyScopeTarget_vm_hitvalid.

Lemma t13_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 16 13 getVerifyScopeTarget_vm_code (M13_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 15 16 getVerifyScopeTarget_vm_code (M14_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M13_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getVerifyScopeTarget_vm_hitvalid.

Lemma t14_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 15 16 getVerifyScopeTarget_vm_code (M14_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 14 17 getVerifyScopeTarget_vm_code (M15_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M14_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getVerifyScopeTarget_vm_hitvalid.

Lemma t15_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 14 17 getVerifyScopeTarget_vm_code (M15_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 13 18 getVerifyScopeTarget_vm_code (M16_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M15_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getVerifyScopeTarget_vm_hitvalid.

Lemma t16_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 13 18 getVerifyScopeTarget_vm_code (M16_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 12 19 getVerifyScopeTarget_vm_code (M17_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M16_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getVerifyScopeTarget_vm_hitvalid.

Lemma t17_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 12 19 getVerifyScopeTarget_vm_code (M17_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 11 20 getVerifyScopeTarget_vm_code (M18_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M17_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getVerifyScopeTarget_vm_hitvalid.

Lemma t18_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 11 20 getVerifyScopeTarget_vm_code (M18_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 10 21 getVerifyScopeTarget_vm_code (M19_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M18_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getVerifyScopeTarget_vm_hitvalid.

Lemma t19_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 10 21 getVerifyScopeTarget_vm_code (M19_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 9 22 getVerifyScopeTarget_vm_code (M20_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M19_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getVerifyScopeTarget_vm_hitvalid.

Lemma t20_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 9 22 getVerifyScopeTarget_vm_code (M20_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 8 23 getVerifyScopeTarget_vm_code (M21_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M20_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getVerifyScopeTarget_vm_hitvalid.

Lemma t21_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes) (Hz : Z.eqb (Z.of_nat (length payload)) 20%Z = true),
 run 8 23 getVerifyScopeTarget_vm_code (M21_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 7 25 getVerifyScopeTarget_vm_code (M22_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload Hz.
 rewrite run_S.
 cbn [M21_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hz.
 reflexivity.
Qed.
Print Assumptions t21_getVerifyScopeTarget_vm_hitvalid.

Lemma t22_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 7 25 getVerifyScopeTarget_vm_code (M22_getVerifyScopeTarget_vm_hitvalid sto account payload) =
 run 6 26 getVerifyScopeTarget_vm_code (M23_getVerifyScopeTarget_vm_hitvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M22_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getVerifyScopeTarget_vm_hitvalid.

Lemma t23_getVerifyScopeTarget_vm_hitvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 6 26 getVerifyScopeTarget_vm_code (M23_getVerifyScopeTarget_vm_hitvalid sto account payload) = Done (GBytes payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M23_getVerifyScopeTarget_vm_hitvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getVerifyScopeTarget_vm_hitvalid.
Definition M0_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 getVerifyScopeTarget_vm_init sto account.

Definition M1_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M2_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M3_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M4_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getVerifyScopeTarget_prefix]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M5_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GNull; GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M6_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M7_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M8_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getVerifyScopeTarget_prefix ++ account)]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M9_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GNull]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M10_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M11_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M12_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GNull; GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M13_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool false]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M14_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := []; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M15_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M16_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M17_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBool false; GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M18_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M19_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload; GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M20_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M21_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GInt 20%Z; GInt (Z.of_nat (length payload)); GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M22_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Definition M23_getVerifyScopeTarget_vm_hitinvalid (sto : storage) (account : bytes) (payload : bytes) : Machine :=
 {| mstack := [GBytes payload]; mlocals := [GBytes (getVerifyScopeTarget_prefix ++ account); GBytes payload]; margs := [GBytes account];
    mstatics := getVerifyScopeTarget_vm_statics; msto := sto; mcalls := [];
    mtokens := (fun _ _ => GNull) |}.

Lemma t0_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 29 0 getVerifyScopeTarget_vm_code (M0_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 28 1 getVerifyScopeTarget_vm_code (M1_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M0_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getVerifyScopeTarget_vm_hitinvalid.

Lemma t1_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 28 1 getVerifyScopeTarget_vm_code (M1_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 27 2 getVerifyScopeTarget_vm_code (M2_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M1_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getVerifyScopeTarget_vm_hitinvalid.

Lemma t2_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 27 2 getVerifyScopeTarget_vm_code (M2_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 26 3 getVerifyScopeTarget_vm_code (M3_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M2_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getVerifyScopeTarget_vm_hitinvalid.

Lemma t3_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 26 3 getVerifyScopeTarget_vm_code (M3_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 25 4 getVerifyScopeTarget_vm_code (M4_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M3_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getVerifyScopeTarget_vm_hitinvalid.

Lemma t4_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 25 4 getVerifyScopeTarget_vm_code (M4_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 24 5 getVerifyScopeTarget_vm_code (M5_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M4_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getVerifyScopeTarget_vm_hitinvalid.

Lemma t5_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 24 5 getVerifyScopeTarget_vm_code (M5_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 23 6 getVerifyScopeTarget_vm_code (M6_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M5_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getVerifyScopeTarget_vm_hitinvalid.

Lemma t6_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 23 6 getVerifyScopeTarget_vm_code (M6_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 22 7 getVerifyScopeTarget_vm_code (M7_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M6_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getVerifyScopeTarget_vm_hitinvalid.

Lemma t7_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 22 7 getVerifyScopeTarget_vm_code (M7_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 21 8 getVerifyScopeTarget_vm_code (M8_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M7_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getVerifyScopeTarget_vm_hitinvalid.

Lemma t8_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes) (Hstore : sto (getVerifyScopeTarget_prefix ++ account) = Some payload),
 run 21 8 getVerifyScopeTarget_vm_code (M8_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 20 9 getVerifyScopeTarget_vm_code (M9_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload Hstore.
 rewrite run_S.
 cbn [M8_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t8_getVerifyScopeTarget_vm_hitinvalid.

Lemma t9_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 20 9 getVerifyScopeTarget_vm_code (M9_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 19 10 getVerifyScopeTarget_vm_code (M10_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M9_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getVerifyScopeTarget_vm_hitinvalid.

Lemma t10_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 19 10 getVerifyScopeTarget_vm_code (M10_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 18 11 getVerifyScopeTarget_vm_code (M11_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M10_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getVerifyScopeTarget_vm_hitinvalid.

Lemma t11_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 18 11 getVerifyScopeTarget_vm_code (M11_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 17 12 getVerifyScopeTarget_vm_code (M12_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M11_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getVerifyScopeTarget_vm_hitinvalid.

Lemma t12_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 17 12 getVerifyScopeTarget_vm_code (M12_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 16 13 getVerifyScopeTarget_vm_code (M13_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M12_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t12_getVerifyScopeTarget_vm_hitinvalid.

Lemma t13_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 16 13 getVerifyScopeTarget_vm_code (M13_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 15 16 getVerifyScopeTarget_vm_code (M14_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M13_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getVerifyScopeTarget_vm_hitinvalid.

Lemma t14_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 15 16 getVerifyScopeTarget_vm_code (M14_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 14 17 getVerifyScopeTarget_vm_code (M15_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M14_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getVerifyScopeTarget_vm_hitinvalid.

Lemma t15_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 14 17 getVerifyScopeTarget_vm_code (M15_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 13 18 getVerifyScopeTarget_vm_code (M16_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M15_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getVerifyScopeTarget_vm_hitinvalid.

Lemma t16_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 13 18 getVerifyScopeTarget_vm_code (M16_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 12 19 getVerifyScopeTarget_vm_code (M17_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M16_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getVerifyScopeTarget_vm_hitinvalid.

Lemma t17_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 12 19 getVerifyScopeTarget_vm_code (M17_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 11 20 getVerifyScopeTarget_vm_code (M18_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M17_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getVerifyScopeTarget_vm_hitinvalid.

Lemma t18_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 11 20 getVerifyScopeTarget_vm_code (M18_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 10 21 getVerifyScopeTarget_vm_code (M19_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M18_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getVerifyScopeTarget_vm_hitinvalid.

Lemma t19_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 10 21 getVerifyScopeTarget_vm_code (M19_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 9 22 getVerifyScopeTarget_vm_code (M20_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M19_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getVerifyScopeTarget_vm_hitinvalid.

Lemma t20_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 9 22 getVerifyScopeTarget_vm_code (M20_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 8 23 getVerifyScopeTarget_vm_code (M21_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M20_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getVerifyScopeTarget_vm_hitinvalid.

Lemma t21_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes) (Hz : Z.eqb (Z.of_nat (length payload)) 20%Z = false),
 run 8 23 getVerifyScopeTarget_vm_code (M21_getVerifyScopeTarget_vm_hitinvalid sto account payload) =
 run 7 24 getVerifyScopeTarget_vm_code (M22_getVerifyScopeTarget_vm_hitinvalid sto account payload).
Proof.
 intros sto account payload Hz.
 rewrite run_S.
 cbn [M21_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hz.
 reflexivity.
Qed.
Print Assumptions t21_getVerifyScopeTarget_vm_hitinvalid.

Lemma t22_getVerifyScopeTarget_vm_hitinvalid : forall (sto : storage) (account : bytes) (payload : bytes),
 run 7 24 getVerifyScopeTarget_vm_code (M22_getVerifyScopeTarget_vm_hitinvalid sto account payload) = Thrown.
Proof.
 intros sto account payload.
 rewrite run_S.
 cbn [M22_getVerifyScopeTarget_vm_hitinvalid getVerifyScopeTarget_vm_init getVerifyScopeTarget_vm_code getVerifyScopeTarget_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getVerifyScopeTarget_vm_hitinvalid.

Theorem getVerifyScopeTarget_vm_miss : forall sto account,
 sto (getVerifyScopeTarget_prefix ++ account) = None ->
 run 29 0 getVerifyScopeTarget_vm_code (getVerifyScopeTarget_vm_init sto account) = Done (GBytes hash160_default) /\
 getter_outcome getVerifyScopeTarget_prefix (GBytes hash160_default) decode_hash160 sto account = OK (GBytes hash160_default).
Proof.
 intros sto account Hstore. split.
 - exact (eq_trans (t0_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t1_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t2_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t3_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t4_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t5_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t6_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t7_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t8_getVerifyScopeTarget_vm_miss sto account Hstore) (eq_trans (t9_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t10_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t11_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t12_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t13_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t14_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t15_getVerifyScopeTarget_vm_miss sto account) (eq_trans (t16_getVerifyScopeTarget_vm_miss sto account) (t17_getVerifyScopeTarget_vm_miss sto account)))))))))))))))))).
 - unfold getter_outcome. rewrite Hstore. reflexivity.
Qed.
Print Assumptions getVerifyScopeTarget_vm_miss.
Theorem getVerifyScopeTarget_vm_hit_valid : forall sto account payload,
 sto (getVerifyScopeTarget_prefix ++ account) = Some payload ->
 valid_bytes payload = true ->
 (length payload = 20)%nat ->
 run 29 0 getVerifyScopeTarget_vm_code (getVerifyScopeTarget_vm_init sto account) = Done (GBytes payload) /\
 getter_outcome getVerifyScopeTarget_prefix (GBytes hash160_default) decode_hash160 sto account = OK (GBytes payload).
Proof.
 intros sto account payload Hstore Hvalid Hlen.
 assert (Hz : Z.eqb (Z.of_nat (length payload)) 20 = true).
 { apply Z.eqb_eq. rewrite Hlen. reflexivity. }
 split.
 - exact (eq_trans (t0_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t1_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t2_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t3_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t4_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t5_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t6_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t7_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t8_getVerifyScopeTarget_vm_hitvalid sto account payload Hstore) (eq_trans (t9_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t10_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t11_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t12_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t13_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t14_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t15_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t16_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t17_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t18_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t19_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t20_getVerifyScopeTarget_vm_hitvalid sto account payload) (eq_trans (t21_getVerifyScopeTarget_vm_hitvalid sto account payload Hz) (eq_trans (t22_getVerifyScopeTarget_vm_hitvalid sto account payload) (t23_getVerifyScopeTarget_vm_hitvalid sto account payload)))))))))))))))))))))))).
 - unfold getter_outcome, decode_hash160.
   rewrite Hstore, Hvalid, Hlen. reflexivity.
Qed.
Print Assumptions getVerifyScopeTarget_vm_hit_valid.
Theorem getVerifyScopeTarget_vm_hit_invalid_size : forall sto account payload,
 sto (getVerifyScopeTarget_prefix ++ account) = Some payload ->
 (length payload <> 20)%nat ->
 run 29 0 getVerifyScopeTarget_vm_code (getVerifyScopeTarget_vm_init sto account) = Thrown /\
 getter_outcome getVerifyScopeTarget_prefix (GBytes hash160_default) decode_hash160 sto account = Fault.
Proof.
 intros sto account payload Hstore Hlen.
 assert (Hz : Z.eqb (Z.of_nat (length payload)) 20 = false).
 { apply Z.eqb_neq. intro He. apply Hlen.
   apply (Nat2Z.inj (length payload) 20 He). }
 split.
 - exact (eq_trans (t0_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t1_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t2_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t3_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t4_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t5_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t6_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t7_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t8_getVerifyScopeTarget_vm_hitinvalid sto account payload Hstore) (eq_trans (t9_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t10_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t11_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t12_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t13_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t14_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t15_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t16_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t17_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t18_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t19_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t20_getVerifyScopeTarget_vm_hitinvalid sto account payload) (eq_trans (t21_getVerifyScopeTarget_vm_hitinvalid sto account payload Hz) (t22_getVerifyScopeTarget_vm_hitinvalid sto account payload))))))))))))))))))))))).
 - unfold getter_outcome, decode_hash160. rewrite Hstore.
   apply Nat.eqb_neq in Hlen. rewrite Hlen, andb_false_r. reflexivity.
Qed.
Print Assumptions getVerifyScopeTarget_vm_hit_invalid_size.
