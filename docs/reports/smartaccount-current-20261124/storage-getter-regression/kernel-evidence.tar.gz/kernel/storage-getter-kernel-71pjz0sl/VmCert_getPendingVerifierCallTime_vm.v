From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Require Import StorageGetterVm.
Require Import StorageGetterArtifact.

Definition getPendingVerifierCallTime_vm_program : list Ins :=
 [InitSlot 1 1; LdArg; LdStatic 20; Call 18; StLoc 0; LdLoc 0; Push GNull; EqualIns; JumpIfNot 11; Push (GInt 0); Jump 16; LdLoc 0; Push (GInt 2); PickItem; LdStatic 14; AddIns; Jump 17; Ret; InitSlot 2 2; LdArgN 1; LdArg; Convert 48; Concat; StLoc 0; LdLoc 0; GetContext; StorageGet; StLoc 1; LdLoc 1; Push GNull; EqualIns; JumpIfNot 34; Push GNull; Jump 37; LdLoc 1; CallToken 4; Jump 37; Ret].
Definition getPendingVerifierCallTime_vm_code (pc : nat) : Ins := nth pc getPendingVerifierCallTime_vm_program Unsupported.
Definition getPendingVerifierCallTime_vm_statics : nat -> option GVal :=
 fun i => if Nat.eqb i 20 then Some (GBytes getPendingVerifierCallTime_prefix)
          else if Nat.eqb i 14 then Some (GInt 86400000%Z) else None.
Definition getPendingVerifierCallTime_vm_init (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 machine [] (repeat GNull 2) [GBytes account; GBytes getPendingVerifierCallTime_prefix] getPendingVerifierCallTime_vm_statics sto [] tok.

Definition M0_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 getPendingVerifierCallTime_vm_init tok sto account.

Definition M1_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M5_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M6_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M7_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingVerifierCallTime_prefix; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M8_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingVerifierCallTime_prefix; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M9_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M10_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M11_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M12_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M13_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M14_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M15_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M16_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M17_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M18_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M19_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M20_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M21_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M22_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GNull; GNull; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBool true; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M26_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M27_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M28_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M29_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M30_getPendingVerifierCallTime_vm_miss (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) : Machine :=
 {| mstack := [GInt 0%Z; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 40 0 getPendingVerifierCallTime_vm_code (M0_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 39 1 getPendingVerifierCallTime_vm_code (M1_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M0_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingVerifierCallTime_vm_miss.

Lemma t1_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 39 1 getPendingVerifierCallTime_vm_code (M1_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 38 2 getPendingVerifierCallTime_vm_code (M2_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M1_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingVerifierCallTime_vm_miss.

Lemma t2_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 38 2 getPendingVerifierCallTime_vm_code (M2_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 37 3 getPendingVerifierCallTime_vm_code (M3_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M2_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingVerifierCallTime_vm_miss.

Lemma t3_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 37 3 getPendingVerifierCallTime_vm_code (M3_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 36 18 getPendingVerifierCallTime_vm_code (M4_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M3_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingVerifierCallTime_vm_miss.

Lemma t4_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 36 18 getPendingVerifierCallTime_vm_code (M4_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 35 19 getPendingVerifierCallTime_vm_code (M5_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M4_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingVerifierCallTime_vm_miss.

Lemma t5_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 35 19 getPendingVerifierCallTime_vm_code (M5_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 34 20 getPendingVerifierCallTime_vm_code (M6_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M5_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingVerifierCallTime_vm_miss.

Lemma t6_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 34 20 getPendingVerifierCallTime_vm_code (M6_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 33 21 getPendingVerifierCallTime_vm_code (M7_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M6_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingVerifierCallTime_vm_miss.

Lemma t7_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 33 21 getPendingVerifierCallTime_vm_code (M7_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 32 22 getPendingVerifierCallTime_vm_code (M8_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M7_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingVerifierCallTime_vm_miss.

Lemma t8_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 32 22 getPendingVerifierCallTime_vm_code (M8_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 31 23 getPendingVerifierCallTime_vm_code (M9_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M8_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingVerifierCallTime_vm_miss.

Lemma t9_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 31 23 getPendingVerifierCallTime_vm_code (M9_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 30 24 getPendingVerifierCallTime_vm_code (M10_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M9_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingVerifierCallTime_vm_miss.

Lemma t10_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 30 24 getPendingVerifierCallTime_vm_code (M10_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 29 25 getPendingVerifierCallTime_vm_code (M11_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M10_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingVerifierCallTime_vm_miss.

Lemma t11_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 29 25 getPendingVerifierCallTime_vm_code (M11_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 28 26 getPendingVerifierCallTime_vm_code (M12_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M11_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingVerifierCallTime_vm_miss.

Lemma t12_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (Hstore : sto (getPendingVerifierCallTime_prefix ++ account) = None),
 run 28 26 getPendingVerifierCallTime_vm_code (M12_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 27 27 getPendingVerifierCallTime_vm_code (M13_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account Hstore.
 rewrite run_S.
 cbn [M12_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t12_getPendingVerifierCallTime_vm_miss.

Lemma t13_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 27 27 getPendingVerifierCallTime_vm_code (M13_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 26 28 getPendingVerifierCallTime_vm_code (M14_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M13_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingVerifierCallTime_vm_miss.

Lemma t14_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 26 28 getPendingVerifierCallTime_vm_code (M14_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 25 29 getPendingVerifierCallTime_vm_code (M15_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M14_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingVerifierCallTime_vm_miss.

Lemma t15_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 25 29 getPendingVerifierCallTime_vm_code (M15_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 24 30 getPendingVerifierCallTime_vm_code (M16_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M15_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingVerifierCallTime_vm_miss.

Lemma t16_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 24 30 getPendingVerifierCallTime_vm_code (M16_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 23 31 getPendingVerifierCallTime_vm_code (M17_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M16_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingVerifierCallTime_vm_miss.

Lemma t17_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 23 31 getPendingVerifierCallTime_vm_code (M17_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 22 32 getPendingVerifierCallTime_vm_code (M18_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M17_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingVerifierCallTime_vm_miss.

Lemma t18_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 22 32 getPendingVerifierCallTime_vm_code (M18_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 21 33 getPendingVerifierCallTime_vm_code (M19_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M18_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingVerifierCallTime_vm_miss.

Lemma t19_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 21 33 getPendingVerifierCallTime_vm_code (M19_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 20 37 getPendingVerifierCallTime_vm_code (M20_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M19_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t19_getPendingVerifierCallTime_vm_miss.

Lemma t20_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 20 37 getPendingVerifierCallTime_vm_code (M20_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 19 4 getPendingVerifierCallTime_vm_code (M21_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M20_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getPendingVerifierCallTime_vm_miss.

Lemma t21_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 19 4 getPendingVerifierCallTime_vm_code (M21_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 18 5 getPendingVerifierCallTime_vm_code (M22_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M21_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getPendingVerifierCallTime_vm_miss.

Lemma t22_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 18 5 getPendingVerifierCallTime_vm_code (M22_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 17 6 getPendingVerifierCallTime_vm_code (M23_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M22_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getPendingVerifierCallTime_vm_miss.

Lemma t23_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 17 6 getPendingVerifierCallTime_vm_code (M23_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 16 7 getPendingVerifierCallTime_vm_code (M24_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M23_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getPendingVerifierCallTime_vm_miss.

Lemma t24_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 16 7 getPendingVerifierCallTime_vm_code (M24_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 15 8 getPendingVerifierCallTime_vm_code (M25_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M24_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getPendingVerifierCallTime_vm_miss.

Lemma t25_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 15 8 getPendingVerifierCallTime_vm_code (M25_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 14 9 getPendingVerifierCallTime_vm_code (M26_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M25_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t25_getPendingVerifierCallTime_vm_miss.

Lemma t26_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 14 9 getPendingVerifierCallTime_vm_code (M26_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 13 10 getPendingVerifierCallTime_vm_code (M27_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M26_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t26_getPendingVerifierCallTime_vm_miss.

Lemma t27_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 13 10 getPendingVerifierCallTime_vm_code (M27_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 12 16 getPendingVerifierCallTime_vm_code (M28_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M27_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t27_getPendingVerifierCallTime_vm_miss.

Lemma t28_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 12 16 getPendingVerifierCallTime_vm_code (M28_getPendingVerifierCallTime_vm_miss tok sto account) =
 run 11 17 getPendingVerifierCallTime_vm_code (M29_getPendingVerifierCallTime_vm_miss tok sto account).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M28_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t28_getPendingVerifierCallTime_vm_miss.

Lemma t29_getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes),
 run 11 17 getPendingVerifierCallTime_vm_code (M29_getPendingVerifierCallTime_vm_miss tok sto account) = Done (GInt 0%Z).
Proof.
 intros tok sto account.
 rewrite run_S.
 cbn [M29_getPendingVerifierCallTime_vm_miss getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t29_getPendingVerifierCallTime_vm_miss.
Definition M0_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 getPendingVerifierCallTime_vm_init tok sto account.

Definition M1_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := []; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M2_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M3_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M4_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M5_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M6_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M7_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingVerifierCallTime_prefix; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M8_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes account; GBytes getPendingVerifierCallTime_prefix; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M9_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GNull; GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M10_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M11_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M12_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes [33%nat]; GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M13_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GNull]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M14_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M15_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M16_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GNull; GBytes payload; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M17_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBool false; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M18_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M19_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes payload; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M20_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M21_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [4%nat];
    mtokens := tok |}.

Definition M22_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GBytes (getPendingVerifierCallTime_prefix ++ account); GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M23_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M24_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M25_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GNull; GArray xs; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M26_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBool false; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M27_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M28_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GArray xs; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M29_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt 2%Z; GArray xs; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M30_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt z; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M31_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt 86400000%Z; GInt z; GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M32_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M33_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Definition M34_getPendingVerifierCallTime_vm_hit (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) : Machine :=
 {| mstack := [GInt (z + 86400000%Z); GBytes getPendingVerifierCallTime_prefix; GBytes account]; mlocals := [GArray xs; GBytes payload]; margs := [GBytes account; GBytes getPendingVerifierCallTime_prefix];
    mstatics := getPendingVerifierCallTime_vm_statics; msto := sto; mcalls := [];
    mtokens := tok |}.

Lemma t0_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 40 0 getPendingVerifierCallTime_vm_code (M0_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 39 1 getPendingVerifierCallTime_vm_code (M1_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M0_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t0_getPendingVerifierCallTime_vm_hit.

Lemma t1_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 39 1 getPendingVerifierCallTime_vm_code (M1_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 38 2 getPendingVerifierCallTime_vm_code (M2_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M1_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t1_getPendingVerifierCallTime_vm_hit.

Lemma t2_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 38 2 getPendingVerifierCallTime_vm_code (M2_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 37 3 getPendingVerifierCallTime_vm_code (M3_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M2_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t2_getPendingVerifierCallTime_vm_hit.

Lemma t3_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 37 3 getPendingVerifierCallTime_vm_code (M3_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 36 18 getPendingVerifierCallTime_vm_code (M4_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M3_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t3_getPendingVerifierCallTime_vm_hit.

Lemma t4_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 36 18 getPendingVerifierCallTime_vm_code (M4_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 35 19 getPendingVerifierCallTime_vm_code (M5_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M4_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t4_getPendingVerifierCallTime_vm_hit.

Lemma t5_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 35 19 getPendingVerifierCallTime_vm_code (M5_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 34 20 getPendingVerifierCallTime_vm_code (M6_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M5_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t5_getPendingVerifierCallTime_vm_hit.

Lemma t6_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 34 20 getPendingVerifierCallTime_vm_code (M6_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 33 21 getPendingVerifierCallTime_vm_code (M7_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M6_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t6_getPendingVerifierCallTime_vm_hit.

Lemma t7_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 33 21 getPendingVerifierCallTime_vm_code (M7_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 32 22 getPendingVerifierCallTime_vm_code (M8_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M7_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t7_getPendingVerifierCallTime_vm_hit.

Lemma t8_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 32 22 getPendingVerifierCallTime_vm_code (M8_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 31 23 getPendingVerifierCallTime_vm_code (M9_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M8_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t8_getPendingVerifierCallTime_vm_hit.

Lemma t9_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 31 23 getPendingVerifierCallTime_vm_code (M9_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 30 24 getPendingVerifierCallTime_vm_code (M10_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M9_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t9_getPendingVerifierCallTime_vm_hit.

Lemma t10_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 30 24 getPendingVerifierCallTime_vm_code (M10_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 29 25 getPendingVerifierCallTime_vm_code (M11_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M10_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t10_getPendingVerifierCallTime_vm_hit.

Lemma t11_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 29 25 getPendingVerifierCallTime_vm_code (M11_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 28 26 getPendingVerifierCallTime_vm_code (M12_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M11_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t11_getPendingVerifierCallTime_vm_hit.

Lemma t12_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hstore : sto (getPendingVerifierCallTime_prefix ++ account) = Some payload),
 run 28 26 getPendingVerifierCallTime_vm_code (M12_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 27 27 getPendingVerifierCallTime_vm_code (M13_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hstore.
 rewrite run_S.
 cbn [M12_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hstore.
 reflexivity.
Qed.
Print Assumptions t12_getPendingVerifierCallTime_vm_hit.

Lemma t13_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 27 27 getPendingVerifierCallTime_vm_code (M13_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 26 28 getPendingVerifierCallTime_vm_code (M14_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M13_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t13_getPendingVerifierCallTime_vm_hit.

Lemma t14_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 26 28 getPendingVerifierCallTime_vm_code (M14_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 25 29 getPendingVerifierCallTime_vm_code (M15_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M14_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t14_getPendingVerifierCallTime_vm_hit.

Lemma t15_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 25 29 getPendingVerifierCallTime_vm_code (M15_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 24 30 getPendingVerifierCallTime_vm_code (M16_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M15_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t15_getPendingVerifierCallTime_vm_hit.

Lemma t16_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 24 30 getPendingVerifierCallTime_vm_code (M16_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 23 31 getPendingVerifierCallTime_vm_code (M17_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M16_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t16_getPendingVerifierCallTime_vm_hit.

Lemma t17_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 23 31 getPendingVerifierCallTime_vm_code (M17_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 22 34 getPendingVerifierCallTime_vm_code (M18_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M17_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t17_getPendingVerifierCallTime_vm_hit.

Lemma t18_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 22 34 getPendingVerifierCallTime_vm_code (M18_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 21 35 getPendingVerifierCallTime_vm_code (M19_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M18_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t18_getPendingVerifierCallTime_vm_hit.

Lemma t19_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Htok : tok 4%nat (GBytes payload) = GArray xs),
 run 21 35 getPendingVerifierCallTime_vm_code (M19_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 20 36 getPendingVerifierCallTime_vm_code (M20_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Htok.
 rewrite run_S.
 cbn [M19_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Htok.
 reflexivity.
Qed.
Print Assumptions t19_getPendingVerifierCallTime_vm_hit.

Lemma t20_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 20 36 getPendingVerifierCallTime_vm_code (M20_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 19 37 getPendingVerifierCallTime_vm_code (M21_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M20_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t20_getPendingVerifierCallTime_vm_hit.

Lemma t21_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 19 37 getPendingVerifierCallTime_vm_code (M21_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 18 4 getPendingVerifierCallTime_vm_code (M22_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M21_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t21_getPendingVerifierCallTime_vm_hit.

Lemma t22_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 18 4 getPendingVerifierCallTime_vm_code (M22_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 17 5 getPendingVerifierCallTime_vm_code (M23_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M22_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t22_getPendingVerifierCallTime_vm_hit.

Lemma t23_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 17 5 getPendingVerifierCallTime_vm_code (M23_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 16 6 getPendingVerifierCallTime_vm_code (M24_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M23_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t23_getPendingVerifierCallTime_vm_hit.

Lemma t24_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 16 6 getPendingVerifierCallTime_vm_code (M24_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 15 7 getPendingVerifierCallTime_vm_code (M25_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M24_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t24_getPendingVerifierCallTime_vm_hit.

Lemma t25_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 15 7 getPendingVerifierCallTime_vm_code (M25_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 14 8 getPendingVerifierCallTime_vm_code (M26_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M25_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t25_getPendingVerifierCallTime_vm_hit.

Lemma t26_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 14 8 getPendingVerifierCallTime_vm_code (M26_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 13 11 getPendingVerifierCallTime_vm_code (M27_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M26_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t26_getPendingVerifierCallTime_vm_hit.

Lemma t27_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 13 11 getPendingVerifierCallTime_vm_code (M27_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 12 12 getPendingVerifierCallTime_vm_code (M28_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M27_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t27_getPendingVerifierCallTime_vm_hit.

Lemma t28_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 12 12 getPendingVerifierCallTime_vm_code (M28_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 11 13 getPendingVerifierCallTime_vm_code (M29_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M28_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t28_getPendingVerifierCallTime_vm_hit.

Lemma t29_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hnth : nth_error xs (Z.to_nat 2%Z) = Some (GInt z)),
 run 11 13 getPendingVerifierCallTime_vm_code (M29_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 10 14 getPendingVerifierCallTime_vm_code (M30_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hnth.
 rewrite run_S.
 cbn [M29_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hnth.
 reflexivity.
Qed.
Print Assumptions t29_getPendingVerifierCallTime_vm_hit.

Lemma t30_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 10 14 getPendingVerifierCallTime_vm_code (M30_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 9 15 getPendingVerifierCallTime_vm_code (M31_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M30_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t30_getPendingVerifierCallTime_vm_hit.

Lemma t31_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z) (Hsum : integer_fitsb (z + 86400000) = true),
 run 9 15 getPendingVerifierCallTime_vm_code (M31_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 8 16 getPendingVerifierCallTime_vm_code (M32_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z Hsum.
 rewrite run_S.
 cbn [M31_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 rewrite Hsum.
 reflexivity.
Qed.
Print Assumptions t31_getPendingVerifierCallTime_vm_hit.

Lemma t32_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 8 16 getPendingVerifierCallTime_vm_code (M32_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) =
 run 7 17 getPendingVerifierCallTime_vm_code (M33_getPendingVerifierCallTime_vm_hit tok sto account payload xs z).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M32_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t32_getPendingVerifierCallTime_vm_hit.

Lemma t33_getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) (sto : storage) (account : bytes) (payload : bytes) (xs : list GVal) (z : Z),
 run 7 17 getPendingVerifierCallTime_vm_code (M33_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) = Done (GInt (z + 86400000%Z)).
Proof.
 intros tok sto account payload xs z.
 rewrite run_S.
 cbn [M33_getPendingVerifierCallTime_vm_hit getPendingVerifierCallTime_vm_init getPendingVerifierCallTime_vm_code getPendingVerifierCallTime_vm_program nth Nat.eqb step storage_lookup pop popn pushv set_stack set_locals set_statics set_calls mstack mlocals margs mstatics msto mcalls mtokens gval_eqb gbytes_eqb firstn skipn].
 reflexivity.
Qed.
Print Assumptions t33_getPendingVerifierCallTime_vm_hit.

Theorem getPendingVerifierCallTime_vm_miss : forall (tok : nat -> GVal -> GVal) sto account,
 sto (getPendingVerifierCallTime_prefix ++ account) = None ->
 run 40 0 getPendingVerifierCallTime_vm_code (getPendingVerifierCallTime_vm_init tok sto account) = Done (GInt 0%Z) /\
 getPendingVerifierCallTime_binding tok sto account = OK (GInt 0%Z).
Proof.
 intros tok sto account Hstore. split.
 - exact (eq_trans (t0_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t1_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t2_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t3_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t4_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t5_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t6_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t7_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t8_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t9_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t10_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t11_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t12_getPendingVerifierCallTime_vm_miss tok sto account Hstore) (eq_trans (t13_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t14_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t15_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t16_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t17_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t18_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t19_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t20_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t21_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t22_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t23_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t24_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t25_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t26_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t27_getPendingVerifierCallTime_vm_miss tok sto account) (eq_trans (t28_getPendingVerifierCallTime_vm_miss tok sto account) (t29_getPendingVerifierCallTime_vm_miss tok sto account)))))))))))))))))))))))))))))).
 - apply getPendingVerifierCallTime_source_miss. exact Hstore.
Qed.
Print Assumptions getPendingVerifierCallTime_vm_miss.
Theorem getPendingVerifierCallTime_vm_hit : forall (tok : nat -> GVal -> GVal) sto account (payload : bytes) (xs : list GVal) (z : Z),
 sto (getPendingVerifierCallTime_prefix ++ account) = Some payload ->
 tok 4%nat (GBytes payload) = GArray xs ->
 nth_error xs (Z.to_nat 2%Z) = Some (GInt z) ->
 integer_fitsb (z + 86400000%Z) = true ->
 run 40 0 getPendingVerifierCallTime_vm_code (getPendingVerifierCallTime_vm_init tok sto account) = Done (GInt (z + 86400000%Z)) /\
 getPendingVerifierCallTime_binding tok sto account = OK (GInt (z + 86400000%Z)).
Proof.
 intros tok sto account payload xs z Hstore Htok Hnth Hsum. split.
 - exact (eq_trans (t0_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t1_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t2_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t3_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t4_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t5_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t6_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t7_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t8_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t9_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t10_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t11_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t12_getPendingVerifierCallTime_vm_hit tok sto account payload xs z Hstore) (eq_trans (t13_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t14_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t15_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t16_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t17_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t18_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t19_getPendingVerifierCallTime_vm_hit tok sto account payload xs z Htok) (eq_trans (t20_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t21_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t22_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t23_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t24_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t25_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t26_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t27_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t28_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t29_getPendingVerifierCallTime_vm_hit tok sto account payload xs z Hnth) (eq_trans (t30_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (eq_trans (t31_getPendingVerifierCallTime_vm_hit tok sto account payload xs z Hsum) (eq_trans (t32_getPendingVerifierCallTime_vm_hit tok sto account payload xs z) (t33_getPendingVerifierCallTime_vm_hit tok sto account payload xs z)))))))))))))))))))))))))))))))))).
 - apply getPendingVerifierCallTime_source_hit with (payload := payload) (xs := xs) (z := z); assumption.
Qed.
Print Assumptions getPendingVerifierCallTime_vm_hit.
