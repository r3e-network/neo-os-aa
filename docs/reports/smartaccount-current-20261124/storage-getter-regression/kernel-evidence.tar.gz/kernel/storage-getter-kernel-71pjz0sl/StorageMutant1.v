From Coq Require Import ZArith List Bool Lia PeanoNat.
Require Import IntegerSemantics StorageGetter.
Import ListNotations. Open Scope Z_scope.
Definition bytes_eqb (a b : bytes) : bool :=
  match list_eq_dec Nat.eq_dec a b with left _ => true | right _ => false end.
Definition fixture_storage : storage := fun key =>
  if bytes_eqb key [7%nat;1%nat] then Some [5%nat] else None.
Definition original_binding (sto : storage) (acct : bytes) : Outcome :=
 getter_outcome [6%nat] (GBytes hash160_default) decode_hash160 sto acct.
Definition mutant_binding (sto : storage) (acct : bytes) : Outcome :=
 getter_outcome [7%nat] (GBytes hash160_default) decode_hash160 sto acct.
